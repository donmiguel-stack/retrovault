Gold Mine Run!
==============

This is an arcade platformer for DOS.

Requirements
------------

- MS/DOS or compatible
- 386DX 33MHz (or better) with VGA
- At least 4MB of RAM
- Sound Blaster (or no sound)

The game can be controlled by keyboard or joystick.

| Key          | Joystick       | Action                  |
| ---          | ---            | ---                     |
| Cursor left  | Joystick left  | Move left               |
| Cursor right | Joystick right | Move Right              |
| Z            | Button 1       | Jump                    |
| P            | -              | Pause / resume game     |
| ESC          | -              | Abandon / exit the game |

Check `-h` CLI flag for options.

The game can be run with DOSBOX, try:

  dosbox -config dosbox.conf


How to Play
-----------

Collect all the gold on a stage to move to the next one. There are 30 stages.

You have 60 seconds to complete each stage, or the time monster will appear and
chase you until you either complete the stage or it kills you!

There are some special pick-ups:

- Bonus gems: add 250 points to your score.
- Extra time: reset the clock to 60 seconds.
- Pickaxe: protect you from one hit, by enemies or mine hazards like the spikes.
- Silver key: open doors with a silver lock.
- Gold key: open doors with a golden lock.

Every 10,000 points you will get an extra life.

Further info
------------

- This was made by Juan J. Martinez: https://www.usebox.net/jjm/about/me/
- Homepage: https://www.usebox.net/jjm/gold-mine-run/

History
-------

- 1.7 (2024-07-01): bug fixes
  + potential stability fix in some VGA functions

- 1.6 (2023-08-19): bug fixes
  + cosmetic fixes starting the game from the cast screen

- 1.5 (2023-08-13): bug fixes
  + use JUMP instead of SPACE in some screens to allow full joystick control
  + better checks when sound initialisation fails

- 1.4 (2023-08-12): bug fixes
  + improved joystick calibration (tested with real hardware)

- 1.3 (2023-08-12): bug fixes
  + update the hiscore

- 1.2 (2023-08-11): bug fixes
  + the joystick calibration is now more accurate

- 1.1 (2023-08-10): bug fixes
  + fixed a few issues with the "no sound" driver, including a crash on exit
    and occasional pauses when the game plays with no sound

- 1.0 (2023-08-08): initial release
