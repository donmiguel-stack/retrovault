Alien Intruder
==============

After investigating a mysterious transmission of unknown origin, the crew of a
commercial spacecraft got captured by unidentified alien forms. It is up to you
to rescue them and deal with the intruders.

In space no one can hear you scream, so use your blaster instead!

Alien Intruder is a single screen jump-and-shoot arcade platformer.


Requirements
------------

- MS/DOS or compatible
- IBM PC/AT 286 or better
- VGA or compatible graphics
- Keyboard or 2 button joystick (2nd button is used for jump)
- AdLib or compatible for music
- SoundBlaster or compatible for sound effects

*Sound and the BLASTER env variable*

The game uses the `BLASTER` environment variable to configure your SoundBlaster.

If you are using DosBox (or one of its siblings), that will be handled for you.

Otherwise you can check this Apogee FAQ for instructions:

http://www.rinkworks.com/apogee/s/6.4.2.shtml)

The AdLib settings are auto-configured and the game also plays fine without
sound.

*Joystick calibration*

If a joystick (or gamepad) is detected, the game will require it to be
calibrated once. After that, the calibration is saved in the file `JOY.RC`.

If you change joystick, you may need to re-calibrate: delete the `JOY.RC` file
before starting the game.

*Resetting the Hall of Fame*

If you want to go back to the default table, just delete `HI.RC` in the game
directory.


How to Play
-----------

You have 60 seconds to rescue all the crew members captured by the aliens on
each stage before running to the exit.

If the time runs out, your character will lose a life.

There are some special pick-ups:

- Bonus points: pick up pizza slices, soda cans and shareware diskettes for
  extra points.
- Energy bomb: an energy wave will cross the stage hitting all enemies in its
  path.
- Extra time: reset the clock back to `60` seconds.
- Extra life: add one extra life, up to `9`.

When completing a stage there are extra bonus points for:

- Time left after reaching the exit.
- Disposing of all the aliens on the screen.
- Completing the stage without losing a life.

There are **50 stages** in total.


Controls
--------

 | Key           | Joystick       | Action              |
 | ---           | ---            | ---                 |
 | Cursor left   | Joystick left  | Move left           |
 | Cursor right  | Joystick right | Move Right          |
 | Cursor up / X | Button 2       | Jump                |
 | Z             | Button 1       | Fire blaster        |
 | P             | -              | Pause / resume game |
 | ESC           | -              | Abandon the game    |

The game menu includes a help section with this information.


Further info
------------

Alien Intruder
Copyright (C) 2024 Juan J.Martinez - usebox.net
All rights reserved.

- This was made by Juan J. Martinez: https://www.usebox.net/jjm/about/me/
- Homepage: https://www.usebox.net/jjm/alien-intruder/

If you like the game, a coffee is greatly appreciated!

https://ko-fi.com/reidrac


History
-------

- 1.1 (2024-12-26): "ready?" improvement
  + avoid unfair deaths by showing the stage layout before the
    action starts
- 1.0 (2024-12-25): initial release and happy Christmas!
  + First public release

