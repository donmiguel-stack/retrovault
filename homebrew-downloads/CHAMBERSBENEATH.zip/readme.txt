THE CHAMBERS BENEATH

Thank you for installing The Chambers Beneath! This is a role-playing
game for one player. It requires MS-DOS and a PC with at least an 8088
processor and CGA graphics. It will also run under DOSBox.

RUNNING ON ORIGINAL HARDWARE

Assuming that you installed the game into its default location of
C:\CHAMBERS, you can run the game with the following sequence of
commands at the C> prompt:

C> cd \chambers
C> chambers

RUNNING ON DOSBOX

Some DOSBox installations have an easy way to run DOS executables by
right clicking on the icon for CHAMBERS.EXE and selecting "Run with
DOSBox" or similar. If your system doesn't have this facility, you can
type the following sequence of commands within DOSBox:

Z:\> mount c /home/user/msdos
Z:\> c:
C:\> cd chambers
C:\CHAMBERS> chambers

This example assumes you have installed The Chambers Beneath within a
directory called /home/user/msdos; if you have installed the game
elsewhere then substitute that directory name instead.

BUGS FIXED

1. The keyboard is not locked if the program quits with an error, such
as when the data file cannot be found or when there is insufficient
memory.

2. The game no longer crashes when diagonal movement takes the cursor
outside the inventory, as sometimes happened on mobile devices with
on-screen keys. Diagonal movement no longer occurs at all.

3. A player character with rope equipped properly escapes a pit trap,
as intended. No longer is the chraacter "trapped" again when the rope
is left behind.
