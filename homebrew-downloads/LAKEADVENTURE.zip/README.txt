+---------------------+
|                     |
|   LAKE Adventure!   |
|   By Eddie Hughes   |
|   Copywrong 1993    |
|                     |
|	 * * *        |
|                     |
|   Revisited         |
|   By Ed Hughes      |
|   March 2020        |
|                     |
+---------------------+

Thank you for downloading LAKE Adventure! There are several ways to play.

To use a DOS emulator, download, set up, and run DOSBox (Windows/Mac/Linux):
https://www.dosbox.com/

Once you've mounted the directory containing the game files, type LAKE.BAT
to run the game. The title image and title screen will advance automatically
after a few moments. Pressing Enter is not necessary on those two screens
and may lead to skipping the introduction.

To use a traditional interactive fiction interpreter, choose one of:

* Gargoyle (Windows/Mac)
  https://github.com/garglk/garglk/releases
* Spatterlight (Mac)
  https://github.com/angstsmurf/spatterlight/releases
* AGiliTy (Windows/Mac/Linux)
  https://www.ifarchive.org/indexes/if-archiveXprogrammingXagtXagility.html

In any of these interpreters, open LAKE.AGX to play the game. Other
interpreters may not support .AGX file types.

If you'd like some hints for particular sections of this story, please see
LAKEMAPS.PDF for the original map of the story's world drawn by Eddie Hughes.

This download includes INDEX.HTML, which can be opened in a web browser and
includes a link to play the game online in DOSBox.

Thanks for playing!