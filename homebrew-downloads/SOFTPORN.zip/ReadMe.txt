                                Softporn Adventure!
                               Version 2.4 Shareware
 

      Original program written and designed by Chuck Benton for the Apple ][. 
        This version re-written, re-designed, and debugged by GARY THOMPSON.

Welcome to the world of SOFTPORN! I feel I should give a little bit of history behind SOFTPORN. The original version of SOFTPORN was written for the Apple II computer by a man named Chuck Benton. When I first played that game, way back in 1984; I thought it was the best game I had ever seen. And since it was written in Applesoft Basic, I made a printout and stored it away. Years later, when I finally began delving into the world of the IBM, I remembered that old printout and promised myself I'd write a version for the
IBM.

Chuck thought that databases were the thing of the future. And he thought that the Apple ][ was the perfect computer to do database programming on. Chuck thought that a perfect test of database programming would be to write a little adventure game.... thus Softporn was born. Softporn on the original Apple was written using a myriad of text files and random access files. These were to test out his ideas on Database programming.

When I began programming in C, I found this the perfect language to re-write Softporn in. So, I grabbed my old printout and loaded my Microsoft Quick-C compiler and began programming it. It took me about three months to complete it. It is written in a mix of Quick-C, Quick-Assembler, and Macro- Assembler. I designed special timing routines using Macro-Assembler that allow the program to run at the same speed no matter how slow or fast your computer is.

One day, I went to my local computer store and bought a copy of Leisure Suit Larry 1. When I played it, I was amazed to see that Larry 1 was the same game as my Softporn! So I contacted Ken Williams, President of Sierra On-Line, and Al Lowe, creator of the Leisure Suit Larry Series. They informed me they bought the rights to Softporn Adventure and re-released it. It won several awards. They then game the contract to Al Lowe and Al re-wrote it, added graphics; and thus LSL was born.

In early 1994, I got a letter from Al Lowe... I gave him my phone number and he gave me a call. He informed me that Sierra On-Line was planning a LSL collector�s edition package called �Leisure Suit Larry�s Greatest Hits (And Misses).� He asked if he could include my game in the CD-ROM disc to show the history of the game. This was because my game is the only surviving copy of the original Softporn. Of course I said YES! The CD-ROM disk was released and my Softporn included on it.

Softporn is an adult adventure game. Your objective is to "score� three times. You must hunt down your female prey and do your thing. Your objective will not be an easy one. There are many tasks you must complete. Many puzzles you will have to solve. And in the end, you will get your reward!

Since this is a text only game, much of what you see lies in your imagination. You control your actions by typing in various two word commands. Your commands will consist of a verb followed by a noun.... Such as �OPEN DOOR,� �PUSH BUTTON,� or �KISS GIRL.� There are many commands so figure them out and what they do. Try anything you can think of! There are some outrageous combinations!

This game follows suit to most other adventure games. If you can pick it up, do so. If you can use it, figure out how. But remember, there are many things that you can use more than once. And everything has a use, however small. But you cannot hold everything you can find, so remember where you put things; they will stay where you drop them.

You will start off the game with $2,500. You will find the price of things in the game very high so your money will quickly diminish. You must find a way to get more.

Version 1.1 now supports 43/50 line screens, whichever your video can support. Plus the command structure is a little better. To switch to 43/50 line mode, simply type -H on the command line when running Softporn.

Version 2.1 contained a major re-write of the game for the CD-ROM disc release. Many bugs were killed. Most of the casino games were totally re-designed.

Version 2.2 was the version released on the CD-ROM disk. Sierra forgot to include three major files on the disc. =(

Version 2.3 added a file-missing error trap. Since the files missing in version 2.2 gave no error when the program was run, I take the blame for that. Version 2.3 added an error trap, if the files are missing, the program fails to run.

Version 2.4 is simply a bug fix. A few players with good eyes notified me of some bugs. Paying the TAXI driver didn�t always check for running out of money and ended up giving the player $65,000. Added error traps.

Since this is an adult game, it should not be played by anyone under 18. (Yes, this is the disclaimer) Also, neither the programmer, nor the Sysop of this bbs are responsible for any damage resulting because of the use of this game. By obtaining this game, the user automatically consents to this.

I found this game very enjoyable to play. It was also much fun to write. If you like this game, I would appreciate any donations you could offer. For every donation, I will send a list of other files and games you can find by me. And for a small $10.00 fee per disk, I will send you any of them. Please send any donations to the address listed at the end of the document.

Thank you for trying this program, and I hope it brings a lot of fun. Bye!

Gary Thompson
AKA The Psycho!
The Psycho Strikes!


This game is the product of a LOT of hard work and programming on my part. So do the right thing and SUPPORT SHAREWARE! Please register this program by sending a check or money order for $20 made out to the name and address listed below. Upon registering, you will get the latest version of the game and be placed on my mailing list for notices of new games and programs releases. When registering, include which size floppy disk you prefer me to send. Thanks!

Gary Thompson
400 NW 51st CT
Ft Lauderdale, FL 33309

CREDITS:
I wish to sincerely thank all my beta testers that spent so much of their time helping me make this program as bullet-proof as possible:
Kevin J. Kearney (Cardis)
Linda Neary  (Ariel)
Penny   (Kojak)

I also wish to thank Art Constantino who runs the AAA (Always All Adult BBS 305-584-4080) for giving up so much of his valuable time and resources of his BBS to allow me to beta test my game.
