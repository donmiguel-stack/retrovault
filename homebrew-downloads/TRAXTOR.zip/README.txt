The Return of Traxtor
Copyright (c) 2023 Juan J. Martinez <jjm@usebox.net>
All rights reserved.

This is an arcade puzzle game for DOS.

Requirements
------------

- MS/DOS or compatible
- IBM PC/XT 8086 compatible (or better)
- CGA or compatible
- PC Speaker

Controls:

| Keyboard           | Action                               |
| ---                | ---                                  |
| cursor left        | move spaceship to the left           |
| cursor right       | move spaceship to the right          |
| cursor down        | beam a block into the bay            |
| cursor up or space | fire the top-most block from the bay |

The game can be run with DOSBOX, try:

  dosbox traxtor.com

How to Play
-----------

Use the tractor beam to move blocks into the bay, and fire to throw back the
top-most block to the board.

Match 3 or more blocks to destroy them before they reach to your defence line.

Wildcard blocks can be thrown to any block type and they will turn into that
type.

There are 25 levels!

Further info
------------

- This was made by Juan J. Martinez: https://www.usebox.net/jjm/about/me/
- Homepage: https://www.usebox.net/jjm/return-of-traxtor-dos/

History
-------

- 1.0 (2023-09-14): initial release
