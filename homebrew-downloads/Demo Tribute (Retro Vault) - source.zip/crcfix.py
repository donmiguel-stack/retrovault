#!/usr/bin/env python3
"""Patch the last 4 bytes of a ROM so that its CRC32 matches a target.
o2em picks 'tweakedaudio' (the volume register sampled per scanline instead
of once per frame) by ROM CRC; 0xC4134DF8 (Helicopter Rescue +) sets nothing
else. The real console does not care."""
import sys, zlib
path, target = sys.argv[1], int(sys.argv[2], 16)
d = bytearray(open(path, 'rb').read())
assert d[-4:] == b'\xff\xff\xff\xff', "last 4 bytes are not free"
base = d[:-4]
c0 = zlib.crc32(bytes(base) + b'\0\0\0\0')
cols = []
for bit in range(32):
    x = (1 << bit).to_bytes(4, 'little')
    cols.append(zlib.crc32(bytes(base) + x) ^ c0)
# solve M x = c0 ^ target over GF(2), M columns = cols
want = c0 ^ target
# gaussian elimination
rows = [[(cols[j] >> i) & 1 for j in range(32)] + [(want >> i) & 1] for i in range(32)]
for col in range(32):
    piv = next(r for r in range(col, 32) if rows[r][col])
    rows[col], rows[piv] = rows[piv], rows[col]
    for r in range(32):
        if r != col and rows[r][col]:
            rows[r] = [a ^ b for a, b in zip(rows[r], rows[col])]
x = sum(rows[i][32] << i for i in range(32))
d[-4:] = x.to_bytes(4, 'little')
assert zlib.crc32(bytes(d)) == target
open(path, 'wb').write(d)
print("crc32 patched to %08x with bytes %s" % (target, d[-4:].hex()))
