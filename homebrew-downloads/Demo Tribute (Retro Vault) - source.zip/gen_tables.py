#!/usr/bin/env python3
"""Generates tables.inc for the Retro Vault demo ROM: rain glyph slices,
the sine for the scroller, the scroller text in BIOS character codes, the
Munchkin sprite frames, and the music step table."""
import math, random

out = []
out5 = out
def db(name, data, comment=""):
    out.append(f"{name}:" + (f"\t; {comment}" if comment else ""))
    for i in range(0, len(data), 12):
        out.append("        db     " + ",".join("0%02xh" % b for b in data[i:i + 12]))

# --- rain glyphs: 8 full + 4 sparse, 8x10, slice bytes bit0 = leftmost ---
rnd = random.Random(7)
def glyph():
    g = [[0] * 8 for _ in range(10)]
    for _ in range(rnd.randint(3, 5)):
        if rnd.random() < 0.5:
            y = rnd.randint(1, 8); x0 = rnd.randint(0, 2); x1 = rnd.randint(5, 7)
            for x in range(x0, x1 + 1): g[y][x] = 1
            if rnd.random() < 0.4 and y < 9:
                for x in range(x0, x1 + 1): g[y + 1][x] = 1
        else:
            x = rnd.randint(1, 6); y0 = rnd.randint(0, 4); y1 = rnd.randint(5, 9)
            dx = rnd.choice([0, 0, 1, -1])
            for y in range(y0, y1 + 1):
                xx = min(7, max(0, x + (dx * (y - y0)) // 3))
                g[y][xx] = 1
                if rnd.random() < 0.3 and xx < 7: g[y][xx + 1] = 1
    return g
glyphs = [glyph() for _ in range(8)]
sparse = []
for g in glyphs[:4]:
    sparse.append([[g[y][x] if (x + y) % 2 == 0 else 0 for x in range(8)] for y in range(10)])
# EF9340 slice: the BIOS/o2em write path reverses the bits, bit 0 = leftmost pixel
def slices(g):
    return [sum(g[y][x] << (7 - x) for x in range(8)) for y in range(10)]
data = []
for g in glyphs + sparse:
    data += slices(g)
db("glyph_slices", data, "12 glyphs x 10 slices, codes 0A0h..0ABh")

# --- sine for the scroller: 64 entries, VDC Y ---
db("sine_tab", [int(round(100 + 18 * math.sin(i / 64 * 2 * math.pi))) for i in range(64)], "y = 100 +- 18")
# plasma: 4x4 Bayer dither, 8 levels x 4 rows, bit 0 = leftmost pixel
BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]
dith = []
for L in range(8):
    thr = L * 2 + 1
    for r in range(4):
        dith.append(sum((1 << x) for x in range(8) if BAYER[r][x % 4] < thr))
db("dither", dith, "8 levels x 4 rows")
db("pl_col", [0x88 | c for c in (4, 1, 3, 2, 6, 5, 7, 1)], "plasma attr per level: B R Y G C M W R")
open("tables5.inc", "w").write("\n".join(out5) + "\n")
out = []

# --- scroller text in BIOS charset codes ---
CODES = {' ': 0x0C, '.': 0x27, '-': 0x28, '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
         'A': 0x20, 'B': 0x25, 'C': 0x23, 'D': 0x1A, 'E': 0x12, 'F': 0x1B, 'G': 0x1C, 'H': 0x1D, 'I': 0x16, 'J': 0x1E,
         'K': 0x1F, 'L': 0x0E, 'M': 0x26, 'N': 0x2D, 'O': 0x17, 'P': 0x0F, 'Q': 0x18, 'R': 0x13, 'S': 0x19, 'T': 0x14,
         'U': 0x15, 'V': 0x24, 'W': 0x11, 'X': 0x22, 'Y': 0x2C, 'Z': 0x21}
TEXT = "        THIS IS NOT A DEMO - ITS JUST A TRIBUTE   RETROVAULT.WORLD            "
codes = [CODES[c] for c in TEXT]
out.append(f"TEXT_LEN        equ    {len(codes)}")
db("scroll_text", codes, TEXT)

# --- Munchkin: VDC sprite bytes, bit 0 = leftmost pixel ---
OPEN = ["00111100", "01111110", "11011000", "11110000", "11110000", "11111000", "01111110", "00111100"]
SHUT = ["00111100", "01111110", "11011111", "11111111", "11111111", "11111111", "01111110", "00111100"]
def spr(rows): return [int(r[::-1], 2) for r in rows]
db("munch_open", spr(OPEN)); db("munch_shut", spr(SHUT))

# --- music: one byte per 16th step: bits 0-2 note index, bit 3 drum, bits 4-7 unused
# The 24-bit shift register is clocked LSB first and loops, so a note is n
# square cycles packed into those 24 bits: pitch = clock * n / 24.  n need not
# divide 24 -- n=5 (the major third over n=4) just buzzes slightly, which is
# the point: it is the only third the chip can make.
def pattern(n):                                     # the register shifts MSB first
    bits = [1 if (b * n) % 24 >= 12 else 0 for b in range(24)]
    return [sum(bits[k * 8 + i] << (7 - i) for i in range(8)) for k in range(3)]
# index -> (cycles in 24 bits, clock bit; 0x20 = fast, about four times the slow
# clock).  1-2 bass: the root the tune already had, and the octave over it.
# 3-7 lead: 2:3:4:5:6 over that -- root, fifth, octave, major third, fifth.
NOTES = [(2, 0x00), (4, 0x00), (2, 0x20), (3, 0x20), (4, 0x20), (5, 0x20), (6, 0x20)]
note_tab = []
for n, clk in NOTES:
    note_tab += pattern(n) + [0xC0 | clk]           # volume added at runtime
open("tables6.inc", "w").write("\n".join(out) + "\n        include \"tables_mus.inc\"\n")
out = []
db("note_tab", note_tab, "4 bytes per note: A7 A8 A9 AA-base")
BASS = [1, 1, 2, 1, 1, 1, 2, 1]
# the lead sits on the off-eighths; four different bars, so the hook is 8 s long
LEAD = [[5, 4, 5, 4, 5, 4, 3, 4],
        [5, 4, 5, 4, 5, 5, 4, 3],
        [4, 5, 4, 5, 4, 3, 4, 5],
        [5, 4, 3, 4, 5, 4, 5, 5]]
DRUMS = [(0, 4, 8, 12), (0, 4, 8, 12), (0, 4, 8, 12), (0, 4, 8, 12, 14)]
steps = []
for bar in range(4):
    for s16 in range(16):
        drum = 8 if s16 in DRUMS[bar] else 0
        note = BASS[(s16 // 2) % 8] if s16 % 2 == 0 else LEAD[bar][s16 // 2]
        steps.append(drum | note)
assert all(s & 7 for s in steps), "the player has no rest path: every step needs a note"
db("music_steps", steps, "64 steps = 4 bars")
db("vol_drum", [15, 11, 7, 10, 8, 6]); db("vol_note", [12, 11, 10, 9, 8, 6])
# MUS_SECT rows, set by the demo: 0 as written (text, bars, plain plasma);
# 1 the colour note on alternate steps (dancer, interlude, card, credits);
# 2 bass only (-8 drops every lead note onto the bass root: cube start, after
# the credits); 3 the cube once it is under way
db("lift_tab", [0, 0, 0, 1, 0xf8, 0xf8, 1, 0], "phase section x alternate step")
open("tables_mus.inc", "w").write("\n".join(out) + "\n")
print("tables5/6.inc written; text", len(codes), "chars")
