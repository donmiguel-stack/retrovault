#!/usr/bin/env python3
"""Shape and logo tables for the shape banks.
Field = 80x75 mosaic pixels (40x25 cells, 2x3 blocks). Logo on cell rows 0-9,
shapes below (centre 40,54). Each shape: 32 rotation frames of projected
vertex (x,y) bytes, plus an edge list (pairs of vertex indices)."""
import math, sys

PHI = (1 + 5 ** 0.5) / 2
CUBE_V = [(sx, sy, sz) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
CUBE_E = [(0, 1), (0, 2), (0, 4), (1, 3), (1, 5), (2, 3), (2, 6), (3, 7), (4, 5), (4, 6), (5, 7), (6, 7)]
OCTA_V = [(1.6, 0, 0), (-1.6, 0, 0), (0, 1.6, 0), (0, -1.6, 0), (0, 0, 1.6), (0, 0, -1.6)]
OCTA_E = [(0, 2), (0, 3), (0, 4), (0, 5), (1, 2), (1, 3), (1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]
_ic = [(0, s1, s2 * PHI) for s1 in (-1, 1) for s2 in (-1, 1)]
ICOSA_V = [(x / PHI * 1.35, y / PHI * 1.35, z / PHI * 1.35) for (x, y, z) in _ic + [(b, c, a) for (a, b, c) in _ic] + [(c, a, b) for (a, b, c) in _ic]]
_icl = min(sum((ICOSA_V[i][k] - ICOSA_V[j][k]) ** 2 for k in range(3)) for i in range(12) for j in range(i + 1, 12))
ICOSA_E = [(i, j) for i in range(12) for j in range(i + 1, 12)
           if abs(sum((ICOSA_V[i][k] - ICOSA_V[j][k]) ** 2 for k in range(3)) - _icl) < 1e-6]
assert len(ICOSA_E) == 30, len(ICOSA_E)
STELLA_V = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1), (-1, -1, -1), (-1, 1, 1), (1, -1, 1), (1, 1, -1)]
STELLA_E = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3), (4, 5), (4, 6), (4, 7), (5, 6), (5, 7), (6, 7)]

SHAPES = {"cube": (CUBE_V, CUBE_E), "octa": (OCTA_V, OCTA_E), "icosa": (ICOSA_V, ICOSA_E), "stella": (STELLA_V, STELLA_E)}
CX, CY, SX, SY = 40, 54, 13, 11
NFRAMES = 32

def project(verts, ang):
    pts = []
    for x, y, z in verts:
        x, z = x * math.cos(ang) - z * math.sin(ang), x * math.sin(ang) + z * math.cos(ang)
        y, z = y * math.cos(ang * 0.7) - z * math.sin(ang * 0.7), y * math.sin(ang * 0.7) + z * math.cos(ang * 0.7)
        d = 3.2 / (z + 4.0)
        pts.append((int(round(CX + x * SX * d)), int(round(CY + y * SY * d))))
    return pts

def db(out, name, data, comment=""):
    out.append(f"{name}:" + (f"\t; {comment}" if comment else ""))
    for i in range(0, len(data), 16):
        out.append("        db     " + ",".join("0%02xh" % (b & 0xff) for b in data[i:i + 16]))

def shape_tables(name, page0, npages=2):
    """Frames as 16-byte slots (8 vertex x,y pairs) or 32-byte slots (icosa),
    15 (or 7) frames per 256-byte page, the page's movp stub at 0FEh.
    Emits full pages at page0, page0+1, ... as org blocks."""
    verts, edges = SHAPES[name]
    slot = 32 if len(verts) > 8 else 16
    per_page = 254 // slot
    nframes = per_page * npages
    out = [f"{name.upper()}_NV      equ    {len(verts)}",
           f"{name.upper()}_NE      equ    {len(edges)}",
           f"{name.upper()}_SLOT    equ    {slot}",
           f"{name.upper()}_PPG     equ    {per_page}",
           f"{name.upper()}_NFR     equ    {nframes}",
           f"{name.upper()}_PAGE    equ    {page0:02x}h"]
    for pg in range(npages):
        data = []
        for f in range(per_page):
            pts = project(verts, (pg * per_page + f) * 2 * math.pi / nframes)
            row = [c for p in pts for c in p]
            row += [0] * (slot - len(row))
            data += row
        data += [0] * (254 - len(data))
        out.append(f"        org    0{page0 + pg:02x}00h")
        db(out, f"{name}_frames{pg}", data, f"frames {pg * per_page}-{pg * per_page + per_page - 1}")
    out.append(f"        org    0{page0 + npages:02x}00h")
    db(out, f"{name}_edges", [v for e in edges for v in e], f"{len(edges)} edges")
    return "\n".join(out) + "\n", nframes

# --- the logo as cells: "RETRO" rows 0-4, "VAULT" rows 5-9, cols 5-33 ---
FONT5 = {
 'A': ["01110","10001","10001","11111","10001","10001","10001"],
 'E': ["11111","10000","10000","11110","10000","10000","11111"],
 'L': ["10000","10000","10000","10000","10000","10000","11111"],
 'O': ["01110","10001","10001","10001","10001","10001","01110"],
 'R': ["11110","10001","10001","11110","10100","10010","10001"],
 'T': ["11111","00100","00100","00100","00100","00100","00100"],
 'U': ["10001","10001","10001","10001","10001","10001","01110"],
 'V': ["10001","10001","10001","10001","10001","01010","00100"],
 ' ': ["00000"]*7}
def text_bitmap(text, scale=2):
    w = len(text) * 6 * scale - scale; h = 7 * scale
    bmp = [[0] * w for _ in range(h)]
    for i, ch in enumerate(text):
        for ry, row in enumerate(FONT5[ch]):
            for rx, b in enumerate(row):
                if b == '1':
                    for dy in range(scale):
                        for dx in range(scale):
                            bmp[ry * scale + dy][(i * 6 + rx) * scale + dx] = 1
    return bmp
def logo_cells():
    """returns list of (row, col, blockbits) for the two words; blockbits bit i = block i (row-major 2x3)"""
    cells = []
    for word, row0 in (("RETRO", 0), ("VAULT", 5)):
        bmp = text_bitmap(word)             # 58 x 14
        for cr in range(5):
            for cc in range(29):
                bits = 0
                for by in range(3):
                    for bx in range(2):
                        y, x = cr * 3 + by, cc * 2 + bx
                        if y < 14 and x < 58 and bmp[y][x]:
                            bits |= 1 << (by * 2 + bx)
                if bits:
                    cells.append((row0 + cr, 5 + cc, bits))
    return cells

if __name__ == "__main__":
    cells = logo_cells()
    out = []
    out.append(f"LOGO_N          equ    {len(cells)}")
    # packed: row (0-9) in bits 4-7 | blocks in bits 0-5? blocks need 6 bits -> two bytes: (row<<6|col), bits
    db(out, "logo_pos", [c for r, c, b in cells], "column")
    db(out, "logo_bits", [b for r, c, b in cells], "2x3 block bits")
    open("logo.inc", "w").write("\n".join(out) + "\n")
    out = []
    starts = [next(i for i, (r, c, b) in enumerate(cells) if r >= row) for row in range(10)] + [len(cells)]
    db(out, "logo_rows", starts, "first cell index of each of the 10 rows, then the end")
    open("logo_rows.inc", "w").write("\n".join(out) + "\n")
    print("logo cells", len(cells))
    # bank B: cube at pages 05-06 (edges in page 07), octa at 08-09 (edges page 0A)
    # bank C: icosa at 05-06 (edges 07), stella at 08-09 (edges 0A)
    for name, page0, npages in (("cube", 5, 1), ("octa", 8, 1)):
        txt, n = shape_tables(name, page0, npages)
        open(f"shape_{name}.inc", "w").write(txt)
        print(name, n, "frames")
    # div3 table: y 0..79 -> (y//3)<<2 | y%3
    out = []
    db(out, "div3", [((y // 3) << 2) | (y % 3) for y in range(80)], "y -> cellrow<<2 | block row")
    open("div3.inc", "w").write("\n".join(out) + "\n")
