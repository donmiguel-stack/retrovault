#!/usr/bin/env python3
"""Cube data for bank B.

Two representations in one ROM stream (pages 9..F, 254 bytes per page with a
movp stub at xFEh, walked by rd_next):

  rotation frames  cell runs, diffed against the previous frame
                   `row-11<<4 | len, col, chars...`, 0, then the erase runs
                   `row-11<<4 | len, col`, 0   -- cheap to draw, flicker free
  div3             y -> (y//3)<<2 | y%3, for the segment drawer
  zoom frames      `count`, then x0,y0,x1,y1 per clipped line segment: a camera
                   fly-in, ~40 bytes a frame instead of ~250, drawn as lines

usage: gen_cube.py NF SIZE PAGE0 OFF0 tab.inc frames.inc DIST,DIST,...
"""
import math, sys

CX, CY = 40, 54                     # field centre, in 2x3 mosaic pixels (80 x 75)
FIELD_TOP, FIELD_BOT = 33, 75       # the rows below the logo
TILT = math.radians(28)
ROLL = math.radians(12)
NEAR = 0.45                         # near plane, in front of the camera
V = [(sx, sy, sz) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
E = [(0,1),(0,2),(0,4),(1,3),(1,5),(2,3),(2,6),(3,7),(4,5),(4,6),(5,7),(6,7)]

def rot(p, yaw):
    x, y, z = p
    x, z = x*math.cos(yaw) - z*math.sin(yaw), x*math.sin(yaw) + z*math.cos(yaw)
    y, z = y*math.cos(TILT) - z*math.sin(TILT), y*math.sin(TILT) + z*math.cos(TILT)
    x, y = x*math.cos(ROLL) - y*math.sin(ROLL), x*math.sin(ROLL) + y*math.cos(ROLL)
    return x, y, z

def project(p, dist, size):
    x, y, z = p
    d = 3.2 / (z + dist)
    return CX + x*14*size*d, CY + y*12*size*d

def clip_near(a, b, dist):
    za, zb = a[2]+dist-NEAR, b[2]+dist-NEAR
    if za < 0 and zb < 0: return None
    if za < 0:
        t = za/(za-zb); a = tuple(a[i]+t*(b[i]-a[i]) for i in range(3))
    elif zb < 0:
        t = zb/(zb-za); b = tuple(b[i]+t*(a[i]-b[i]) for i in range(3))
    return a, b

def clip2d(p0, p1):
    """Liang-Barsky against the field; integer endpoints, or None"""
    x0, y0 = p0; x1, y1 = p1
    dx, dy = x1-x0, y1-y0
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, x0), (dx, 79-x0), (-dy, y0-FIELD_TOP), (dy, FIELD_BOT-1-y0)):
        if p == 0:
            if q < 0: return None
        else:
            r = q/p
            if p < 0:
                if r > t1: return None
                if r > t0: t0 = r
            else:
                if r < t0: return None
                if r < t1: t1 = r
    a = (int(round(x0+t0*dx)), int(round(y0+t0*dy)))
    b = (int(round(x0+t1*dx)), int(round(y0+t1*dy)))
    return None if a == b else (a, b)

def segments(yaw, dist, size):
    rv = [rot(v, yaw) for v in V]
    out = []
    for a, b in E:
        s = clip_near(rv[a], rv[b], dist)
        if not s: continue
        c = clip2d(project(s[0], dist, size), project(s[1], dist, size))
        if c: out.append(c)
    return out

def cells(yaw, dist, size):
    px = set()
    for a, b in segments(yaw, dist, size):
        x0, y0 = a; x1, y1 = b
        dx, dy = abs(x1-x0), -abs(y1-y0)
        sx = 1 if x0 < x1 else -1; sy = 1 if y0 < y1 else -1
        err = dx+dy
        while True:
            px.add((x0, y0))
            if x0 == x1 and y0 == y1: break
            e2 = 2*err
            if e2 >= dy: err += dy; x0 += sx
            if e2 <= dx: err += dx; y0 += sy
    out = {}
    for x, y in px:
        out.setdefault((y//3, x//2), 0)
        out[(y//3, x//2)] |= 1 << ((y % 3)*2 + (x % 2))
    return out

def runs(keys):
    out = []; cur = None
    for r, c in sorted(keys):
        if cur and cur[0] == r and cur[1]+len(cur[2]) == c and len(cur[2]) < 15:
            cur[2].append(c)
        else:
            cur = [r, c, [c]]; out.append(cur)
    return out

NF   = int(sys.argv[1])
SIZE = float(sys.argv[2])
PG0  = int(sys.argv[3], 16)
OFF0 = int(sys.argv[4])
DOLLY = [float(x) for x in sys.argv[7].split(",")] if len(sys.argv) > 7 else []

# ---- rotation frames, as diffed cell runs ----
frames = [cells(k*(math.pi/2)/NF, 4.0, SIZE) for k in range(NF)]
rot_data = []
for k in range(NF):
    cur, prev = frames[k], frames[k-1]
    b = []
    for r, c, cols in runs(cur.keys()):
        b += [((r-11) << 4) | len(cols), c] + [0x40 | cur[(r, cc)] for cc in cols]
    b.append(0)
    for r, c, cols in runs([key for key in prev if key not in cur]):
        b += [((r-11) << 4) | len(cols), c]
    b.append(0)
    rot_data.append(b)

# ---- zoom frames, as clipped segments (the rotation keeps running) ----
zoom_data = []
for i, dist in enumerate(DOLLY):
    segs = segments((NF+i)*(math.pi/2)/NF, dist, SIZE)
    b = [len(segs)]
    for (x0, y0), (x1, y1) in segs:
        b += [x0, y0, x1, y1]
    zoom_data.append(b)

# ---- lay the stream out over the pages ----
stream = []                      # (page, offset, bytes, label)
pg, off = PG0, OFF0
starts = []
def place(b):
    global pg, off
    out = []
    i = 0
    while i < len(b):
        n = min(254-off, len(b)-i)
        out.append((pg, off, b[i:i+n]))
        i += n; off += n
        if off == 254: off = 0; pg += 1
    return out

chunks = []
for b in rot_data:
    starts.append((pg, off)); chunks += place(b)
for b in zoom_data:
    starts.append((pg, off)); chunks += place(b)
last_page = pg if off else pg-1

tab = [f"FREE_ORG        equ    0{pg:02x}{off:02x}h   ; first free byte after the data",
       f"CUBE_NF         equ    {NF}",
       f"ZOOM_NF         equ    {len(zoom_data)}",
       "cube_starts:    ; page, offset of every frame (rotation, then zoom)"]
for p, o in starts:
    tab.append(f"        db     0{p:02x}h,{o}")
open(sys.argv[5], "w").write("\n".join(tab) + "\n")

out = []
cur_page = None
for p, o, b in chunks:
    if p != cur_page:
        if cur_page is not None:
            out += [f"        org    0{cur_page:02x}feh", f"read_p{cur_page:x}:",
                    "        movp   a,@a", "        ret"]
        cur_page = p
    out.append(f"        org    0{p:02x}{o:02x}h")
    for i in range(0, len(b), 16):
        out.append("        db     " + ",".join(f"0{v:02x}h" for v in b[i:i+16]))
out += [f"        org    0{cur_page:02x}feh", f"read_p{cur_page:x}:",
        "        movp   a,@a", "        ret"]
open(sys.argv[6], "w").write("\n".join(out) + "\n")

print(f"rotation {NF} frames, {sum(len(b) for b in rot_data)} bytes; "
      f"zoom {len(zoom_data)} frames, {sum(len(b) for b in zoom_data)} bytes; "
      f"last data page {last_page:x}", file=sys.stderr)
