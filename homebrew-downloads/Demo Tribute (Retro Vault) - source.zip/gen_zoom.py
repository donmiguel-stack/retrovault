#!/usr/bin/env python3
"""Zoom frames for the cube: a camera fly-in stored as screen-space line segments.
Each frame = count, then 4 bytes per segment (x0, y0, x1, y1) already clipped to the
mosaic field, so the ROM holds ~40 bytes per frame instead of ~250 of cell runs.
The player draws them without erasing: the cubes pile up into a tunnel."""
import math, sys
CX, CY = 40, 54
FIELD_TOP, FIELD_BOT = 33, 75
TILT = math.radians(28); ROLL = math.radians(12)
V = [(sx, sy, sz) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
E = [(0,1),(0,2),(0,4),(1,3),(1,5),(2,3),(2,6),(3,7),(4,5),(4,6),(5,7),(6,7)]
NEAR = 0.45

def rot(p, yaw):
    x, y, z = p
    x, z = x*math.cos(yaw) - z*math.sin(yaw), x*math.sin(yaw) + z*math.cos(yaw)
    y, z = y*math.cos(TILT) - z*math.sin(TILT), y*math.sin(TILT) + z*math.cos(TILT)
    x, y = x*math.cos(ROLL) - y*math.sin(ROLL), x*math.sin(ROLL) + y*math.cos(ROLL)
    return x, y, z

def project(p, dist, size):
    x, y, z = p
    d = 3.2 / (z + dist)
    return CX + x*14*size*d, CY + y*12*size*d

def clip_near(a, b, dist):
    za, zb = a[2]+dist-NEAR, b[2]+dist-NEAR
    if za < 0 and zb < 0: return None
    if za < 0:
        t = za/(za-zb); a = tuple(a[i]+t*(b[i]-a[i]) for i in range(3))
    elif zb < 0:
        t = zb/(zb-za); b = tuple(b[i]+t*(a[i]-b[i]) for i in range(3))
    return a, b

def clip2d(p0, p1):
    """Liang-Barsky to the field box; returns integer endpoints or None"""
    x0, y0 = p0; x1, y1 = p1
    dx, dy = x1-x0, y1-y0
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, x0-0), (dx, 79-x0), (-dy, y0-FIELD_TOP), (dy, FIELD_BOT-1-y0)):
        if p == 0:
            if q < 0: return None
        else:
            r = q/p
            if p < 0:
                if r > t1: return None
                if r > t0: t0 = r
            else:
                if r < t0: return None
                if r < t1: t1 = r
    a = (int(round(x0+t0*dx)), int(round(y0+t0*dy)))
    b = (int(round(x0+t1*dx)), int(round(y0+t1*dy)))
    return a, b

def frame_segs(yaw, dist, size):
    rv = [rot(v, yaw) for v in V]
    segs = []
    for a, b in E:
        s = clip_near(rv[a], rv[b], dist)
        if not s: continue
        c = clip2d(project(s[0], dist, size), project(s[1], dist, size))
        if c and (c[0] != c[1]): segs.append(c)
    return segs

if __name__ == "__main__":
    size = float(sys.argv[1]); nf = int(sys.argv[2])
    dists = [float(x) for x in sys.argv[3].split(",")]
    tot = 0
    for i, d in enumerate(dists):
        yaw = (nf + i) * (math.pi/2) / nf
        s = frame_segs(yaw, d, size)
        tot += 1 + 4*len(s)
        print(f"  dist {d:5.2f}  segs {len(s):2d}  bytes {1+4*len(s):3d}")
    print("total", tot)
