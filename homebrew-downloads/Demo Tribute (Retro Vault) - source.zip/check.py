"""Every jump and call in the AS listing must land where its label is: conditional
jumps take their page from the byte after the instruction (8048), so one that sits on a
page edge jumps into the next page. Exit 1 on any mismatch."""
import re, sys
lst = open(sys.argv[1], encoding='latin-1').read().split('\n')
# symbol table: lines like "NAME : 0612 - ..." in AS listing; collect from code lines with labels instead
labels = {}
for line in lst:
    m = re.match(r'^\s*\d+/\s*([0-9A-F]{3,4})\s*:\s*(?:[0-9A-F]{2}\s)*\s*([A-Za-z_][A-Za-z0-9_]*):', line)
    if m: labels[m.group(2).lower()] = int(m.group(1), 16)
bad = 0
for line in lst:
    m = re.match(r'^\s*\d+/\s*([0-9A-F]{3,4})\s*:\s*((?:[0-9A-F]{2}\s)+)\s*(?:\(MACRO\).*)?(jmp|call|jz|jnz|jc|jnc|jb[0-7]|jf0|jf1|jtf|jt0|jnt0|jt1|jnt1|jni|djnz)\s+(?:r[0-7],)?([A-Za-z_][A-Za-z0-9_]*)', line, re.I)
    if not m: continue
    addr = int(m.group(1), 16); bytes_ = [int(b, 16) for b in m.group(2).split()]; op = m.group(3).lower(); lab = m.group(4).lower()
    if lab not in labels: continue
    tgt = labels[lab]
    b = bytes_
    if b[0] in (0xE5, 0xF5): mb = (b[0] == 0xF5); b = b[1:]
    else: mb = None
    if op in ('jmp', 'call'):
        enc = ((b[0] >> 5) << 8) | b[1]
        if mb is None: mb = (addr >= 0x800)
        enc |= 0x800 if mb else 0
        if enc != tgt: print('MISMATCH %04X %s %s -> enc %04X, label %04X' % (addr, op, lab, enc, tgt)); bad += 1
    else:
        nxt = addr + len(bytes_)
        enc = (nxt & 0xF00) | b[1]
        if enc != tgt: print('MISMATCH %04X %s %s -> enc %04X, label %04X' % (addr, op, lab, enc, tgt)); bad += 1
print('check.py:', len(labels), 'labels,', bad, 'mismatches')
sys.exit(1 if bad else 0)
