#!/bin/sh
# 12K cart = 4 x 3K banks selected by P10/P11 (o2em bank mode 3, 4-in-1 scheme).
# File order (o2em loads the LAST 3K as the boot bank, P1 = 11):
#   bank D (P1=00: production card + sample) | bank C (01: intro voice) | bank B (10: cube) | bank A (11: boot)
set -e
cd "$(dirname "$0")"
A=${ASL_DIR:-$HOME/tc/asl}
$A/asl -cpu 8048 -L -q cube.a48 -o cube.p
$A/p2bin cube.p bankb.bin -r '$400-$fff' -l '$ff' >/dev/null
$A/asl -cpu 8048 -L -q speech.a48 -o speech.p
$A/p2bin speech.p bankc.bin -r '$400-$fff' -l '$ff' >/dev/null
$A/asl -cpu 8048 -L -q demo.a48 -o demo.p
$A/p2bin demo.p banka.bin -r '$400-$fff' -l '$ff' >/dev/null
$A/asl -cpu 8048 -L -q sample.a48 -o sample.p
$A/p2bin sample.p bankd.bin -r '$400-$fff' -l '$ff' >/dev/null
python3 check.py demo.lst
python3 check.py cube.lst
python3 check.py sample.lst
cat bankd.bin bankc.bin bankb.bin banka.bin > demo.bin
python3 crcfix.py demo.bin C4134DF8
ls -l demo.bin; md5sum demo.bin
