#!/usr/bin/env python3
"""Dancer silhouettes for the plasma part: poses built from capsules (thick
segments) in a 192x220 px box, rasterised to 24x22 Plus cells (8x10 px).
Output dancer.inc: 2 poses x 22 rows x 3 bytes, bit 0 = leftmost cell."""
import math, sys
import numpy as np
W, H = 24 * 8, 22 * 10
def capsule(img, p0, p1, r):
    ys, xs = np.mgrid[0:H, 0:W]
    x0, y0 = p0; x1, y1 = p1
    dx, dy = x1 - x0, y1 - y0
    L2 = dx * dx + dy * dy or 1
    t = np.clip(((xs - x0) * dx + (ys - y0) * dy) / L2, 0, 1)
    d2 = (xs - (x0 + t * dx)) ** 2 + (ys - (y0 + t * dy)) ** 2
    img |= d2 <= r * r
def ellipse(img, c, rx, ry, ang=0):
    ys, xs = np.mgrid[0:H, 0:W]
    x, y = xs - c[0], ys - c[1]
    ca, sa = math.cos(ang), math.sin(ang)
    u, v = x * ca + y * sa, -x * sa + y * ca
    img |= (u / rx) ** 2 + (v / ry) ** 2 <= 1
def pol(p, ang, l):                     # point from p at angle (deg, 0 = down, + = clockwise on screen)
    return (p[0] + l * math.sin(math.radians(ang)), p[1] + l * math.cos(math.radians(ang)))

def pose(hip_x, lean, l_up, l_fore, r_up, r_fore, l_thigh, l_shin, r_thigh, r_shin, hair):
    """angles are absolute: 0 = down, 90 = screen right, 180 = up, 270 = screen left"""
    img = np.zeros((H, W), bool)
    hip = (hip_x, 126)
    shoulder = pol(hip, 180 + lean, 56)
    neck = pol(shoulder, 180 + lean, 10)
    head = pol(neck, 180 + lean, 19)
    capsule(img, hip, shoulder, 11)
    ellipse(img, ((hip[0] + shoulder[0]) / 2, (hip[1] + shoulder[1]) / 2), 9, 28, -math.radians(lean))
    ellipse(img, hip, 21, 13)                     # hips
    ellipse(img, shoulder, 24, 9)                 # shoulders
    capsule(img, neck, shoulder, 6)
    ellipse(img, head, 15, 17)
    ellipse(img, (head[0] + hair[0], head[1] + hair[1]), 9, 20, hair[2])   # ponytail
    for side, up, fore in ((-1, l_up, l_fore), (1, r_up, r_fore)):
        sh = (shoulder[0] + side * 19, shoulder[1] + 1)
        el = pol(sh, up, 36); ha = pol(el, fore, 34)
        capsule(img, sh, el, 7); capsule(img, el, ha, 6); ellipse(img, ha, 7, 7)
    for side, th, sn in ((-1, l_thigh, l_shin), (1, r_thigh, r_shin)):
        hp = (hip[0] + side * 10, hip[1] + 6)
        kn = pol(hp, th, 44); ft = pol(kn, sn, 42)
        capsule(img, hp, kn, 10); capsule(img, kn, ft, 7); ellipse(img, (ft[0], ft[1] + 2), 10, 5)
    return img

POSES = [
    # hips out to the left, right arm straight up, left arm out, weight on the left leg
    pose(100, 10, l_up=250, l_fore=215, r_up=150, r_fore=175, l_thigh=350, l_shin=0, r_thigh=30, r_shin=350, hair=(-16, -2, 0.5)),
    # both arms up in a V, legs apart
    pose(96, -3,  l_up=225, l_fore=200, r_up=135, r_fore=160, l_thigh=335, l_shin=350, r_thigh=25, r_shin=10, hair=(14, 2, -0.5)),
]
def cells(img):
    g = img.reshape(22, 10, 24, 8).mean(axis=(1, 3))
    return g >= 0.45
out = []
for k, img in enumerate(POSES):
    m = cells(img)
    for r in range(22):
        print("".join("#" if v else "." for v in m[r]) + "   " + "".join("#" if v else "." for v in m[r][::-1]))
    print()
    b = []
    for r in range(22):
        for byte in range(3):
            v = 0
            for bit in range(8):
                if m[r][byte * 8 + bit]: v |= 1 << bit
            b.append(v)
    out.append(f"dancer{k}:")
    for i in range(0, 66, 22):
        out.append("        db     " + ",".join("0%02xh" % v for v in b[i:i + 22]))
if len(sys.argv) > 1:
    # one file per pose (they live in different pages of bank A)
    for k in range(len(POSES)):
        open(f"dancer{k}.inc", "w").write("\n".join(out[k * 4:k * 4 + 4]) + "\n")
