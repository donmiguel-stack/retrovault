// Generated: manual scans (archive.org odysseymanuals), history (Wikipedia),
// gameplay videos (YouTube), and per-game input style for the controls box.
window.GAMEPAGES_DATA = {
 "am_demo_sota": {
   "input": "joystick",
   "video": {
     "id": "D0scuIFp9nQ",
     "title": "State of the Art by Spaceballs - Amiga Demo"
   },
   "history": {
     "text": "Spaceballs' trackmo, first in the Amiga demo competition at The Party 1992. It is built around vector-drawn silhouettes of dancing figures — produced by rotoscoping filmed footage frame by frame — cut to a eurotechno track by Travolta, rather than around a sequence of coder effects. It is routinely credited with moving Amiga demos toward design and presentation aimed at a general audience, and was divisive on release for exactly that reason.",
     "source": "https://demozoo.org/productions/2/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_enigma": {
   "input": "joystick",
   "video": {
     "id": "iGpU3DicbLQ",
     "title": "Phenomena - Enigma - Amiga Demo (HD 50fps)"
   },
   "history": {
     "text": "Phenomena's 1991 demo, first in the Amiga demo competition at the Anarchy Easter Conference. It is known for raytraced and 3D sequences running on a stock 512 KB A500 — a precalculated fractal animation, a vector-world flyby and the much-remembered “TV box” effect — at a point when such imagery on a 7 MHz 68000 was unusual. The Firefox and Tip soundtrack is one of the most frequently cited Amiga module scores and is often listened to on its own.",
     "source": "https://demozoo.org/productions/143/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_mentalhangover": {
   "input": "joystick",
   "video": {
     "id": "4Pm7H-NKZb4",
     "title": "SCOOPEX 1990 MENTAL HANGOVER (A500/GBA1000)"
   },
   "history": {
     "text": "Scoopex's 1990 production, first in the Amiga demo competition at the Swedish Elite Easter Conference. It loads from disk as one continuous scripted piece rather than as a menu of separate megademo parts, and is widely credited in the scene as the release that established the trackmo format. It is remembered technically for its vector work, and for Uncle Tom's module “Madness Took Me”.",
     "source": "https://demozoo.org/productions/22186/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_interference": {
   "input": "joystick",
   "video": {
     "id": "2-JCap86Zn4",
     "title": "Interference (Sanity, 1993, Amiga ECS) HQ"
   },
   "history": {
     "text": "A 1993 Sanity one-file demo that packs a full effect set into a single loadable file: a music-synchronised dot tunnel, rotating raster bars and Wolfenstein-style texture-mapped walls, an early instance of that technique on OCS/ECS. Virgill's module is regularly named among the best Amiga soundtracks. Unlike most of this shelf it was not a party release.",
     "source": "https://demozoo.org/productions/8991/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_arte": {
   "input": "joystick",
   "video": {
     "id": "p9qPBYdXJKs",
     "title": "Arte by Sanity - Amiga Demo HD"
   },
   "history": {
     "text": "Sanity's single-disk trackmo, third in the Amiga demo competition at The Party 1993. Its best-known effect is a texture-mapped rotating sphere, alongside other 3D work considered advanced for stock OCS/ECS hardware at the time. Ra's stylised graphics and Moby's syncopated soundtrack are the elements most often singled out, and the demo has held a higher long-term standing than its competition placing.",
     "source": "https://demozoo.org/productions/5784/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_globaltrash": {
   "input": "joystick",
   "video": {
     "id": "o96I_UfSdIU",
     "title": "The Silents - Global Trash - Amiga Demo (HD 50fps)"
   },
   "history": {
     "text": "The Silents' 1991 demo, first in the Amiga demo competition at the Amiga Summit Convention — a design-led production that won over technically stronger entries. It is notable for a one-pixel plasma routine and early light-sourced “rubber” vectors, and for a soundtrack by Jesper Kyd, who later scored Hitman and Assassin's Creed. It opens with a looped-sample bootloader trick that plays audio before the demo proper starts.",
     "source": "https://demozoo.org/productions/710/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_voyage": {
   "input": "joystick",
   "video": {
     "id": "YMFBAOjuMWw",
     "title": "Razor 1911 - Voyage - Amiga Demo (HD 50fps)"
   },
   "history": {
     "text": "Razor 1911's trackmo, third in the Amiga demo competition at The Party 1991 behind Alcatraz's Odyssey and Hardwired. It is known for texture mapping and 3D routines on a stock A500, including a much-remembered running figure inside a wireframe cube, and for two well-travelled modules — “Undersea” by Codex and “Overload” by Tip and Mantronix. It also carries a good deal of BBS advertising, a trace of Razor 1911's warez-scene origins.",
     "source": "https://demozoo.org/productions/1914/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "am_demo_rinkadink": {
   "input": "joystick",
   "video": {
     "id": "CpR4TgCbkcU",
     "title": "LEMON. 2013 RINK A DINK REDUX (FINAL) (A500/A600)"
   },
   "history": {
     "text": "Lemon.'s complete recode and expansion of their own 1993 demo Rink a Dink, first in the oldskool demo competition at Revision 2013. It runs on an unexpanded 512 KB A500 with plain OCS/ECS and adds seven effects the original did not have — glenz vectors, light-sourced bars, “no AGA” bars, circles, dots, spacecut vectors and RGB balls — at roughly twice the length. Proof that the 1980s machine is still being written for.",
     "source": "https://demozoo.org/productions/59657/"
   },
   "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. Give it a moment &mdash; demos load their first part from disk before anything appears. <span class='kbd'>F5</span> starts it over."
 },
 "c64_demo_dutchbreeze": {
   "input": "keyboard",
   "video": {
     "id": "PUbbYDUIFbc",
     "title": "Commodore 64 demo: Black Mail - Dutch Breeze (1991)"
   },
   "history": {
     "text": "Black Mail's 1991 demo, first in the C64 demo competition at the Silicon Limited Winter Party. It is usually described as a turning point in C64 demo design, moving the emphasis from raw effects toward art direction. Its reputation rests on Hein's pixel graphics and on a soundtrack from three of the best-known Dutch SID composers — Jeroen Tel, Reyn Ouwehand and Falco Paul.",
     "source": "https://csdb.dk/release/?id=11584"
   },
   "note": "This is a demo, not a game: it loads and then plays by itself, with nothing to control. It runs from side&nbsp;1 of the original multi-side release and will ask for the next side when it reaches that point &mdash; the Download button gives the complete set. Loading is slower here than for the games on this shelf, on purpose: demos use their own custom disk loaders, so the Vault switches true 1541 drive emulation on for them instead of the fast virtual-device load."
 },
 "c64_demo_deusexmachina": {
   "input": "keyboard",
   "video": {
     "id": "tWtOS5CN4fI",
     "title": "C64 - Demo - Deus Ex Machina by Crest, Oxyron (2000) With Original Sid 6581R4AR"
   },
   "history": {
     "text": "A joint Crest and Oxyron production, first in the C64 demo competition at Mekka & Symposium 2000. It is regarded as a landmark for C64 art direction, where the visual design and pacing matter as much as the individual effects, and its soundtrack — split across Drax, Jeff and MSK — is routinely named among the best on the platform. It is commonly cited as the template for the design-driven C64 demos that followed.",
     "source": "https://csdb.dk/release/?id=11585"
   },
   "note": "This is a demo, not a game: it loads and then plays by itself, with nothing to control. It runs from side&nbsp;1 of the original multi-side release and will ask for the next side when it reaches that point &mdash; the Download button gives the complete set. Loading is slower here than for the games on this shelf, on purpose: demos use their own custom disk loaders, so the Vault switches true 1541 drive emulation on for them instead of the fast virtual-device load."
 },
 "c64_demo_royalarte": {
   "input": "keyboard",
   "video": {
     "id": "oYPxSPpWUdk",
     "title": "C64 Demo - Royal Arte [2001] by Booze Design"
   },
   "history": {
     "text": "Booze Design's 2001 demo, first in the C64 demo competition at Mekka & Symposium 2001. It is known for its extra-large IFLI pictures and a “wobbling picture” distortion effect that commenters still describe as unbeaten on the platform, across a long sequence of parts with a soundtrack from six composers. The disk here is the later “Royal Arte 100%” release from November 2001, which fixed loading problems the original had on some drives.",
     "source": "https://csdb.dk/release/?id=11619"
   },
   "note": "This is a demo, not a game: it loads and then plays by itself, with nothing to control. It runs from side&nbsp;1 of the original multi-side release and will ask for the next side when it reaches that point &mdash; the Download button gives the complete set. Loading is slower here than for the games on this shelf, on purpose: demos use their own custom disk loaders, so the Vault switches true 1541 drive emulation on for them instead of the fast virtual-device load."
 },
 "c64_demo_wonderland12": {
   "input": "keyboard",
   "video": {
     "id": "jX0UgvgBuQc",
     "title": "Censor Design - Wonderland XII - Real C64, 8580 SID"
   },
   "history": {
     "text": "Censor Design's three-disk, roughly twenty-minute production, first in the C64 demo competition at Baroque Floppy People 2013. It is built around the group's colour-attribute cycling technique, with a fractal zoomer, vector cubes, metaballs and a rotating scroller among its parts. Its finale plays 16 kHz digitised audio while simultaneously running a full-screen upscroller, an unusually demanding combination on C64 hardware.",
     "source": "https://csdb.dk/release/?id=120907"
   },
   "note": "This is a demo, not a game: it loads and then plays by itself, with nothing to control. It runs from side&nbsp;1 of the original multi-side release and will ask for the next side when it reaches that point &mdash; the Download button gives the complete set. Loading is slower here than for the games on this shelf, on purpose: demos use their own custom disk loaders, so the Vault switches true 1541 drive emulation on for them instead of the fast virtual-device load."
 },

 "new_amok_alt": {
  "input": "joystick",
  "history": {
   "text": "An alternate dump of John Dondzila's Amok!, the 1998 Berzerk port that was the first homebrew ever written for this console.",
   "source": "odyssey2.info",
   "url": "https://odyssey2.info/faq/essentials/"
  },
  "video": {
   "id": "ZW72o6CCLps",
   "title": "Amok   ~ Magnavox Odyssey 2"
  }
 },
 "new_amok": {
  "input": "joystick",
  "video": {
   "id": "BME16m-BDG0",
   "title": "AMOK! (Magnavox Odyssey 2/Philips Videopac G7000). Score: 610."
  },
  "history": {
   "text": "John Dondzila's port of Stern's Berzerk, released in 1998 - the first homebrew game ever written for this console, about fifteen years after Philips stopped supporting it. Dondzila is better known for his Vectrex work, and had already put out a 56-game Odyssey2 multicart in 1996.",
   "source": "odyssey2.info",
   "url": "https://odyssey2.info/faq/essentials/"
  }
 },
 "new_bird-hunt": {
  "input": "joystick",
  "keys": "j2arrows",
  "manual": {
   "text": "<h3>Playing</h3><p>Move the crosshair with the joystick and press fire to shoot, letting the fire button go between shots. Three birds appear in each round, one at a time, each on a different flight path, and you have five bullets to spend on them. A bird you hit drops out of the sky; a miss shows a short white flash where the shot went. The five yellow bullets in the top right are your ammunition — each shot takes one away, and all five come back at the start of the next round.</p><p>Every round, the first one included, opens with a two-second pause, then a buzz as the start signal, then one more second. From the second round on, that sequence begins only once the round tune has finished. The crosshair still moves while you wait, but shooting is disabled. Fire used to leave the title screen, or to resume a paused game, counts as an input rather than a shot and costs no ammunition.</p><h3>Scoring</h3><p>The total is brought up to date once all three birds in a round have finished:</p><table><tr><th>Birds hit</th><th>Result</th></tr><tr><td>0</td><td>Total halved, rounded down, and the alarm sounds</td></tr><tr><td>1</td><td>+1 point</td></tr><tr><td>2</td><td>+5 points</td></tr><tr><td>3</td><td>+10 points, plus 5 points for every bullet still unused</td></tr></table><p><strong>A perfect round is three hits with two bullets left.</strong> The first one awards 20 points, and consecutive perfect rounds double it — 40, 80, 160, 320 and on up. Any round that is not perfect breaks the streak, and the next perfect round starts again at 20. The 16-bit total saturates at 65,535. Three hits play the happy tune once; a perfect round plays it three times.</p><p>If a zero-hit round halves the score to zero, that is the end: the alarm sounds, two seconds pass, and the title screen returns.</p><h3>Pausing</h3><p>Any key on the console keyboard pauses the game. Bird movement, round timers and animation all stop while it is paused. Fire starts it again without spending a shot; let fire go before you shoot. A key held down does not pause the game a second time after it resumes — lift it and press again.</p><h3>What you see</h3><p>On a G7400 the cartridge uses the Plus graphics layer twice over: a dawn landscape on the title screen, carrying <em>AHNL66's BIRD HUNT</em> and <em>PRESS FIRE</em>, and then a separate landscape during play with a tree, shrubs and grass. On a G7000, or any console it does not recognise, you get the original black Videopac title screen and the raster-timed blue sky over green grass. The Vault boots Videopac titles with the G7400 BIOS, so the Plus version is what you see here.</p>",
   "source": "the game’s own README",
   "url": "https://github.com/Ahnl66/BIRD-HUNT#gameplay"
  },
  "note": "Aim with the <span class='kbd'>arrow keys</span>, fire with the backtick key <span class='kbd'>&#96;</span> (left hand, top-left of the keyboard). This cartridge reads <strong>joystick&nbsp;2</strong> and also watches the console keyboard, so the Vault remaps joystick 2 onto those keys on this page only. That is also why fire is not on the usual <span class='kbd'>G</span>: the game scans all six rows of the console keyboard and pauses on any key it finds down, without checking which one — and <span class='kbd'>G</span>, every other letter, <span class='kbd'>Space</span>, <span class='kbd'>.</span>, <span class='kbd'>/</span>, <span class='kbd'>-</span> and <span class='kbd'>=</span> are all real keys on that keyboard, so they freeze the crosshair instead of moving it. Let fire go between shots — only a fresh press counts. How a round runs and how the scoring works is in the Manual below, in the author's own words. If you are on a copy of the Vault downloaded before 19 September 2026 and the arrow keys do nothing here, download the Vault again — this control fix lives in the emulator, which the in-app Update deliberately never replaces.",
  "video": {
   "id": "GbsQa3yT3MQ",
   "title": "Bird Hunt — a brand new Videopac homebrew"
  },
  "history": {
   "text": "A 2026 homebrew written from scratch in Intel 8048 assembly and published on GitHub by Ahnl66 — source, build file and the author's own emulator test harness included, under the working title ArtGame that the test names still carry. Version 1.0.0, released 23 September 2026, added a Plus title screen: on a G7400 the game opens on a dawn landscape instead of the plain black Videopac title, and brought with it a streak bonus for consecutive perfect rounds. It is built to run on the real console from a PicoPac cartridge, and it knows which machine it is on — a G7400 is recognised by two opcode signatures in its Plus BIOS, and anything else falls back to blue sky over green grass. The cartridge is four standard 2 KB banks, the game itself in the last one and a slice of the background art plus a copy of the loader in each of the other three.",
   "source": "the game’s own repository",
   "url": "https://github.com/Ahnl66/BIRD-HUNT"
  }
 },
 "new_le-sprint": {
  "input": "joystick",
  "note": "Two players, no computer opponent. At <strong>SELECT GAME</strong> press <span class='kbd'>1</span>. The <strong>red runner</strong> (player&nbsp;1) is on joystick&nbsp;2: run with <span class='kbd'>A</span> and <span class='kbd'>D</span>, fire is <span class='kbd'>Q</span>. The <strong>green runner</strong> (player&nbsp;2) is on joystick&nbsp;1: run with <span class='kbd'>&larr;</span> and <span class='kbd'>&rarr;</span>, fire is <span class='kbd'>G</span>. It is the switching that counts, not holding a direction — left, right, left, right, as fast as you can. When both runners are over the line, each player presses fire once (not necessarily together) for the next race. The best time sits in the lower right corner: beat it and your runner jumps for joy at the finish line. It lasts until you reset or switch off.",
  "manual": {
   "text": "<h3>How to play</h3><ol><li>Wait for the yellow <strong>3, 2, 1</strong> countdown and the starting sound.</li><li>Player 1 controls the <strong>red runner</strong>; player 2 controls the <strong>green runner</strong>.</li><li>Alternate <strong>left and right</strong> on your joystick to move toward the finish line. The faster you alternate, the faster your runner moves.</li><li>Each runner's finish time appears beside their lane.</li><li>Once both runners have finished, press the fire button on <strong>each controller</strong> to start another race. The presses do not need to be simultaneous.</li></ol><p>Timing uses PAL frames, with hundredths advancing in steps of two. The clock at the top counts whole seconds while the race is on.</p><h3>Best time</h3><p>The lower right corner shows the best time, <strong>BEST 6.28</strong>, the record set at Skrolli Party 2026. Beat it and your runner jumps for joy at the finish line while NEW and BEST flash; your time then stays in the corner, in your runner’s colour, until the console is reset or switched off. A tie does not count.</p><h3>On a Videopac+ G7400</h3><p>The race runs in a full stadium: a crowd in the stands, an advertising board, white lane lines and a green infield. On every console a race official fires his starting pistol when the countdown reaches zero.</p>",
   "source": "the game’s own README",
   "url": "https://github.com/kuoris-dev/Le-Sprint#how-to-play"
  },
  "history": {
   "text": "A 2026 homebrew for the Philips Videopac G7000 by kuoris-dev, written in Intel 8048 assembly and released at Skrolli Party 2026, the party run by the Finnish computer-culture magazine Skrolli. Source, hardware definitions and the assembled 2 KB cartridge image are all on GitHub under the MIT licence. It is a joystick-waggler in the spirit of the arcade track-and-field games, cut down to the bone: two runners, one finish line, a stopwatch, and no computer to race against. Retro Vault made a contribution for the G7400 edition, creating the stadium and race official with starting pistol. The record to beat, 6.28, was set at the party on a €3 AliExpress joystick.",
   "source": "the game’s own repository",
   "url": "https://github.com/kuoris-dev/Le-Sprint"
  },
  "video": {
   "id": "ZjfWBOYVORM",
   "title": "Le Sprint on the Videopac G7400 — a full stadium for a brand new homebrew"
  },
  "record": {
   "label": "100 m record",
   "time": "6.28",
   "holder": "Skrolli Party",
   "hardware": "€3 AliExpress joystick",
   "send": "mailto:hq@retrovault.world?subject=Le%20Sprint%20record&body=My%20time%3A%20%0AName%3A%20%0AVideo%20link%3A%20%0A%0A(please%20show%20your%20hands%20and%20the%20screen)"
  }
 },
 "new_calculator": {
  "input": "keyboard"
 },
 "new_helicopter_buzzword": {
  "input": "keyboard"
 },
 "new_jg-munchkin": {
  "input": "joystick",
  "manual": {
   "item": "munchkin-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Munchkin (EUR)(Philips Videopac)(1982)"
  },
  "video": {
   "id": "AdQtjP8ZvKk",
   "title": "2909 - J.G. Munchkin! - Odyssey² [MAME]"
  }
 },
 "new_kc-pacvid": {
  "input": "joystick",
  "video": {
   "id": "SbwtsNq2Ves",
   "title": "KC Pacman!"
  },
  "history": {
   "text": "A modified K.C. Munchkin — the game Atari sued Philips over and won, reworked years later by someone who thought the original had the better idea.",
   "source": "the uploader's notes",
   "url": "https://www.youtube.com/watch?v=SbwtsNq2Ves"
  }
 },
 "new_kc-pacman": {
  "input": "joystick",
  "video": {
   "id": "SbwtsNq2Ves",
   "title": "KC Pacman!"
  },
  "history": {
   "text": "A modified K.C. Munchkin — the game Atari sued Philips over and won, reworked years later by someone who thought the original had the better idea.",
   "source": "the uploader's notes",
   "url": "https://www.youtube.com/watch?v=SbwtsNq2Ves"
  }
 },
 "new_ktaa": {
  "input": "joystick",
  "video": {
   "id": "JVyY_IKZic4",
   "title": "Kill the Attacking Aliens (Odyssey2 /Videopac-emu) 3.551"
  },
  "history": {
   "text": "Written by Soeren Gust and released in 2003 under the Xype label, and one of the first homebrews to use the G7400's Plus graphics. It is regularly named among the best games on the machine, official releases included.",
   "source": "odyssey2.info",
   "url": "https://odyssey2.info/db/game/kill-the-attacking-aliens-499"
  }
 },
 "new_ktaa-demo1": {
  "input": "joystick",
  "video": {
   "id": "76nRGYCSN8A",
   "title": "Kill the Attacking Aliens - Odyssey2"
  },
  "history": {
   "text": "An early demo build of Soeren Gust's Kill the Attacking Aliens, the 2003 Xype release that was among the first homebrews to use the G7400's Plus graphics.",
   "source": "odyssey2.info",
   "url": "https://odyssey2.info/db/game/kill-the-attacking-aliens-499"
  }
 },
 "new_ktaa-demo2": {
  "input": "joystick",
  "video": {
   "id": "tLGv7NPtzh8",
   "title": "Kill The Attacking Aliens • Odyssey²"
  },
  "history": {
   "text": "An early demo build of Soeren Gust's Kill the Attacking Aliens, the 2003 Xype release that was among the first homebrews to use the G7400's Plus graphics.",
   "source": "odyssey2.info",
   "url": "https://odyssey2.info/db/game/kill-the-attacking-aliens-499"
  }
 },
 "new_mrroboto": {
  "input": "joystick",
  "video": {
   "id": "Krpz3WMevHs",
   "title": "Mr  Roboto! USA  Magnavox Odyssey 2 HYPERSPIN NOT MINE VIDEOSUnl VIDEOPAC PHILIPS VIDEOPAC"
  },
  "history": {
   "text": "Ted Foolery packed three game screens, an intro and a menu into eight kilobytes, playable by one, two or nobody at all, with Voice support and a hidden puzzle that ran as a competition on his site. Packrat Video Games later sold it as a cartridge with a printed manual.",
   "source": "tedfoolery.com",
   "url": "http://www.tedfoolery.com/RetroGeek/Odyssey2.php"
  }
 },
 "new_planet-lander": {
  "input": "joystick",
  "video": {
   "id": "UxjNbFDAO-g",
   "title": "Planet Lander - Philips Magnavox Odyssey2"
  },
  "history": {
   "text": "Ted Foolery's lunar-lander game, deliberately squeezed under the two-kilobyte limit the earliest cartridges worked to, but with multiple screens, randomly generated landscapes and difficulty that climbs as you go.",
   "source": "tedfoolery.com",
   "url": "http://www.tedfoolery.com/RetroGeek/Odyssey2.php"
  }
 },
 "new_pong_all": {
  "input": "joystick",
  "history": {
   "text": "It took this console more than thirty years to get a version of Pong. Rene van den Enden wrote it in 2004, with eleven variations from squash and tennis to the 1972 original. Several of them are Voice-enhanced: with the cartridge plugged in through The Voice you get spoken comments as balls are hit and missed.",
   "source": "Ozyr's Odyssey2 Archive",
   "url": "https://www.ozyr.com/o2/o2pong.html"
  },
  "video": {
   "id": "7jGNjcCJS-c",
   "title": "Pong 2003 USA  Magnavox Odyssey 2 Unl VIDEOPAC PHILIPS VIDEOPAC HYPERSPIN"
  }
 },
 "new_pong": {
  "input": "joystick",
  "history": {
   "text": "It took this console more than thirty years to get a version of Pong. Rene van den Enden wrote it in 2004, with eleven variations from squash and tennis to the 1972 original. Several of them are Voice-enhanced: with the cartridge plugged in through The Voice you get spoken comments as balls are hit and missed.",
   "source": "Ozyr's Odyssey2 Archive",
   "url": "https://www.ozyr.com/o2/o2pong.html"
  },
  "video": {
   "id": "7jGNjcCJS-c",
   "title": "Pong 2003 USA  Magnavox Odyssey 2 Unl VIDEOPAC PHILIPS VIDEOPAC HYPERSPIN"
  }
 },
 "new_puzzle-piece-panic": {
  "input": "joystick",
  "video": {
   "id": "9OLJIE2Aq9k",
   "title": "Puzzle Piece Panic! for the Odyssey 2!"
  },
  "history": {
   "text": "Ted Foolery's falling-block game: four variations, polyphonic music and enhanced graphics on a G7400. The music is the interesting part - on the real cartridge it plays through The Voice module, which is why a separate build exists for emulators.",
   "source": "tedfoolery.com",
   "url": "http://www.tedfoolery.com/RetroGeek/Odyssey2.php"
  }
 },
 "new_ppp-o2em": {
  "input": "joystick",
  "video": {
   "id": "9OLJIE2Aq9k",
   "title": "Puzzle Piece Panic! for the Odyssey 2!"
  },
  "history": {
   "text": "Ted Foolery's falling-block game: four variations, polyphonic music and enhanced graphics on a G7400. The music is the interesting part - on the real cartridge it plays through The Voice module, which is why a separate build exists for emulators. This is that emulator build.",
   "source": "tedfoolery.com",
   "url": "http://www.tedfoolery.com/RetroGeek/Odyssey2.php"
  }
 },
 "new_route66": {
  "input": "joystick",
  "history": {
   "text": "A vertical-scrolling racer by Rafael Cardoso and Rene van den Enden, first released in 2007 as Videopac 66. The pair kept working on it and added high-resolution backgrounds for Plus machines; the later Route 66+ also supports The Voice. Four levels - day, night, desert and snow - with seven black cars to destroy in each, and a hundred cartridges were made.",
   "source": "Classic Consoles Center",
   "url": "http://www.classic-consoles-center.at/videopac/route-66-introduction"
  },
  "video": {
   "id": "GY389TGiyNw",
   "title": "Route 66 Europe  Magnavox Odyssey 2 HYPERSPIN NOT MINE VIDEOSProto VIDEOPAC PHILIPS VIDEOPAC"
  }
 },
 "new_teletext": {
  "vaultCart": "teletext-vault.bin",
  "shots": {
   "title": "Page 400 and the build manual, pages 406-414",
   "pages": [400, 406, 407, 408, 409, 410, 411, 412, 413, 414],
   "file": "shot_new_teletext_{lang}_{page}.png",
   "langs": ["en", "nl"]
  },
  "input": "keyboard",
  "note": "A real 2 KB cartridge, written for the Vault: it boots to <strong>SELECT GAME</strong> like any Videopac cart. Press <span class='kbd'>1</span> and the teletext screen comes up - live NOS Teletekst, drawn the way the G7400's EF9340/EF9341 video chips would draw it: 40 × 24 cells, eight colours, 2 × 3 block graphics. Type a page number (<span class='kbd'>101</span> news, <span class='kbd'>601</span> sport, <span class='kbd'>702</span> weather) or <span class='kbd'>400</span> for the Vault's own pages; <span class='kbd'>F5</span> goes back to SELECT GAME. On real hardware the cartridge would fetch the pages over WiFi itself - the manual below is the plan for building that, and it is also on teletext pages <span class='kbd'>406</span>-<span class='kbd'>414</span>, one step per page.",
  "manual": {
   "text": "<p>The teletext screen this cartridge opens in the Vault is the simulation. This is the full plan for the real thing: a cartridge that puts a Videopac G7400 on WiFi and shows live teletext on the TV, with no PC in between. Nobody has built it yet. Each half has been proven separately, though: <a href=\"https://github.com/aotta/PicoPAC\" target=\"_blank\" rel=\"noopener\">PicoPAC</a> shows that a Raspberry Pi Pico can stand in for a Videopac cartridge (tested on the G7000 and G7400), and the P2000T cartridge shows that a WiFi chip on the cartridge port is enough to bring teletext to a 1981 Philips.</p> \n<h3>A shortcut: FujiNet for the Odyssey 2</h3> \n<p><a href=\"https://forums.atariage.com/topic/392582-fujinet-for-odyssey2-bring-up-thread/\" target=\"_blank\" rel=\"noopener\">FujiNet</a>, the open-source WiFi adapter for 8-bit computers, is being brought to the Odyssey 2 / Videopac. Its cartridge is also a PicoPAC fork, and it talks to the console exactly the way this plan does: MOVX writes in, ROM reads out. It pairs the Pico cartridge with a separate ESP32-S3 for the network, and as of October 2026 it runs in an emulator only (<a href=\"https://github.com/FujiNetWIFI/fujinet-firmware/tree/master/pico/o2\" target=\"_blank\" rel=\"noopener\">source code</a>). Once it works on real hardware, teletext could simply be a G7400 program for FujiNet: its network layer fetches the pages from the Vault's relay, and the EF9340 drawing code below puts them on screen, with no new board needed. The steps below remain the plan for a stand-alone cartridge.</p> \n<h3>1. How it fits together</h3> \n<ol class=\"tt-flow\"> \n<li><b>WiFi</b> → a <b>Raspberry Pi Pico 2 W</b> on the cartridge fetches a page from the Vault's relay and converts it into EF9340 character and attribute codes.</li> \n<li>The same Pico pretends to be a <b>2 KB cartridge ROM</b>. The program in that ROM is a small teletext client for the G7400's 8048 CPU.</li> \n<li>The client asks the cartridge for a page, reads it back through the ROM, and copies it into the <b>EF9340/EF9341</b> video chips.</li> \n<li>The TV shows it, 40 × 24 plus a header row: the same grid you see above.</li> \n</ol> \n<h3>2. Parts</h3> \n<table class=\"tt-table\"> \n<tr><th>Part</th><th>Qty</th><th>Why</th></tr> \n<tr><td>Raspberry Pi Pico 2 W (RP2350 + CYW43439 WiFi)</td><td>1</td><td>CPU, bus logic and 2.4 GHz WiFi on one board. Unlike the RP2040, the RP2350's GPIOs are 5 V tolerant, so it can sit on the console's 5 V bus.</td></tr> \n<tr><td>Cartridge PCB with the 30-contact Videopac edge</td><td>1</td><td>Start from PicoPAC's KiCad files (CC BY-SA) and move the Pico footprint to a Pico 2 W. Order from JLCPCB or PCBWay.</td></tr> \n<tr><td>Schottky diode (1N5817 or BAT54)</td><td>1</td><td>Feeds the console's +5 V into the Pico's VSYS without back-feeding a USB cable that is plugged in at the same time.</td></tr> \n<tr><td>100 nF ceramic capacitor</td><td>2</td><td>Decoupling at VSYS and 3V3.</td></tr> \n<tr><td>Push button</td><td>1</td><td>Reset / BOOTSEL, as on PicoPAC.</td></tr> \n<tr><td>3D-printed shell</td><td>1</td><td>PicoPAC's STL files, or the PicoPAC case on Thingiverse.</td></tr> \n</table> \n<p>About €15–25 in parts plus the PCB order.</p> \n<h3>3. The cartridge port</h3> \n<p>30 contacts, two rows of 15. Names as used in PicoPAC's connector symbol. <b>Check every contact with a multimeter against a real cartridge before you solder.</b></p> \n<table class=\"tt-table tt-pins\"> \n<tr><th>Pin</th><th>Signal</th><th>Pin</th><th>Signal</th></tr> \n<tr><td>1</td><td>T0</td><td>A</td><td>/WR</td></tr> \n<tr><td>2–9</td><td>B0–B7 (data bus)</td><td>B, C</td><td>GND</td></tr> \n<tr><td>10</td><td>A10</td><td>D</td><td>+5 V</td></tr> \n<tr><td>11</td><td>CS (P14, \"external RAM enable\")</td><td>E</td><td>/CS</td></tr> \n<tr><td>12</td><td>P11 (bank select)</td><td>F</td><td>/PSEN (program read)</td></tr> \n<tr><td>13</td><td>P10 (bank select)</td><td>G–M</td><td>A0–A5</td></tr> \n<tr><td>14</td><td>A11</td><td>N, P</td><td>A7, A6</td></tr> \n<tr><td>15</td><td>A9</td><td>R</td><td>A8</td></tr> \n</table> \n<h3>4. Wiring the Pico 2 W</h3> \n<p>The Pico 2 W has fewer free pins than the Pico clone PicoPAC uses: GP23–25 drive the WiFi chip, and GP26–28 are analog pins that are <b>not</b> 5 V tolerant. Everything on the 5 V bus therefore goes on GP0–GP22, which is exactly enough for a 2 KB cartridge:</p> \n<table class=\"tt-table\"> \n<tr><th>Pico</th><th>Cartridge</th><th>Note</th></tr> \n<tr><td>GP0–GP10</td><td>A0–A10</td><td>11 address lines, enough for a 2 KB image</td></tr> \n<tr><td>GP11–GP18</td><td>B0–B7</td><td>kept together so one masked write puts a whole byte on the bus</td></tr> \n<tr><td>GP19</td><td>/PSEN</td><td>low = the 8048 is reading program memory</td></tr> \n<tr><td>GP20</td><td>/WR</td><td>low = a MOVX write</td></tr> \n<tr><td>GP21</td><td>CS (P14)</td><td>low = the write is meant for external RAM, which includes us</td></tr> \n<tr><td>GP22</td><td>P10</td><td>optional; a 2 KB client needs no bank switching</td></tr> \n<tr><td>VSYS (pin 39)</td><td>+5 V via the diode</td><td></td></tr> \n<tr><td>GND</td><td>B, C</td><td></td></tr> \n</table> \n<p>A11, P11, T0 and /CS stay unconnected. The Pico drives B0–B7 <b>only while /PSEN is low</b> and floats them otherwise, so it never fights the 8048 or the console's own RAM. Its 3.3 V high level is above the 8048's TTL input threshold. Want to use the older Pico W (RP2040) instead? Its pins are not 5 V tolerant, so put 74LVC245 buffers in between: one for the data bus, with its direction taken from /PSEN, and two for the address and control lines. PicoPAC connects an RP2040 straight to the bus and is reported to work, but that is outside the chip's specification.</p> \n<h3>5. Firmware on the Pico (C, Pico SDK)</h3> \n<ul> \n<li><b>Core 0, the bus</b>: one tight loop running from RAM with interrupts off, overclocked to about 250 MHz (PicoPAC runs its RP2040 at 270 MHz). Read all GPIOs at once. If /PSEN is low, put <code>image[address]</code> on B0–B7. If CS and /WR are both low, store the data byte as a command. The 8048's machine cycle is 2.5 µs, so there is plenty of margin, but the loop must never stall. That is why nothing else runs on this core.</li> \n<li><b>Core 1, the network</b>: the CYW43 driver with lwIP and mbedTLS. An HTTPS GET to <code>retrovault.world/teletext/nos.php?p=101</code>. Better still, add a compact <code>&amp;fmt=ef9340</code> answer to the relay that returns the 1,920 bytes ready to copy, so the cartridge doesn't need to parse JSON. Refresh every 60 s and on request. Keep two buffers and swap them only while the console isn't reading.</li> \n<li><b>Settings</b>: the WiFi name and password go in <code>wifi.txt</code> on the Pico's USB drive. PicoPAC already shows up as a USB drive for its ROM files.</li> \n</ul> \n<h3>6. How the console and the cartridge talk</h3> \n<ul> \n<li><b>Console → cartridge</b>: the 8048 sets P14 low (P13 high) and does a MOVX write. On the cartridge this shows up as CS and /WR low, with the address on A0–A7 and the value on B0–B7. PicoPAC's menu uses this trick to tell the cartridge which game you picked. The console's own external RAM receives the same write, which does no harm. <b>Stay within <code>E0–E3</code></b>: The Voice speech module reacts to writes at <code>80–DF</code> and <code>F0–FF</code> (and <code>E4</code>, <code>E8–EF</code>), which is why PicoPAC's own <code>FE</code>/<code>FF</code> handshake garbles with a Voice attached. That lesson comes from FujiNet's Odyssey 2 work (see above). Proposed layout: <code>E0</code> the page's hundreds digit, <code>E1</code> its tens and units (BCD), <code>E2</code> the subpage, <code>E3</code> the command, written last (1 fetch, 2 next, 3 previous, 4 refresh).</li> \n<li><b>Cartridge → console</b>: a MOVX read would collide with the console's RAM on the same bus, so data comes back through the ROM instead. One fixed address in the cartridge image (for example <code>7FF</code>) is a <b>streaming port</b>: every time the 8048 reads it, it returns the next byte of the page. <code>7FE</code> is a status byte: 0 busy, 1 page ready, 2 page does not exist, 3 no WiFi. The 8048 reads both with <code>MOVP A,@A</code>. FujiNet's Odyssey 2 cartridge answers the same way: a page of the ROM window that the cartridge rewrites between transactions.</li> \n</ul> \n<h3>7. The G7400 program (8048, 2 KB)</h3> \n<ul> \n<li>Reuse the EF9340 routines from the Vault's own G7400 homebrew engine: chip setup, cursor, write-with-increment, custom glyphs.</li> \n<li>Input through the BIOS key routine at <code>00B0h</code>: digits build the page number. On the joystick, left/right is the previous/next page, up/down the subpage, and fire goes to 100.</li> \n<li>Fetch: write the request, poll <code>7FE</code>, then stream 24 rows × 40 cells × 2 bytes (character + attribute) into the EF9340. Draw the header row with the page number and status.</li> \n<li>About 2,000 bytes at a few 2.5 µs cycles each comes to roughly 30–60 ms, so a page appears within a few frames.</li> \n<li>NOS already sends every character with its own colour, which matches the EF9340's attribute byte per cell, so no teletext control codes have to be decoded. Block graphics map onto the EF9341's built-in 2 × 3 set. Dutch accents (ë, é) become plain letters or custom glyphs.</li> \n<li>On a G7000 (no EF9340) the program shows \"needs a G7400\" instead of crashing.</li> \n</ul> \n<h3>8. Build and test in this order</h3> \n<ol> \n<li>Build the board and flash PicoPAC's firmware with its pin numbers changed to the table above. If normal games run, the bus wiring is right.</li> \n<li>Serve one fixed teletext page from flash, without WiFi, and get the 8048 client drawing it. Write the client in o2em first with the Vault's headless test harness, extended with a fake cartridge that serves the streaming port.</li> \n<li>Turn on WiFi on core 1 and check that games still run while it is busy: the bus loop must not hiccup.</li> \n<li>Add <code>fmt=ef9340</code> to the relay, then the request channel.</li> \n<li>Put it in the case and test on a G7400, then on a G7000 for the fallback message.</li> \n</ol> \n<h3>9. Watch out for</h3> \n<ul> \n<li><b>Power</b>: the WiFi chip draws peaks of a couple of hundred mA, and the console's 5 V supply was sized for a ROM chip. Measure it. If it's marginal, power the Pico from USB and share only ground.</li> \n<li>Never insert or remove the cartridge with the console switched on.</li> \n<li>PicoPAC's hardware is CC BY-SA. A board based on it keeps that licence and credits the original.</li> \n<li>Go through the relay rather than straight to NOS. Its 60-second cache keeps the load on NOS the same, however many cartridges there are.</li> \n</ul>",
   "text_nl": "<p>Het teletekstscherm dat deze cartridge in de Vault opent is de simulatie. Dit is het volledige plan voor het echte werk: een cartridge die een Videopac G7400 via WiFi live teletekst op de tv laat zien, zonder pc ertussen. Niemand heeft hem nog gebouwd. Beide helften zijn wel al apart bewezen: <a href=\"https://github.com/aotta/PicoPAC\" target=\"_blank\" rel=\"noopener\">PicoPAC</a> laat zien dat een Raspberry Pi Pico een Videopac-cartridge kan nadoen (getest op G7000 en G7400), en de P2000T-cartridge laat zien dat een WiFi-chip op de cartridgepoort genoeg is om teletekst naar een Philips uit 1981 te halen.</p> \n<h3>Een kortere weg: FujiNet voor de Odyssey 2</h3> \n<p><a href=\"https://forums.atariage.com/topic/392582-fujinet-for-odyssey2-bring-up-thread/\" target=\"_blank\" rel=\"noopener\">FujiNet</a>, de opensource WiFi-adapter voor 8-bitcomputers, wordt naar de Odyssey 2 / Videopac gebracht. Ook die cartridge is een afsplitsing van PicoPAC, en hij praat precies zo met de console als in dit plan: MOVX-schrijfacties erin, ROM-leesacties eruit. Naast de Pico-cartridge zit een losse ESP32-S3 voor het netwerk, en in oktober 2026 draait het nog alleen in een emulator (<a href=\"https://github.com/FujiNetWIFI/fujinet-firmware/tree/master/pico/o2\" target=\"_blank\" rel=\"noopener\">broncode</a>). Werkt het eenmaal op echte hardware, dan kan teletekst gewoon een G7400-programma voor FujiNet worden: de netwerklaag haalt de pagina's op bij de doorgeefserver van de Vault en de EF9340-tekencode hieronder zet ze op het scherm, zonder nieuw printje. De stappen hieronder blijven het plan voor een losse cartridge.</p> \n<h3>1. Hoe het in elkaar past</h3> \n<ol class=\"tt-flow\"> \n<li><b>WiFi</b> → een <b>Raspberry Pi Pico 2 W</b> op de cartridge haalt een pagina op bij de doorgeefserver van de Vault en zet die om naar EF9340-teken- en attribuutcodes.</li> \n<li>Dezelfde Pico doet zich voor als een <b>cartridge-ROM van 2 KB</b>. Het programma in die ROM is een kleine teletekst-client voor de 8048-processor van de G7400.</li> \n<li>De client vraagt de cartridge om een pagina, leest die terug via de ROM en kopieert hem naar de videochips <b>EF9340/EF9341</b>.</li> \n<li>De tv toont 40 × 24 plus kopregel: hetzelfde raster als hierboven.</li> \n</ol> \n<h3>2. Onderdelen</h3> \n<table class=\"tt-table\"> \n<tr><th>Onderdeel</th><th>Aantal</th><th>Waarom</th></tr> \n<tr><td>Raspberry Pi Pico 2 W (RP2350 + CYW43439 WiFi)</td><td>1</td><td>Processor, buslogica en 2,4 GHz WiFi op één bordje. Anders dan bij de RP2040 kunnen de pinnen van de RP2350 tegen 5 V, dus hij kan op de 5V-bus van de console.</td></tr> \n<tr><td>Cartridge-printplaat met de Videopac-rand van 30 contacten</td><td>1</td><td>Begin met de KiCad-bestanden van PicoPAC (CC BY-SA) en vervang de Pico-footprint door een Pico 2 W. Bestellen bij JLCPCB of PCBWay.</td></tr> \n<tr><td>Schottky-diode (1N5817 of BAT54)</td><td>1</td><td>Voert de +5 V van de console naar VSYS van de Pico zonder terug te voeden naar een USB-kabel die tegelijk aangesloten is.</td></tr> \n<tr><td>Keramische condensator 100 nF</td><td>2</td><td>Ontkoppeling bij VSYS en 3V3.</td></tr> \n<tr><td>Drukknop</td><td>1</td><td>Reset / BOOTSEL, net als bij PicoPAC.</td></tr> \n<tr><td>3D-geprinte behuizing</td><td>1</td><td>De STL-bestanden van PicoPAC, of de PicoPAC-behuizing op Thingiverse.</td></tr> \n</table> \n<p>Ongeveer € 15–25 aan onderdelen plus de printplaatbestelling.</p> \n<h3>3. De cartridgepoort</h3> \n<p>30 contacten, twee rijen van 15. Namen zoals in het connectorsymbool van PicoPAC. <b>Meet elk contact met een multimeter na tegen een echte cartridge voordat je soldeert.</b></p> \n<table class=\"tt-table tt-pins\"> \n<tr><th>Pin</th><th>Signaal</th><th>Pin</th><th>Signaal</th></tr> \n<tr><td>1</td><td>T0</td><td>A</td><td>/WR</td></tr> \n<tr><td>2–9</td><td>B0–B7 (databus)</td><td>B, C</td><td>GND</td></tr> \n<tr><td>10</td><td>A10</td><td>D</td><td>+5 V</td></tr> \n<tr><td>11</td><td>CS (P14, \"extern RAM aan\")</td><td>E</td><td>/CS</td></tr> \n<tr><td>12</td><td>P11 (bankkeuze)</td><td>F</td><td>/PSEN (programma lezen)</td></tr> \n<tr><td>13</td><td>P10 (bankkeuze)</td><td>G–M</td><td>A0–A5</td></tr> \n<tr><td>14</td><td>A11</td><td>N, P</td><td>A7, A6</td></tr> \n<tr><td>15</td><td>A9</td><td>R</td><td>A8</td></tr> \n</table> \n<h3>4. De Pico 2 W aansluiten</h3> \n<p>De Pico 2 W heeft minder vrije pinnen dan de Pico-kloon van PicoPAC: GP23–25 sturen de WiFi-chip, en GP26–28 zijn analoge pinnen die <b>niet</b> tegen 5 V kunnen. Alles op de 5V-bus gaat dus op GP0–GP22, en dat is precies genoeg voor een cartridge van 2 KB:</p> \n<table class=\"tt-table\"> \n<tr><th>Pico</th><th>Cartridge</th><th>Opmerking</th></tr> \n<tr><td>GP0–GP10</td><td>A0–A10</td><td>11 adreslijnen, genoeg voor 2 KB</td></tr> \n<tr><td>GP11–GP18</td><td>B0–B7</td><td>naast elkaar, zodat één gemaskeerde schrijfactie een hele byte op de bus zet</td></tr> \n<tr><td>GP19</td><td>/PSEN</td><td>laag = de 8048 leest programmageheugen</td></tr> \n<tr><td>GP20</td><td>/WR</td><td>laag = een MOVX-schrijfactie</td></tr> \n<tr><td>GP21</td><td>CS (P14)</td><td>laag = de schrijfactie is voor extern RAM, en dus ook voor ons</td></tr> \n<tr><td>GP22</td><td>P10</td><td>optioneel; een client van 2 KB heeft geen bankwissel nodig</td></tr> \n<tr><td>VSYS (pin 39)</td><td>+5 V via de diode</td><td></td></tr> \n<tr><td>GND</td><td>B, C</td><td></td></tr> \n</table> \n<p>A11, P11, T0 en /CS blijven los. De Pico stuurt B0–B7 <b>alleen aan zolang /PSEN laag is</b> en laat ze verder zweven, zodat hij nooit vecht met de 8048 of het RAM van de console. Zijn 3,3V-hoog ligt boven de TTL-drempel van de 8048. Wil je toch de oudere Pico W (RP2040) gebruiken? Die pinnen kunnen niet tegen 5 V, dus zet er 74LVC245-buffers tussen: één voor de databus, met de richting uit /PSEN, en twee voor de adres- en stuurlijnen. PicoPAC hangt een RP2040 rechtstreeks aan de bus en dat werkt volgens de gebruikers, maar het valt buiten de specificatie van de chip.</p> \n<h3>5. Firmware op de Pico (C, Pico SDK)</h3> \n<ul> \n<li><b>Core 0, de bus</b>: één strakke lus vanuit RAM, zonder interrupts, overgeklokt naar ongeveer 250 MHz (PicoPAC draait zijn RP2040 op 270 MHz). Lees alle pinnen tegelijk. Is /PSEN laag, zet dan <code>image[adres]</code> op B0–B7. Zijn CS en /WR allebei laag, bewaar dan de databyte als commando. Een machinecyclus van de 8048 duurt 2,5 µs, dus er is ruim marge, maar de lus mag nooit haperen. Daarom draait er verder niets op deze core.</li> \n<li><b>Core 1, het netwerk</b>: de CYW43-driver met lwIP en mbedTLS. Een HTTPS-GET naar <code>retrovault.world/teletext/nos.php?p=101</code>. Nog beter: geef de doorgeefserver een compact antwoord <code>&amp;fmt=ef9340</code> met de 1.920 bytes kant-en-klaar, dan hoeft de cartridge geen JSON te lezen. Ververs elke 60 seconden en op verzoek. Houd twee buffers en wissel ze alleen als de console niet aan het lezen is.</li> \n<li><b>Instellingen</b>: de WiFi-naam en het wachtwoord staan in <code>wifi.txt</code> op het USB-station van de Pico. PicoPAC verschijnt al als USB-station voor zijn ROM-bestanden.</li> \n</ul> \n<h3>6. Zo praten console en cartridge met elkaar</h3> \n<ul> \n<li><b>Console → cartridge</b>: de 8048 zet P14 laag (P13 hoog) en doet een MOVX-schrijfactie. Op de cartridge zie je dan CS en /WR laag, het adres op A0–A7 en de waarde op B0–B7. Het menu van PicoPAC gebruikt dit trucje om door te geven welk spel je kiest. Het eigen externe RAM van de console krijgt dezelfde schrijfactie, en dat kan geen kwaad. <b>Blijf binnen <code>E0–E3</code></b>: de spraakmodule The Voice reageert op schrijfacties naar <code>80–DF</code> en <code>F0–FF</code> (en <code>E4</code>, <code>E8–EF</code>). Daarom raakt de <code>FE</code>/<code>FF</code>-handshake van PicoPAC zelf in de war als er een Voice aan hangt. Die les komt uit het Odyssey 2-werk van FujiNet (zie boven). Voorstel: <code>E0</code> het honderdtal van de pagina, <code>E1</code> tientallen en eenheden (BCD), <code>E2</code> de subpagina, <code>E3</code> het commando, als laatste geschreven (1 ophalen, 2 volgende, 3 vorige, 4 verversen).</li> \n<li><b>Cartridge → console</b>: een MOVX-leesactie zou botsen met het RAM van de console op dezelfde bus, dus de data komt terug via de ROM. Eén vast adres in de cartridge (bijvoorbeeld <code>7FF</code>) is een <b>doorstroompoort</b>: elke keer dat de 8048 het leest, geeft het de volgende byte van de pagina. <code>7FE</code> is een statusbyte: 0 bezig, 1 pagina klaar, 2 pagina bestaat niet, 3 geen WiFi. De 8048 leest beide met <code>MOVP A,@A</code>. De Odyssey 2-cartridge van FujiNet antwoordt op dezelfde manier: een pagina in het ROM-venster die de cartridge tussen de transacties door herschrijft.</li> \n</ul> \n<h3>7. Het G7400-programma (8048, 2 KB)</h3> \n<ul> \n<li>Hergebruik de EF9340-routines uit de eigen G7400-homebrew-engine van de Vault: chip instellen, cursor, schrijven-met-ophogen, eigen tekens.</li> \n<li>Invoer via de BIOS-toetsroutine op <code>00B0h</code>: cijfers vormen het paginanummer. Op de joystick is links/rechts de vorige/volgende pagina, omhoog/omlaag de subpagina, en vuur gaat naar 100.</li> \n<li>Ophalen: schrijf het verzoek, kijk naar <code>7FE</code> tot de pagina klaar is, en stroom dan 24 rijen × 40 vakjes × 2 bytes (teken + attribuut) de EF9340 in. Teken de kopregel met paginanummer en status.</li> \n<li>Ongeveer 2.000 bytes à een paar cycli van 2,5 µs is grofweg 30–60 ms, dus een pagina staat er binnen een paar beeldjes.</li> \n<li>De NOS stuurt elk teken al met een eigen kleur, en dat past op de attribuutbyte per vakje van de EF9340, dus er hoeven geen teletekst-stuurcodes ontleed te worden. Blokgrafiek gaat naar de ingebouwde 2 × 3-set van de EF9341. Nederlandse accenten (ë, é) worden gewone letters of eigen tekens.</li> \n<li>Op een G7000 (geen EF9340) toont het programma \"heeft een G7400 nodig\" in plaats van vast te lopen.</li> \n</ul> \n<h3>8. Bouwen en testen, in deze volgorde</h3> \n<ol> \n<li>Bouw het bordje en flash de firmware van PicoPAC met de pinnummers aangepast aan de tabel hierboven. Draaien gewone spellen, dan klopt de bedrading.</li> \n<li>Serveer één vaste teletekstpagina uit flash, zonder WiFi, en krijg de 8048-client zover dat hij hem tekent. Schrijf de client eerst in o2em met het headless testharnas van de Vault, uitgebreid met een nepcartridge die de doorstroompoort nadoet.</li> \n<li>Zet WiFi aan op core 1 en controleer dat spellen nog steeds draaien terwijl WiFi bezig is: de buslus mag niet haperen.</li> \n<li>Voeg <code>fmt=ef9340</code> toe aan de doorgeefserver, daarna het verzoekkanaal.</li> \n<li>Bouw hem in de behuizing en test op een G7400, daarna op een G7000 voor de foutmelding.</li> \n</ol> \n<h3>9. Let op</h3> \n<ul> \n<li><b>Stroom</b>: de WiFi-chip trekt pieken van een paar honderd mA, en de 5V-voeding van de console was bedoeld voor een ROM-chip. Meet het. Is het krap, voed de Pico dan via USB en deel alleen de massa.</li> \n<li>Steek de cartridge er nooit in en haal hem er nooit uit terwijl de console aan staat.</li> \n<li>De hardware van PicoPAC is CC BY-SA. Een printplaat die erop gebaseerd is, houdt die licentie en vermeldt het origineel.</li> \n<li>Ga via de doorgeefserver en niet rechtstreeks naar de NOS. De cache van 60 seconden houdt de belasting voor de NOS gelijk, hoeveel cartridges er ook zijn.</li> \n</ul>",
   "source": "Retro Vault"
  },
  "history": {
   "text": "A Retro Vault what-if from 2026. The Videopac G7400 (1983) came with a teletext-style video chip pair, and Philips made the TV sets, the teletext chips and the console - yet a teletext cartridge never appeared. The idea came from Dutch enthusiasts who built a WiFi cartridge that shows live teletext on a Philips P2000T. The box is a fan-made concept cover.",
   "source": "Retro Vault",
   "url": "teletext.html"
  }
 },

 "im_atlantis": {
  "input": "joystick",
  "manual": {
   "item": "Atlantis_1983_Imagic_EU",
   "pages": 3,
   "source": "Atlantis (1983)(Imagic)(EU)"
  },
  "history": {
   "text": "Imagic's defence game: hold off the Gorgon fleet before it levels the city. Atlantis has six sections and the game ends when the last one falls. Four skill levels.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Atlantis_1983_Imagic_EU"
  },
  "video": {
   "id": "c98XV6roIBU",
   "title": "Atlantis for the Magnavox Odyssey²/Philips Videopac"
  }
 },
 "im_demon-attack": {
  "input": "joystick",
  "manual": {
   "item": "Demon_Attack_1993_Imagic",
   "pages": 6,
   "source": "Demon Attack (1993)(Imagic)"
  },
  "history": {
   "text": "Imagic's fixed shooter. Demons come down in waves and you survive them to earn reserve bunkers — three to start with, six at most, and the next hit after the last one is gone ends the game.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Demon_Attack_1993_Imagic"
  },
  "video": {
   "id": "HeiHP93mfjQ",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Demon Attack (1983) (Imagic) Longplay"
  }
 },
 "jo_basket-bowling_pl": {
  "input": "joystick",
  "manual": {
   "item": "tenpin-bowling-basketball-eur-philips-videopac-1980",
   "pages": 12,
   "source": "Tenpin Bowling | Basketball (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "L-3EeUcJQKM",
   "title": "Modul 6 Jopac Version: Bowling | Philips Videopac / Magnavox Odyssey / G7000 / G7400"
  },
  "history": {
   "text": "Tenpin bowling and basketball on one cartridge, for two or three players, with a faster speed setting for the bowling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/tenpin-bowling-basketball-eur-philips-videopac-1980"
  }
 },
 "jo_billard_pl": {
  "input": "joystick",
  "video": {
   "id": "tH1_fTFI5KA",
   "title": "Billard Américain (Fra) - Odyssey 2 [MESS] [shortplay]"
  }
 },
 "jo_chez-maxime": {
  "input": "joystick",
  "manual": {
   "item": "Chez_Maxime_198x_Jopac",
   "pages": 3,
   "source": "Chez Maxime (198x)(Jopac)"
  },
  "video": {
   "id": "FPgLPbCKPqI",
   "title": "Videopac /  Odyssey 2 Games - The Mousing Cat & Chez Maxime - ARG Presents 204"
  },
  "history": {
   "text": "Maxime runs meals up to a waiter working his way between floors by the stairs. Let more than three customers leave angry and the job is judged a failure.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Chez_Maxime_198x_Jopac"
  }
 },
 "jo_demon-attack_pl": {
  "input": "joystick",
  "manual": {
   "item": "Demon_Attack_1993_Imagic",
   "pages": 6,
   "source": "Demon Attack (1993)(Imagic) - Imagic booklet, same game"
  },
  "history": {
   "text": "Written by Rob Fulop and published by Imagic in 1982. Imagic licensed it to Thomson-Brandt, who sold the Videopac in France under the Jopac name and released this version in 1983 as Demon Attack+ - the game is Imagic's, but the G7400 background graphics are exclusive to the Jopac edition, which is why it sits under Jopac here rather than under Imagic.",
   "wikiTitle": "Demon Attack",
   "url": "https://en.wikipedia.org/wiki/Demon_Attack"
  },
  "video": {
   "id": "nwctfn_mNik",
   "title": "Demon Attack+ Jopac Version | Philips Videopac / Magnavox Odyssey / G7000 / G7400 (MrVenom1974)"
  }
 },
 "jo_exojet_pl": {
  "input": "joystick",
  "manual": {
   "item": "Exojet_198x_Jopac",
   "pages": 3,
   "source": "Exojet (198x)(Jopac)"
  },
  "video": {
   "id": "7c4KGPJKnaI",
   "title": "Odyssey²  Videopac+ : Exojet+ / Preview \\"
  },
  "history": {
   "text": "Your ship has strayed into a canyon on a reconnaissance flight and cannot get out. Enemy ships overhead fire two missiles at a time, laser guns in the canyon walls fire one, and the sight tells you which is coming.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Exojet_198x_Jopac"
  }
 },
 "jo_flipper_pl": {
  "input": "joystick",
  "manual": {
   "item": "Flipper_Game_1980_Philips_en-de",
   "pages": 6,
   "source": "Flipper Game (1980)(Philips)(en-de) - same game, Philips-branded manual"
  },
  "video": {
   "id": "QT3msJJbjlE",
   "title": "Modul 24+: Flipper Jopac Version | Philips Videopac / Magnavox Odyssey / G7000 / G7400 (MrVenom1974)"
  },
  "history": {
   "text": "Pinball, with the whole television turned into a table. The four small coloured targets at the very top are worth four thousand points each and are correspondingly hard to hit.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Flipper_Game_1980_Philips_en-de"
  }
 },
 "jo_le-tresor-englouti_pl": {
  "input": "joystick",
  "manual": {
   "item": "Tresor_Englouti_Le_198x_Jopac_FR",
   "pages": 3,
   "source": "Tresor Englouti, Le (198x)(Jopac)(FR)"
  },
  "video": {
   "id": "ZIgIzZJOWgo",
   "title": "Philips Videopac Plus G7400 - Le Tresor Englouti"
  },
  "history": {
   "text": "A diving game: your air runs down as you explore the wreck and goes back up when you surface at the boat, where three bottles are waiting.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Tresor_Englouti_Le_198x_Jopac_FR"
  }
 },
 "jo_moto-crash_pl": {
  "input": "joystick",
  "manual": {
   "item": "Moto-Crash_198x_Jopac",
   "pages": 3,
   "source": "Moto-Crash (198x)(Jopac)"
  },
  "video": {
   "id": "9XGTuyK6W8Q",
   "title": "Philips Videopac Plus G7400 - Moto Crash"
  },
  "history": {
   "text": "A French Jopac release, published by TO.TEK: a reflex game, riding a motorbike flat out at night.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Moto-Crash_198x_Jopac"
  }
 },
 "jo_syracuse": {
  "input": "joystick",
  "video": {
   "id": "fBWnkaDpfj0",
   "title": "Syracuse (Odyssey 2 / Videopac) complete run - 2nd Gen Journey #32"
  }
 },
 "mod_br21_fix": {
  "input": "joystick",
  "video": {
   "id": "5KapGxp0hEo",
   "title": "O Segredo do Faraó - Odyssey (unmodified cartridge)"
  },
  "history": {
   "text": "Two pyramid builders race each other to get the stones into the right order and solve the pyramid. The winner grows in stature and blows his trumpet about it. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Secret_of_the_Pharaohs_1980_Philips_en-de"
  }
 },
 "mod_vp9_examples": {
  "input": "keyboard",
  "video": {
   "id": "Is9v3t5DxiE",
   "title": "PHILIPS VIDEOPAC 7000 ODYSSEY 2 Computer Intro 1980MagnavoxUS bin"
  },
  "history": {
   "text": "Not a game but a course, in six chapters: how microprocessors work, binary and computer languages, the Videopac machine itself, its instruction set, its operating modes, and sample programs to type in. This one carries the worked examples that go with it.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Computer_Programmer_1978_Philips_EU"
  }
 },
 "mod_demon-attack_pl": {
  "input": "joystick",
  "manual": {
   "item": "Demon_Attack_1993_Imagic",
   "pages": 6,
   "source": "Demon Attack (1993)(Imagic)"
  },
  "history": {
   "text": "Imagic's fixed shooter. Demons come down in waves and you survive them to earn reserve bunkers — three to start with, six at most, and the next hit after the last one is gone ends the game.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Demon_Attack_1993_Imagic"
  },
  "video": {
   "id": "HeiHP93mfjQ",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Demon Attack (1983) (Imagic) Longplay"
  }
 },
 "mod_01pl": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "QJECgFRqT5E",
   "title": "Race/Spin Out/Cryptogram (Videopac/Odyssey²) [#01]"
  }
 },
 "mod_05_g7400": {
  "input": "mixed",
  "video": {
   "id": "Z7Cb7ubFV-E",
   "title": "Las Vegas Blackjack for the Magnavox Odyssey² / Philips Videopac"
  },
  "history": {
   "text": "Blackjack against the computer, which deals, keeps its second card hidden and does the banking. One or two players, aces count one or eleven, and you can draw to a maximum of five cards. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Blackjack_1978_Philips_en-de"
  }
 },
 "mod_06pl": {
  "input": "joystick",
  "manual": {
   "item": "tenpin-bowling-basketball-eur-philips-videopac-1980",
   "pages": 12,
   "source": "Tenpin Bowling | Basketball (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "_SZMgiFthtY",
   "title": "Bowling! - (1978) - Odyssey 2 - gameplay HD"
  },
  "history": {
   "text": "Tenpin bowling and basketball on one cartridge, for two or three players, with a faster speed setting for the bowling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/tenpin-bowling-basketball-eur-philips-videopac-1980"
  }
 },
 "mod_11pl": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "mod_14fix": {
  "input": "joystick",
  "video": {
   "id": "mTd_F2J2qPU",
   "title": "Gunfighter on Videopac G7000 (Rob's Retro Rambles)"
  },
  "history": {
   "text": "A duel for two, blue against red. Take cover behind the rocks, wait for a clear horizontal shot, and mind the ricochets. First to ten wins. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Gunfighter_1978_Philips_en-de"
  }
 },
 "mod_19_g7400": {
  "input": "joystick",
  "manual": {
   "item": "catch-the-ball-noughts-and-crosses-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Catch The Ball | Noughts And Crosses (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "pqPmAYwVrA8",
   "title": "39 - Catch the Ball - press 2:Single Player - Videopac [MAME]"
  },
  "history": {
   "text": "Catch the Ball and Noughts and Crosses, in variations for one or two players, with and without a time limit — the untimed ones exist so you can practise the timed ones.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/catch-the-ball-noughts-and-crosses-eur-philips-videopac-1980"
  }
 },
 "mod_20pl": {
  "input": "joystick",
  "manual": {
   "item": "Stone_Sling_1980_Philips_en-de",
   "pages": 6,
   "source": "Stone Sling (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Videopac 20 - Stone Sling is 1981 artillery video game released in Europe by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². In North America it was reworked by Robert Cheezem and published under the title Smithereens! in 1982. In the game, two players face off with catapults and attempt to knock each other's tower down. In North America, the game featured compatibility with \"The Voice of Odyssey²\" expansion module. It was also later released for the Philips Videopac+ G7400.",
   "wikiTitle": "Stone Sling",
   "url": "https://en.wikipedia.org/wiki/Stone_Sling"
  },
  "video": {
   "id": "sVFAzikfWWw",
   "title": "Videopac #20 - Stone Sling"
  }
 },
 "mod_24pl": {
  "input": "joystick",
  "history": {
   "text": "Pinball, with the whole television turned into a table. The four small coloured targets at the very top are worth four thousand points each and are correspondingly hard to hit. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Flipper_Game_1980_Philips_en-de"
  },
  "video": {
   "id": "Fi34Om0UAIs",
   "title": "Flipper Game - G7000 Videopac nr. 24 - GubbaGaming"
  }
 },
 "mod_28fix": {
  "input": "joystick",
  "manual": {
   "item": "electronic-volleyball-eur-philips-videopac-1981",
   "pages": 18,
   "source": "Electronic Volleyball (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "Volleyball!, known in Europe as Videopac 28 - Electronic Volleyball, is a 1980 volleyball video game created by Ed Averett and published by Magnavox and Philips for the Magnavox Odyssey 2 also known as the Philips Videopac G7000. Players either compete with each other or a computer opponent by controlling six volleyball players simultaneously. The game received mixed reviews from critics, some of whom praised its attempt to recreate the feel of the original sport while others criticized it for being too much like Pong.",
   "wikiTitle": "Volleyball!",
   "url": "https://en.wikipedia.org/wiki/Volleyball!"
  },
  "video": {
   "id": "U95KWXplSzk",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Volleyball! (1980) (Videopac 28) Longplay"
  }
 },
 "mod_30fix": {
  "input": "joystick",
  "history": {
   "text": "Two generals, and soldiers you cannot steer. They make their own way towards the opposing general and capture whatever they meet on the route; the officers start out gentlemanly and do not stay that way. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/battlefield-eur-philips-videopac-1981"
  },
  "video": {
   "id": "qIfCwJE857U",
   "title": "Magnavox Odyssey 2 - Philips Videopac: War of Nerves! (1979) (Videopac 30) Longplay"
  }
 },
 "mod_31_g7400": {
  "input": "keyboard",
  "video": {
   "id": "uhGxRzkkUJw",
   "title": "Musician for the Philips Videopac"
  },
  "history": {
   "text": "A music cartridge rather than a game. It teaches you to play, and records what you play back. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Musician_1983_Philips_EU"
  }
 },
 "mod_35pl_fix": {
  "input": "joystick",
  "manual": {
   "item": "electronic-billiards-eur-philips-videopac-1981",
   "pages": 24,
   "source": "Electronic Billiards (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "1c4VL8be2XM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Pocket Billiards! (1980) (Videopac 35) Longplay"
  },
  "history": {
   "text": "Pool, in two games: 8-Ball and Rotation. The manual is firm that you never press the action button or a key while you are moving the joystick.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-billiards-eur-philips-videopac-1981"
  }
 },
 "mod_36fix": {
  "input": "joystick",
  "manual": {
   "item": "electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Electronic Soccer | Electronic Ice Hockey (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "B8s5zSQDGDg",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Electronic Table Soccer! (1980) (Videopac 27) Longplay"
  },
  "history": {
   "text": "Soccer and ice hockey, red against blue, played in five-minute periods with the clock counting down at the bottom of the screen. Hold the action button and the ball keeps travelling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981"
  }
 },
 "mod_40_g7400": {
  "input": "mixed",
  "video": {
   "id": "upoIpYcwjaE",
   "title": "Odyssey 2 - 4 in 1 Row © 1982 Philips - Gameplay"
  },
  "history": {
   "text": "Connect four, played by a pussycat and a hounddog. Drop a ball into a column each turn and try to line up four across, down or diagonally; the computer applauds the winner for as long as you hold the button down. This copy is a modified dump of that cartridge. Nobody has written down what was changed in it — playing it and comparing is the only way to find out.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Four_in_1_row_1982_Philips_EU"
  }
 },
 "mod_43pl": {
  "input": "joystick",
  "manual": {
   "item": "pickaxe-pete-eur-philips-videopac-1982",
   "pages": 28,
   "source": "Pickaxe Pete (EUR)(Philips Videopac)(1982)"
  },
  "history": {
   "text": "Pick Axe Pete!, known in Europe as Videopac 43 - Pickaxe Pete, is a 1982 platform video game released for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was created by American programmer Ed Averett and his wife Linda and published by Philips. The player takes the role of the miner Pick Axe Pete who searching the Misty Mountain Mine for gold. A national high score competition was held at the 1982 World's Fair. In Brazil, it was titled Didi na Mina Encantada based on the character Didi from the TV series Os Trapalhões.",
   "wikiTitle": "Pick Axe Pete!",
   "url": "https://en.wikipedia.org/wiki/Pick_Axe_Pete!"
  },
  "video": {
   "id": "xkIVZhTgZ48",
   "title": "Pick Axe Pete! for the Odyssey² | BIG Claims from a SO-SO Platformer?"
  }
 },
 "mod_55pl": {
  "input": "joystick",
  "manual": {
   "item": "55_PLUS_Neutron_Star_1983_Philips_EU",
   "pages": 4,
   "source": "Neutron Star (1983)(Philips)(EU)"
  },
  "video": {
   "id": "buF3DWJ_nPQ",
   "title": "Neutron Star (Odyssey 2 /Videopac...emu) 116"
  },
  "history": {
   "text": "You fly out to a dead planet, collect the fragments left of it and drop them into a neutron star to be incinerated. Getting close enough to grab a boulder is the easy half; firing the retro rockets to pull away from the star before it takes you is the other.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/55_PLUS_Neutron_Star_1983_Philips_EU"
  }
 },
 "mod_moto-crash_g7000": {
  "input": "joystick",
  "manual": {
   "item": "Moto-Crash_198x_Jopac",
   "pages": 3,
   "source": "Moto-Crash (198x)(Jopac)"
  },
  "video": {
   "id": "QX6_c71gdQ0",
   "title": "Videopac G7400 / Moto-Crash 3,897"
  },
  "history": {
   "text": "A French Jopac release, published by TO.TEK: a reflex game, riding a motorbike flat out at night.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Moto-Crash_198x_Jopac"
  }
 },
 "mod_vp31_examples": {
  "input": "keyboard",
  "history": {
   "text": "A music cartridge rather than a game. It teaches you to play, and records what you play back. This one carries the worked code examples that go with it, rather than the music program itself.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Musician_1983_Philips_EU"
  },
  "video": {
   "id": "uhGxRzkkUJw",
   "title": "Musician for the Philips Videopac"
  }
 },
 "mod_playtag_fix": {
  "input": "joystick",
  "video": {
   "id": "0WQ1hcMF-_8",
   "title": "Play Tag (PROTOTYPE!) for the Philips Videopac"
  }
 },
 "mod_tutankham_fix": {
  "input": "joystick",
  "video": {
   "id": "6IgcEyfp8s0",
   "title": "Tutankham Videopac / Odyssey2"
  }
 },
 "o2_40": {
  "input": "keyboard",
  "manual": {
   "item": "TypeTellOdyssey21982",
   "pages": 12,
   "source": "Type & Tell game manual Odyssey 2 (1982)"
  },
  "history": {
   "text": "Type and Tell! is a speech synthesis program released in 1982 for the Magnavox Odyssey². It was designed by Robert Cheezum for North American Philips and released exclusively in North America as a launch title for the Odyssey²'s voice synthesis module, \"The Voice of Odyssey²\". Users can enter a short phrase which the voice module will attempt to read. Critics thought it was too simple to hold anyone's attention for long but were entertained by getting the voice module to say a wide variety of things. The Voice plugged into the cartridge slot with the game plugged into it in turn; the O2EM core used here does not emulate it, so the cart runs but stays silent.",
   "wikiTitle": "Type & Tell!",
   "url": "https://en.wikipedia.org/wiki/Type_%26_Tell!"
  },
  "video": {
   "id": "r02EwfmZojU",
   "title": "Type & Tell - Magnavox Odyssey 2 The Voice, review (The No Swear Gamer)"
  }
 },
 "o2_48": {
  "input": "joystick",
  "manual": {
   "item": "power-lords-us-odyssey-2-1983",
   "pages": 8,
   "source": "Power Lords (US)(Odyssey 2)(1983)"
  },
  "video": {
   "id": "Sgeo6S_zuJI",
   "title": "Power Lords - Magnavox Odyssey 2 gameplay (The No Swear Gamer)"
  },
  "history": {
   "text": "A tie-in with the Revell toy line. Points come from blasting lava during the eruption and destroying the rock it leaves, and the high scorer types their initials in at the end.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/power-lords-us-odyssey-2-1983"
  }
 },
 "o2_48alt": {
  "input": "mixed",
  "video": {
   "id": "IVtCcwX0LJw",
   "title": "Power Lords for the Magnavox Odyssey²"
  },
  "manual": {
   "item": "Backgammon_1982_Philips_EU",
   "pages": 18,
   "source": "Backgammon (1982)(Philips)(EU)"
  },
  "history": {
   "text": "Backgammon against the computer or another player. Both sides race to bear all their checkers off; a roll of five and three moves five and then three, never eight in one go.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Backgammon_1982_Philips_EU"
  }
 },
 "o2_30": {
  "input": "joystick",
  "manual": {
   "item": "ufogamemanualodyssey21981",
   "pages": 8,
   "source": "UFO game manual Odyssey 2 (1981)"
  },
  "history": {
   "text": "UFO!, released in Europe as Videopac 34 - Satellite Attack, is a 1981 multidirectional shooter video game created by Ed Averett for the Magnavox Odyssey² otherwise known as the Philips Videopac G7000. Players take control of a flying saucer tasked with destroying swarms of enemy unidentified flying objects in outer space. It was published by Magnavox in North America and Philips in Europe and Brazil. It was also later released for the Philips Videopac+ G7400 in 1983. The game is frequently compared to Atari's 1979 video game Asteroids.",
   "wikiTitle": "UFO!",
   "url": "https://en.wikipedia.org/wiki/UFO!"
  },
  "video": {
   "id": "jNlu7wREuUA",
   "title": "UFO - Magnavox Odyssey 2 review (The No Swear Gamer)"
  }
 },
 "o2_06": {
  "input": "keyboard",
  "manual": {
   "item": "computer-intro-us-odyssey-2-1979",
   "pages": 28,
   "source": "Computer Intro! (US)(Odyssey 2)(1979)"
  },
  "video": {
   "id": "IDaW_g5pibM",
   "title": "Computer Intro Walkthrough Odyssey 2"
  },
  "history": {
   "text": "A programming course on cartridge, working up from the ideas to typed-in programs: a Creepy Crawler in two versions, addition in three, multiplication, division, area problems using subroutines, and flash cards.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/computer-intro-us-odyssey-2-1979"
  }
 },
 "o2_19": {
  "input": "keyboard",
  "manual": {
   "item": "OutOfThisWorldHelicopterRescueOdyssey2",
   "pages": 8,
   "source": "Out of This World & Helicopter Rescue game manual Odyssey 2 (1979)"
  },
  "video": {
   "id": "e0QjOgqUXmw",
   "title": "Magnovox Odyssey 2 Game   Out of This World/Helicopter Rescue (1979 Magnovox)"
  },
  "history": {
   "text": "You fly the rescue helicopter Daredevil and have two minutes to lift as many people as possible off the roof of the burning Doomsday Hotel.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/OutOfThisWorldHelicopterRescueOdyssey2"
  }
 },
 "o2_10": {
  "input": "joystick",
  "manual": {
   "item": "computer-golf-us-odyssey-2-1978",
   "pages": 8,
   "source": "Computer Golf! (US)(Odyssey 2)(1978)"
  },
  "history": {
   "text": "Computer Golf!, released in Europe as Videopac 10 - Golf, is a 1979 golf simulation video game. The game was released by Magnavox and Philips for the Magnavox Odyssey², also known as the Philips Videopac G7000. The game features a nine-hole course golf course where players control the angle of their golf strokes by moving a player character around the map and control the power of their strokes by holding down the action button. The game was heavily praised at the time of its release for its graphical flourishes and is considered one of the best sports titles in the Odyssey²'s library.",
   "wikiTitle": "Computer Golf!",
   "url": "https://en.wikipedia.org/wiki/Computer_Golf!"
  },
  "video": {
   "id": "ZQxyaaiR7Es",
   "title": "Computer Golf! - (1978) - Odyssey 2 - gameplay HD"
  }
 },
 "o2_41": {
  "input": "joystick",
  "manual": {
   "item": "smithereens-us-odyssey-2-1982",
   "pages": 12,
   "source": "Smithereens! (US)(Odyssey 2)(1982)"
  },
  "video": {
   "id": "9fyLZvdnPgY",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Smithereens! (1982) (Videopac 20) Longplay"
  },
  "history": {
   "text": "Two catapults, two castles, and boulders. Each hit takes a section off your opponent's castle; hit the catapult itself and he has to pull it back out of range to repair it, which is the moment to press.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/smithereens-us-odyssey-2-1982"
  }
 },
 "o2_11": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-us-odyssey-2-1978",
   "pages": 5,
   "source": "Cosmic Conflict (US)(Odyssey 2)(1978)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "o2_16": {
  "input": "joystick",
  "history": {
   "text": "Showdown in 2100 A.D., known in Europe as Videopac 14 - Gunfighter is a 1979 multidirectional shooter video game created by Ed Averett and published by Magnavox and Philips for the Magnavox Odyssey², also known as the Philips Videopac G7000. The game is set in a futuristic version of the old west. Two gunfighters face one another across a field filled with trees, similar to Midway's Gun Fight.",
   "wikiTitle": "Showdown in 2100 A.D.",
   "url": "https://en.wikipedia.org/wiki/Showdown_in_2100_A.D."
  },
  "video": {
   "id": "uvr_00Qwkf4",
   "title": "Magnovox Odyssey 2 Game: Showdown in 2100 AD (1979 Magnovox)"
  }
 },
 "o2_39": {
  "input": "keyboard",
  "manual": {
   "item": "nimble-numbers-ned",
   "pages": 16,
   "source": "Nimble Numbers Ned (US)(Odyssey 2)(1982)"
  },
  "history": {
   "text": "Nimble Numbers Ned!, also known as Nimble Numbers N.E.D., is an 1982 educational video game with platforming elements released by North American Philips for the Magnavox Odyssey². It was developed by Bob Harris and released exclusively in North America as a launch title for the Odyssey²'s voice synthesis module, \"The Voice\". Players guide the player character Ned over a series of numbered stones while avoiding barrels and answering math and geometry questions. It was designed in collaboration with the University of Tennessee, Knoxville for children grades 1-9. Contemporary reviews found it to be a good educational tool but were mixed on the quality of game itself.",
   "wikiTitle": "Nimble Numbers Ned!",
   "url": "https://en.wikipedia.org/wiki/Nimble_Numbers_Ned!"
  },
  "video": {
   "id": "t4c9hM429t0",
   "title": "Magnavox Odyssey 2: Nimble Numbers Ned (1982) Longplay"
  }
 },
 "o2_38": {
  "input": "joystick",
  "manual": {
   "item": "sid-the-spellbinder-us-odyssey-2-1982",
   "pages": 12,
   "source": "Sid The Spellbinder (US)(Odyssey 2)(1982)"
  },
  "video": {
   "id": "W0fTUMkq3po",
   "title": "Magnavox Odyssey 2 : SID the Spellbinder (1982) Longplay"
  },
  "history": {
   "text": "A segmented creature works its way down the screen, and if you don't destroy it before it reaches the openings at the bottom corners it starts eating your missile reserve — five missiles for every segment that gets through.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/sid-the-spellbinder-us-odyssey-2-1982"
  }
 },
 "o2_07": {
  "input": "keyboard",
  "manual": {
   "item": "matchmaker-buzzword-logix-us-odyssey-2-1978",
   "pages": 8,
   "source": "Matchmaker! Buzzword! Logix! (US)(Odyssey 2)(1978)"
  },
  "video": {
   "id": "VqQYYJB3Avs",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Matchmaker! Logix! Buzzword! Space Rendezvous (1978) Longplay"
  },
  "history": {
   "text": "A deduction game: work out the answer in as few tries as you can. The computer keeps the last six attempts on screen to compare, and whoever solves it in fewest entries wins.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/matchmaker-buzzword-logix-us-odyssey-2-1978"
  }
 },
 "o2_45": {
  "input": "joystick",
  "manual": {
   "item": "attack-of-the-timelord-us-odyssey-2-1982",
   "pages": 12,
   "source": "Attack Of The Timelord! (US)(Odyssey 2)(1982)"
  },
  "history": {
   "text": "Attack of the Timelord!, also known as Terrahawks, is a 1982 fixed shooter video game by Ed and Linda Averett for the Magnavox Odyssey², known in Europe as the Philips Videopac G7000. The player takes the role of a time machine defending against the titular Timelord, Spyrus the Deathless. It was published by Philips who also released it for the Philips Videopac+ G7400. It is compatibile with \"The Voice\" expansion module for the Odyssey². In Europe, it was released as Terrahawks, based off the Terrahawks television series.",
   "wikiTitle": "Attack of the Timelord!",
   "url": "https://en.wikipedia.org/wiki/Attack_of_the_Timelord!"
  },
  "video": {
   "id": "eFwgtqeRnCM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Attack of the Timelord! (1982) (Videopac 51) Longplay"
  }
 },
 "o2_33": {
  "input": "keyboard",
  "manual": {
   "item": "keyboard-creations-us-odyssey-2-1981",
   "pages": 16,
   "source": "Keyboard Creations! (US)(Odyssey 2)(1981)"
  },
  "video": {
   "id": "iB1WzfXM_MM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Keyboard Creations! (1981) (Viadeoapac A) Longplay"
  },
  "history": {
   "text": "A message and quiz cartridge. One player fills as much of the screen message as they can inside an agreed time limit — five, ten or fifteen minutes, ninety-nine for a perfect score — then the second player takes a turn.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/keyboard-creations-us-odyssey-2-1981"
  }
 },
 "o2_43": {
  "input": "joystick",
  "manual": {
   "item": "p.-t.-barnums-acrobats-us-odyssey-2-1982",
   "pages": 12,
   "source": "P. T. Barnum's Acrobats! (US)(Odyssey 2)(1982)"
  },
  "video": {
   "id": "5qdPOXqpWPw",
   "title": "P.T. Barnum's Acrobats! Odyssey 2 Videopac Gameplay"
  },
  "history": {
   "text": "Two acrobats and a seesaw, popping rows of balloons. The bottom row scores two a balloon, the middle four, the top six, with a bonus for clearing a row outright.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/p.-t.-barnums-acrobats-us-odyssey-2-1982"
  }
 },
 "o2_35": {
  "input": "joystick",
  "manual": {
   "item": "k.-c.-munchkin-us-odyssey-2-1981",
   "pages": 16,
   "source": "K. C. Munchkin! (US)(Odyssey 2)(1981)"
  },
  "history": {
   "text": "K.C. Munchkin!, released in Europe as Videopac 38 - Munchkin, is a 1981 maze game created by Ed Averett for the Magnavox Odyssey², also known as the Philips Videopac G7000. Players control a blue alien named K.C. who navigates a maze while eating pellets and avoiding enemy aliens. It was published by North American Philips (N.A.P.), who were sued by Atari over the game's resemblance to the arcade game Pac-Man. The ensuing court case, which was a landmark ruling in video game copyright law, found K.C. Munchkin! to be too close in \"look and feel\" to the arcade game causing it to be pulled from the market. At that point, it was the best selling game yet released for the Odyssey².",
   "wikiTitle": "K.C. Munchkin!",
   "url": "https://en.wikipedia.org/wiki/K.C._Munchkin!"
  },
  "video": {
   "id": "YzAu9xI_Gbc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: K.C. Munchkin! (1981) (Videopac 38) Longplay"
  }
 },
 "o2_21": {
  "input": "mixed",
  "manual": {
   "item": "dynastygamemanualodyssey21979",
   "pages": 8,
   "source": "Dynasty! game manual Odyssey 2 (1979)"
  },
  "history": {
   "text": "Dynasty!, known in Europe as Videopac 15 - Samurai, is a 1979 video game published by Magnavox and Philips for the Magnavox Odyssey², also known as the Philips Videopac G7000. It is a computer version of the board game reversi, a variant of Othello.",
   "wikiTitle": "Dynasty!",
   "url": "https://en.wikipedia.org/wiki/Dynasty!"
  },
  "video": {
   "id": "ENcCIA9dTYs",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Dynasty! (1979) (Videopac 15) Longplay"
  }
 },
 "o2_14": {
  "input": "joystick",
  "manual": {
   "item": "invadersfromhyperspacegamemanualodyssey21978",
   "pages": 8,
   "source": "Invaders from Hyperspace game manual Odyssey 2 (1978)"
  },
  "video": {
   "id": "XeW4Jojq86Y",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Invaders from Hyperspace! (1978) (Videopac 18) Longplay"
  },
  "history": {
   "text": "Battle cruisers launch from planets of your own colour, and a planet changes colour each time laser fire hits it — so losing ground means losing the places you can launch from. Sold in Europe as Laser War.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/invadersfromhyperspacegamemanualodyssey21978"
  }
 },
 "o2_46": {
  "input": "joystick",
  "manual": {
   "item": "turtles-eur-philips-videopac-1983",
   "pages": 16,
   "source": "Turtles (EUR)(Philips Videopac)(1983)"
  },
  "video": {
   "id": "oAqux065vAU",
   "title": "Tartarugas! para Odyssey da Philips  -  Turtles! for Magnavox Odyssey² / Philips Videopac G7000"
  },
  "history": {
   "text": "Konami's arcade game under licence: a multi-storey building, baby turtles to collect, and bombers working through the rooms after you.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/turtles-eur-philips-videopac-1983"
  }
 },
 "o2_47": {
  "input": "joystick",
  "manual": {
   "item": "killerbeesgamemanualodyssey21983",
   "pages": 12,
   "source": "Killer Bees! game manual Odyssey 2 (1983)"
  },
  "history": {
   "text": "Killer Bees! is a 1983 action video game written by Bob Harris for the Magnavox Odyssey², known in Europe as the Philips Videopac G7000. Players take on the role of a swarm of bees who must sting five robots to death while avoiding swarms of enemy bees. It was developed by Magnavox and published by Philips who also released it for the Philips Videopac+ G7400. In North America, the game is compatible with \"The Voice of Odyssey²\", an expansion module that adds synthesized voice lines.",
   "wikiTitle": "Killer Bees!",
   "url": "https://en.wikipedia.org/wiki/Killer_Bees!"
  },
  "video": {
   "id": "bewkGthH8WM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Killer Bees! (1983) (Videopac 52) Longplay"
  }
 },
 "vp_49": {
  "input": "joystick",
  "manual": {
   "item": "turtles-eur-philips-videopac-1983",
   "pages": 16,
   "source": "Turtles (EUR)(Philips Videopac)(1983)"
  },
  "video": {
   "id": "oAqux065vAU",
   "title": "Tartarugas! para Odyssey da Philips  -  Turtles! for Magnavox Odyssey² / Philips Videopac G7000"
  },
  "history": {
   "text": "Konami's arcade game under licence: a multi-storey building, baby turtles to collect, and bombers working through the rooms after you.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/turtles-eur-philips-videopac-1983"
  }
 },
 "vp_40": {
  "input": "mixed",
  "manual": {
   "item": "Four_in_1_row_1982_Philips_EU",
   "pages": 4,
   "source": "Odyssey 2 Manual: 4 in 1 Row"
  },
  "video": {
   "id": "upoIpYcwjaE",
   "title": "Odyssey 2 - 4 in 1 Row © 1982 Philips - Gameplay"
  },
  "history": {
   "text": "Connect four, played by a pussycat and a hounddog. Drop a ball into a column each turn and try to line up four across, down or diagonally; the computer applauds the winner for as long as you hold the button down.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Four_in_1_row_1982_Philips_EU"
  }
 },
 "vp_58_12": {
  "input": "joystick",
  "note": "This game reads <strong>joystick&nbsp;2</strong> &mdash; fly with <span class='kbd'>W</span> <span class='kbd'>A</span> <span class='kbd'>S</span> <span class='kbd'>D</span> and fire with <span class='kbd'>Q</span>; the arrow keys do nothing here. Take-off is a manoeuvre in itself, and getting it wrong ends in the fence within seconds: the moment you pick a variant, hold <span class='kbd'>W</span> (stick forward) to build speed &mdash; when the take-off indicator flashes you have flying speed &mdash; then pull <span class='kbd'>S</span> to climb. Verified working in this vault with the keys above.",
  "manual": {
   "item": "58_PLUS_Air_Battle_1983_Philips_EU",
   "pages": 4,
   "source": "58 PLUS - Air Battle (1983)(Philips)(EU)"
  },
  "video": {
   "id": "YY6QuNVT5ZM",
   "title": "Air Battle (Odyssey 2). Score: 20."
  },
  "history": {
   "text": "An air combat game for one or more players. Take-off is a manoeuvre in itself: push the stick forward until the indicator light flashes to say you have flying speed, then pull back.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/58_PLUS_Air_Battle_1983_Philips_EU"
  }
 },
 "vp_04": {
  "input": "joystick",
  "manual": {
   "item": "Air-Sea_War_1978_Philips_EU",
   "pages": 6,
   "source": "Air-Sea War / Battle (1978)(Philips)(EU)"
  },
  "history": {
   "text": "Air-Sea War and Battle are two games that were released together as the fourth cartridge in the official Philips line of games for the Videopac. In North America, the same game was released as Armored Encounter! / Subchase! for the Magnavox Odyssey².",
   "wikiTitle": "Air-Sea War – Battle",
   "url": "https://en.wikipedia.org/wiki/Air-Sea_War_%E2%80%93_Battle"
  },
  "video": {
   "id": "X3ki9AR-trY",
   "title": "Videopac #04 - Air-Sea War / Battle"
  }
 },
 "vp_03": {
  "note": "Two players only &mdash; there is no computer opponent, and nothing moves until <strong>both</strong> Action buttons have been pressed: on one keyboard that is <span class='kbd'>G</span> for the arrow-key joystick and <span class='kbd'>Q</span> for the <span class='kbd'>W</span> <span class='kbd'>A</span> <span class='kbd'>S</span> <span class='kbd'>D</span> one. The direction each player holds while pressing picks that side's play (see the manual for the play list); then the play runs on the sticks.",
  "input": "joystick",
  "manual": {
   "item": "American_Football_1978_Philips_EU",
   "pages": 5,
   "source": "American Football (1978)(Philips)(EU)"
  },
  "history": {
   "text": "American football for two players, with downs, field goals worth three points, and a choice of normal or fast play.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/American_Football_1978_Philips_EU"
  },
  "video": {
   "id": "fx-CNnsWOOI",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Football! (1978) (Videopac 3) Longplay"
  }
 },
 "vp_48": {
  "input": "mixed",
  "manual": {
   "item": "Backgammon_1982_Philips_EU",
   "pages": 18,
   "source": "Backgammon (1982)(Philips)(EU)"
  },
  "history": {
   "text": "Backgammon against the computer or another player. Both sides race to bear all their checkers off; a roll of five and three moves five and then three, never eight in one go.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Backgammon_1982_Philips_EU"
  },
  "video": {
   "id": "K7Dl9vA8zVo",
   "title": "Modul 48: Backgammon | Philips Videopac / Magnavox Odyssey / G7000 / G7400"
  }
 },
 "vp_08": {
  "input": "joystick",
  "manual": {
   "item": "Baseball_1978_Philips_en-de",
   "pages": 6,
   "source": "Baseball (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Baseball!, known in Europe as Videopac 8 - Baseball, is a 1978 baseball video game published by Magnavox and Philips for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was a launch title for the system in North America. Contemporary critics considered it one of the better sports titles of its era and agreed it was better than Home Run for the Atari 2600 but not better than Major League Baseball for the Intellivision.",
   "wikiTitle": "Baseball!",
   "url": "https://en.wikipedia.org/wiki/Baseball!"
  },
  "video": {
   "id": "jHbKYzHtMRs",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Baseball! (1978) (Videopac 8) Longplay"
  }
 },
 "vp_26": {
  "input": "joystick",
  "manual": {
   "item": "Basket_Game_1980_Philips_en-de",
   "pages": 6,
   "source": "Basket Game (1980)(Philips)(en-de)"
  },
  "video": {
   "id": "CtLLQftDf1c",
   "title": "Basket Game (Euro) ~ Pachinko! (USA) - Odyssey 2 [MESS] [shortplay]"
  },
  "history": {
   "text": "Two players lob balls across a hall, and the game pauses to salute whoever crosses another hundred points. The complication is the busybody running back and forth midway up the screen, catching whatever passes and dumping it back in the centre.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Basket_Game_1980_Philips_en-de"
  }
 },
 "vp_30": {
  "input": "joystick",
  "manual": {
   "item": "battlefield-eur-philips-videopac-1981",
   "pages": 24,
   "source": "Battlefield (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "A strategy game for one or two, and the trick is that you barely control your own army. Each side has a general and four robots; the robots move and fire by themselves, and you only steer the general. A robot hit by a shot freezes, and the fewer of them are still moving the faster the survivors get. The general's job is to repair them by touching them, herd them towards the enemy general, and stay alive — he can be caught by robots, and only by robots. Sold in America as War of Nerves! and in Brazil as Guerra de Nervos!",
   "source": "GameClab longplay notes",
   "url": "https://www.youtube.com/watch?v=qIfCwJE857U"
  },
  "video": {
   "id": "qIfCwJE857U",
   "title": "Magnavox Odyssey 2 - Philips Videopac: War of Nerves! (1979) (Videopac 30) Longplay"
  }
 },
 "vp_05": {
  "note": "Runs on the <strong>G7000 BIOS</strong> (o2rom.bin) &mdash; on the G7400 one this cartridge freezes on a green screen right after SHUFFLE, because its shuffle routine calls a random-number generator that only exists inside the original G7000 BIOS. The vault switches BIOS for this title automatically. Play: press the number of players, type your bet on the number keys and press <span class='kbd'>Enter</span>; answer <em>HIT ?</em> and <em>DOUBLE ?</em> with the YES / NO keys, which are <span class='kbd'>Y</span> and <span class='kbd'>N</span> on your keyboard.",
  "bios": "o2rom.bin",
  "input": "mixed",
  "manual": {
   "item": "Blackjack_1978_Philips_en-de",
   "pages": 6,
   "source": "Blackjack (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Blackjack against the computer, which deals, keeps its second card hidden and does the banking. One or two players, aces count one or eleven, and you can draw to a maximum of five cards.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Blackjack_1978_Philips_en-de"
  },
  "video": {
   "id": "Z7Cb7ubFV-E",
   "title": "Las Vegas Blackjack for the Magnavox Odyssey² / Philips Videopac"
  }
 },
 "vp_57": {
  "input": "joystick",
  "manual": {
   "item": "Blobbers_1983_Philips_EU",
   "pages": 4,
   "source": "Blobbers (1983)(Philips)(EU)"
  },
  "video": {
   "id": "WC0chYsRm5Y",
   "title": "Blobbers for the Philips Videopac"
  },
  "history": {
   "text": "Blobbers hatch harmless and grow, turning purple, then white, then red — and red is when they are dangerous. Adults have a habit of sticking to your laser unit.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Blobbers_1983_Philips_EU"
  }
 },
 "vp_19": {
  "input": "joystick",
  "manual": {
   "item": "catch-the-ball-noughts-and-crosses-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Catch The Ball | Noughts And Crosses (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "pqPmAYwVrA8",
   "title": "39 - Catch the Ball - press 2:Single Player - Videopac [MAME]"
  },
  "history": {
   "text": "Catch the Ball and Noughts and Crosses, in variations for one or two players, with and without a time limit — the untimed ones exist so you can practise the timed ones.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/catch-the-ball-noughts-and-crosses-eur-philips-videopac-1980"
  }
 },
 "vp_17": {
  "input": "keyboard",
  "manual": {
   "item": "chinese-logic-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Chinese Logic (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "DAVAEVmm9ao",
   "title": "Odyssey 2 - Chinese Logic © 1980 Philips - Gameplay"
  },
  "history": {
   "text": "The Tower of Hanoi, with figures moved between stations. The manual gives the minimum for each size, and the numbers tell you what kind of puzzle it is: three moves for three figures, seven for four, fifteen for five, thirty-one for six.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/chinese-logic-eur-philips-videopac-1980"
  }
 },
 "vp_09": {
  "input": "keyboard",
  "manual": {
   "item": "Computer_Programmer_1978_Philips_EU",
   "pages": 28,
   "source": "Computer Programmer (1978)(Philips)(EU)"
  },
  "video": {
   "id": "tsLRtlqsUxU",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Computer Intro! (1979) (Videopac 9) Longplay"
  },
  "history": {
   "text": "Not a game but a course, in six chapters: how microprocessors work, binary and computer languages, the Videopac machine itself, its instruction set, its operating modes, and sample programs to type in.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Computer_Programmer_1978_Philips_EU"
  }
 },
 "vp_41": {
  "input": "mixed",
  "video": {
   "id": "w4kHeH_7mBQ",
   "title": "Conquest of the World for the Magnavox Odyssey²/Philips Videopac"
  }
 },
 "vp_11": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "vp_11alt": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "vp_11pl": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "vp_44": {
  "input": "joystick",
  "video": {
   "id": "qIiVoq98Ggg",
   "title": "KC's Krazy Chase for the Magnavox Odyssey 2/G7000 Videopac"
  }
 },
 "vp_29": {
  "input": "joystick",
  "manual": {
   "item": "Dambuster_1981_Philips_en-de",
   "pages": 16,
   "source": "Dam Buster (1981)(Philips)(en-de)"
  },
  "video": {
   "id": "46SY8ltwihU",
   "title": "Odyssey 2 / Videopac Dam Buster [Variation 0/2] 7"
  },
  "history": {
   "text": "One player has sixty seconds to knock as many blocks as possible out of a dam; the other defends it with a shield. Then the handsets swap and the other one tries.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Dambuster_1981_Philips_en-de"
  }
 },
 "vp_16": {
  "input": "joystick",
  "manual": {
   "item": "Marksman_1978_Philips_en-de",
   "pages": 6,
   "source": "Depth Charge / Marksman (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Two games. In Marksman, targets drift past a sight for one minute or three, with the manual grading your score from 'more practice needed' below fifty to 'a marksman' above a hundred and forty.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Marksman_1978_Philips_en-de"
  },
  "video": {
   "id": "WgE0dGp_kXE",
   "title": "Magnovox Odyssey 2 Game:  Depth Charge/ Marksman (1979 N.V. Phillips)"
  }
 },
 "vp_35": {
  "input": "joystick",
  "manual": {
   "item": "electronic-billiards-eur-philips-videopac-1981",
   "pages": 24,
   "source": "Electronic Billiards (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "1c4VL8be2XM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Pocket Billiards! (1980) (Videopac 35) Longplay"
  },
  "history": {
   "text": "Pool, in two games: 8-Ball and Rotation. The manual is firm that you never press the action button or a key while you are moving the joystick.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-billiards-eur-philips-videopac-1981"
  }
 },
 "vp_35pl": {
  "input": "joystick",
  "manual": {
   "item": "electronic-billiards-eur-philips-videopac-1981",
   "pages": 24,
   "source": "Electronic Billiards (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "1c4VL8be2XM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Pocket Billiards! (1980) (Videopac 35) Longplay"
  },
  "history": {
   "text": "Pool, in two games: 8-Ball and Rotation. The manual is firm that you never press the action button or a key while you are moving the joystick.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-billiards-eur-philips-videopac-1981"
  }
 },
 "vp_36": {
  "input": "joystick",
  "manual": {
   "item": "electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Electronic Soccer | Electronic Ice Hockey (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "B8s5zSQDGDg",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Electronic Table Soccer! (1980) (Videopac 27) Longplay"
  },
  "history": {
   "text": "Soccer and ice hockey, red against blue, played in five-minute periods with the clock counting down at the bottom of the screen. Hold the action button and the ball keeps travelling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981"
  }
 },
 "vp_27": {
  "input": "joystick",
  "manual": {
   "item": "Electronic_Table_Football_1980_Philips_EU",
   "pages": 6,
   "source": "Electronic Table Football (1980)(Philips)(EU)"
  },
  "video": {
   "id": "B8s5zSQDGDg",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Electronic Table Soccer! (1980) (Videopac 27) Longplay"
  },
  "history": {
   "text": "Table football for one or two players, blue playing left to right and yellow the other way. The computer keeps score along the bottom of the screen.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Electronic_Table_Football_1980_Philips_EU"
  }
 },
 "vp_28": {
  "input": "joystick",
  "manual": {
   "item": "electronic-volleyball-eur-philips-videopac-1981",
   "pages": 18,
   "source": "Electronic Volleyball (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "Volleyball!, known in Europe as Videopac 28 - Electronic Volleyball, is a 1980 volleyball video game created by Ed Averett and published by Magnavox and Philips for the Magnavox Odyssey 2 also known as the Philips Videopac G7000. Players either compete with each other or a computer opponent by controlling six volleyball players simultaneously. The game received mixed reviews from critics, some of whom praised its attempt to recreate the feel of the original sport while others criticized it for being too much like Pong.",
   "wikiTitle": "Volleyball!",
   "url": "https://en.wikipedia.org/wiki/Volleyball!"
  },
  "video": {
   "id": "U95KWXplSzk",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Volleyball! (1980) (Videopac 28) Longplay"
  }
 },
 "vp_24": {
  "input": "joystick",
  "manual": {
   "item": "Flipper_Game_1980_Philips_en-de",
   "pages": 6,
   "source": "Flipper Game (1980)(Philips)(en-de)"
  },
  "video": {
   "id": "IPfgNqdVI0s",
   "title": "Videopac (Odyssey 2) - Flipper (fast game - 1) - Gameplay (plus4punk)"
  },
  "history": {
   "text": "Pinball, with the whole television turned into a table. The four small coloured targets at the very top are worth four thousand points each and are correspondingly hard to hit.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Flipper_Game_1980_Philips_en-de"
  }
 },
 "vp_24pl": {
  "input": "joystick",
  "manual": {
   "item": "Flipper_Game_1980_Philips_en-de",
   "pages": 6,
   "source": "Flipper Game (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Pinball, with the whole television turned into a table. The four small coloured targets at the very top are worth four thousand points each and are correspondingly hard to hit.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Flipper_Game_1980_Philips_en-de"
  },
  "video": {
   "id": "Fi34Om0UAIs",
   "title": "Flipper Game - G7000 Videopac nr. 24 - GubbaGaming"
  }
 },
 "vp_39": {
  "input": "joystick",
  "manual": {
   "item": "Freedom_Fighters_1982_Philips_EU",
   "pages": 4,
   "source": "Freedom Fighters (1982)(Philips)(EU)"
  },
  "history": {
   "text": "Freedom Fighters!, released in Europe as Videopac 39 - Freedom Fighters, is a 1982 horizontally scrolling shooter video game written by Ed Averett for the Magnavox Odyssey² also known as the Philips Videopac G7000. Two players must defeat waves of enemies while cooperatively controlling a single space ship. One player controls the ship's position on screen while the other controls the ship's scrolling and speed. It was also released for the Philips Videopac+ G7400. The game was praised at the time of its release for being fast paced and fun, but the game's unique control scheme has been a focal point for criticism. It is also frequently compared to Defender.",
   "wikiTitle": "Freedom Fighters!",
   "url": "https://en.wikipedia.org/wiki/Freedom_Fighters!"
  },
  "video": {
   "id": "8CUjnJSjBnQ",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Freedom Fighters! (1982) (Videopac 39) Longplay"
  }
 },
 "vp_39pl": {
  "input": "joystick",
  "manual": {
   "item": "Freedom_Fighters_1982_Philips_EU",
   "pages": 4,
   "source": "Freedom Fighters (1982)(Philips)(EU)"
  },
  "history": {
   "text": "Freedom Fighters!, released in Europe as Videopac 39 - Freedom Fighters, is a 1982 horizontally scrolling shooter video game written by Ed Averett for the Magnavox Odyssey² also known as the Philips Videopac G7000. Two players must defeat waves of enemies while cooperatively controlling a single space ship. One player controls the ship's position on screen while the other controls the ship's scrolling and speed. It was also released for the Philips Videopac+ G7400. The game was praised at the time of its release for being fast paced and fun, but the game's unique control scheme has been a focal point for criticism. It is also frequently compared to Defender.",
   "wikiTitle": "Freedom Fighters!",
   "url": "https://en.wikipedia.org/wiki/Freedom_Fighters!"
  },
  "video": {
   "id": "8CUjnJSjBnQ",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Freedom Fighters! (1982) (Videopac 39) Longplay"
  }
 },
 "vp_10": {
  "input": "joystick",
  "manual": {
   "item": "golf-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Golf (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Computer Golf!, released in Europe as Videopac 10 - Golf, is a 1979 golf simulation video game. The game was released by Magnavox and Philips for the Magnavox Odyssey², also known as the Philips Videopac G7000. The game features a nine-hole course golf course where players control the angle of their golf strokes by moving a player character around the map and control the power of their strokes by holding down the action button. The game was heavily praised at the time of its release for its graphical flourishes and is considered one of the best sports titles in the Odyssey²'s library.",
   "wikiTitle": "Computer Golf!",
   "url": "https://en.wikipedia.org/wiki/Computer_Golf!"
  },
  "video": {
   "id": "z0j3UtOJvc4",
   "title": "Modul 10: Golf | Philips Videopac / Magnavox Odyssey / G7000 / G7400"
  }
 },
 "vp_14": {
  "input": "joystick",
  "manual": {
   "item": "Gunfighter_1978_Philips_en-de",
   "pages": 6,
   "source": "Gunfighter (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "A duel for two, blue against red. Take cover behind the rocks, wait for a clear horizontal shot, and mind the ricochets. First to ten wins.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Gunfighter_1978_Philips_en-de"
  },
  "video": {
   "id": "mTd_F2J2qPU",
   "title": "Gunfighter on Videopac G7000 (Rob's Retro Rambles)"
  }
 },
 "vp_59_16": {
  "input": "keyboard",
  "manual": {
   "item": "59_PLUS_Helicopter_Rescue_1983_Philips_en-de",
   "pages": 6,
   "source": "59 PLUS - Helicopter Rescue (1983)(Philips)(en-de)"
  },
  "history": {
   "text": "Fly a helicopter over desert and sea picking up stranded pilots, who mark themselves with red flares. Enemy tanks and patrol boats try to stop you, and to pick the pilots off before you get there.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/59_PLUS_Helicopter_Rescue_1983_Philips_en-de"
  },
  "video": {
   "id": "r2s0-TLKiUY",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Out of This World! / Helicopter Rescue! (1979) Longplay"
  }
 },
 "vp_13": {
  "input": "keyboard",
  "manual": {
   "item": "ive-got-your-number-usodyssey-21978",
   "pages": 8,
   "source": "I've Got Your Number! (US)(Odyssey 2)(1978)"
  },
  "video": {
   "id": "G_2yfSnnC9E",
   "title": "Magnavox Odyssey 2 - Philips Videopac: I've Got Your Number (1978) (Videopac 13) Longplay"
  },
  "history": {
   "text": "A number game for children, and deliberately playable by ones who cannot read numbers yet. First to ten right answers wins, with an electronic pat on the back and a musical salute; some answers sit inside the orbits, and you duck the figure's head through to reach them.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/ive-got-your-number-usodyssey-21978"
  }
 },
 "vp_33": {
  "input": "joystick",
  "manual": {
   "item": "jumping-acrobats-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Jumping Acrobats (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "Videopac 33 - Jumping Acrobats, known in North America as P.T. Barnum's Acrobats!, is 1981 action video game by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². It is very similar to Exidy's arcade game Circus, itself a rethemed version of Atari's Breakout. In late 1982, it was rethemed around the entertainment properties of P.T. Barnum by the Odyssey Software Development Group for its North American release. This version also included compatibility with \"The Voice of Odyssey²\" expansion module.",
   "wikiTitle": "Jumping Acrobats",
   "url": "https://en.wikipedia.org/wiki/Jumping_Acrobats"
  },
  "video": {
   "id": "l3oVdXPTF2Q",
   "title": "Videopac (Odyssey 2) - Jumping Acrobats (Kunstspringer) [Game 9] - Gameplay (plus4punk)"
  }
 },
 "vp_33alt": {
  "input": "joystick",
  "manual": {
   "item": "jumping-acrobats-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Jumping Acrobats (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "Videopac 33 - Jumping Acrobats, known in North America as P.T. Barnum's Acrobats!, is 1981 action video game by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². It is very similar to Exidy's arcade game Circus, itself a rethemed version of Atari's Breakout. In late 1982, it was rethemed around the entertainment properties of P.T. Barnum by the Odyssey Software Development Group for its North American release. This version also included compatibility with \"The Voice of Odyssey²\" expansion module.",
   "wikiTitle": "Jumping Acrobats",
   "url": "https://en.wikipedia.org/wiki/Jumping_Acrobats"
  },
  "video": {
   "id": "l3oVdXPTF2Q",
   "title": "Videopac (Odyssey 2) - Jumping Acrobats (Kunstspringer) [Game 9] - Gameplay (plus4punk)"
  }
 },
 "vp_a": {
  "input": "keyboard",
  "manual": {
   "item": "keyboard-creations-us-odyssey-2-1981",
   "pages": 16,
   "source": "Keyboard Creations! (US)(Odyssey 2)(1981)"
  },
  "video": {
   "id": "8BbWqceR7Eg",
   "title": "Newscaster (Euro) - Odyssey 2 [shortplay] (Arcade Database)"
  },
  "history": {
   "text": "A message and quiz cartridge. One player fills as much of the screen message as they can inside an agreed time limit — five, ten or fifteen minutes, ninety-nine for a perfect score — then the second player takes a turn.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/keyboard-creations-us-odyssey-2-1981"
  }
 },
 "vp_52pl": {
  "input": "joystick",
  "manual": {
   "item": "killer-bees-eur-philips-videopac-1983",
   "pages": 16,
   "source": "Killer Bees (EUR)(Philips Videopac)(1983)"
  },
  "history": {
   "text": "Killer Bees! is a 1983 action video game written by Bob Harris for the Magnavox Odyssey², known in Europe as the Philips Videopac G7000. Players take on the role of a swarm of bees who must sting five robots to death while avoiding swarms of enemy bees. It was developed by Magnavox and published by Philips who also released it for the Philips Videopac+ G7400. In North America, the game is compatible with \"The Voice of Odyssey²\", an expansion module that adds synthesized voice lines.",
   "wikiTitle": "Killer Bees!",
   "url": "https://en.wikipedia.org/wiki/Killer_Bees!"
  },
  "video": {
   "id": "pTkjGszLefA",
   "title": "Killer Bees! - Philips Videopac+ G7400 gameplay"
  }
 },
 "vp_32": {
  "input": "joystick",
  "manual": {
   "item": "a-labyrinth-game-supermind-eur-philips-videopac-1981",
   "pages": 28,
   "source": "A Labyrinth Game | Supermind (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "Xz8XElZySqY",
   "title": "Odyssey 2 - A Labyrinth Game © 1981 Philips - Gameplay"
  },
  "history": {
   "text": "Two games on one cartridge. Supermind is the code-breaker: the computer picks a combination of four symbols out of the forty-seven on the Videopac keyboard, and you work out which.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/a-labyrinth-game-supermind-eur-philips-videopac-1981"
  }
 },
 "vp_23": {
  "input": "mixed",
  "manual": {
   "item": "las-vegas-gambling-eur-philips-videopac-1980",
   "pages": 6,
   "source": "Las Vegas Gambling (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "TEOy5nIPLzE",
   "title": "Las Vegas Gambling (Euro) ~ Casino Slot Machine! (USA) - Odyssey 2 [MESS] [shortplay]"
  },
  "history": {
   "text": "A slot machine for up to four players. Line up three symbols along any of five lines — three across and two diagonal — and the machine pays out coin by coin. The computer keeps your balance.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/las-vegas-gambling-eur-philips-videopac-1980"
  }
 },
 "vp_18": {
  "input": "joystick",
  "manual": {
   "item": "laser-war-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Laser War (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "DbAOS72ffdE",
   "title": "Laser War (Videopac G7000/Odyssey²)[#18]"
  },
  "history": {
   "text": "Red and yellow fighters among asteroids. You fire when an asteroid takes your own craft's colour, and the flying saucer explodes when the laser catches it. The American release called it Invaders from Hyperspace.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/laser-war-eur-philips-videopac-1980"
  }
 },
 "vp_54": {
  "input": "joystick",
  "manual": {
   "item": "54_PLUS_Looney_Balloon_1983_Philips_en-de",
   "pages": 7,
   "source": "Loony Balloon (1983)(Philips)(en-de)"
  },
  "video": {
   "id": "GzmMpicE_Oc",
   "title": "Loony Balloon (Prototype version) for the Philips Videopac"
  },
  "history": {
   "text": "Ten variations set in a playground. You score off the roundabout, the rocking horse and the trees, but each one only pays once, so bonus points have to be hunted elsewhere.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/54_PLUS_Looney_Balloon_1983_Philips_en-de"
  }
 },
 "vp_54pl": {
  "input": "joystick",
  "manual": {
   "item": "54_PLUS_Looney_Balloon_1983_Philips_en-de",
   "pages": 7,
   "source": "Loony Balloon (1983)(Philips)(en-de)"
  },
  "video": {
   "id": "GzmMpicE_Oc",
   "title": "Loony Balloon (Prototype version) for the Philips Videopac"
  },
  "history": {
   "text": "Ten variations set in a playground. You score off the roundabout, the rocking horse and the trees, but each one only pays once, so bonus points have to be hunted elsewhere.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/54_PLUS_Looney_Balloon_1983_Philips_en-de"
  }
 },
 "vp_07": {
  "input": "keyboard",
  "manual": {
   "item": "mathematician-echo-eur-philips-videopac-1978",
   "pages": 12,
   "source": "Mathematician | Echo (EUR)(Philips Videopac)(1978)"
  },
  "video": {
   "id": "hue_65oFTZY",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Math-a-Magic! / Echo! (1978) (Videopac 7) Longplay"
  },
  "history": {
   "text": "Two teaching games. Math-a-Magic sets arithmetic problems — addition, subtraction, multiplication and division, at one, two or three digits depending on the skill level — and never ends; it plays a little tune every ten right answers and runs a clock in the corner so you can race yourself. Echo is Simon: the computer plays a note, shown as a number, a colour and a sound, you repeat it, and one more note is added each round until you have made three mistakes. Brazil sold it as Matemagica! / Jogo da Memória!",
   "source": "GameClab longplay notes",
   "url": "https://www.youtube.com/watch?v=hue_65oFTZY"
  }
 },
 "vp_37": {
  "input": "joystick",
  "manual": {
   "item": "Monkeyshines_1982_Philips_EU",
   "pages": 4,
   "source": "Monkeyshines (1982)(Philips)(EU)"
  },
  "history": {
   "text": "Monkeyshines!, released in Europe as Videopac 37 - Monkeyshines, is a 1981 maze platform written by Ed Averett and published by Philips for the Magnavox Odyssey² also known as the Philips Videopac G7000. It is a game for young children, in which two players compete or coordinate with each other to challenge four monkeys to a game of tag.",
   "wikiTitle": "Monkeyshines!",
   "url": "https://en.wikipedia.org/wiki/Monkeyshines!"
  },
  "video": {
   "id": "5qOEINltvDo",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Monkeyshines! (1981) (Videopac 37) Longplay"
  }
 },
 "vp_45": {
  "input": "keyboard",
  "manual": {
   "item": "Morse_1982_Philips_EU",
   "pages": 4,
   "source": "Morse (1982)(Philips)(EU)"
  },
  "history": {
   "text": "A Morse tutor. The computer sends a signal, and if you don't recognise it, repeats it as dots and dashes on screen and tells you the letter. You answer on the keyboard, and pick your speed to start.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Morse_1982_Philips_EU"
  },
  "video": {
   "id": "nFWY3uMvHQg",
   "title": "Morse for the Videopac"
  }
 },
 "vp_38": {
  "input": "joystick",
  "manual": {
   "item": "munchkin-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Munchkin (EUR)(Philips Videopac)(1982)"
  },
  "history": {
   "text": "K.C. Munchkin!, released in Europe as Videopac 38 - Munchkin, is a 1981 maze game created by Ed Averett for the Magnavox Odyssey², also known as the Philips Videopac G7000. Players control a blue alien named K.C. who navigates a maze while eating pellets and avoiding enemy aliens. It was published by North American Philips (N.A.P.), who were sued by Atari over the game's resemblance to the arcade game Pac-Man. The ensuing court case, which was a landmark ruling in video game copyright law, found K.C. Munchkin! to be too close in \"look and feel\" to the arcade game causing it to be pulled from the market. At that point, it was the best selling game yet released for the Odyssey².",
   "wikiTitle": "K.C. Munchkin!",
   "url": "https://en.wikipedia.org/wiki/K.C._Munchkin!"
  },
  "video": {
   "id": "YzAu9xI_Gbc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: K.C. Munchkin! (1981) (Videopac 38) Longplay"
  }
 },
 "vp_31": {
  "input": "keyboard",
  "manual": {
   "item": "Musician_1983_Philips_EU",
   "pages": 27,
   "source": "Musician (1983)(Philips)(EU)"
  },
  "history": {
   "text": "A music cartridge rather than a game. It teaches you to play, and records what you play back.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Musician_1983_Philips_EU"
  },
  "video": {
   "id": "uhGxRzkkUJw",
   "title": "Musician for the Philips Videopac"
  }
 },
 "vp_55": {
  "input": "joystick",
  "manual": {
   "item": "55_PLUS_Neutron_Star_1983_Philips_EU",
   "pages": 4,
   "source": "Neutron Star (1983)(Philips)(EU)"
  },
  "video": {
   "id": "buF3DWJ_nPQ",
   "title": "Neutron Star (Odyssey 2 /Videopac...emu) 116"
  },
  "history": {
   "text": "You fly out to a dead planet, collect the fragments left of it and drop them into a neutron star to be incinerated. Getting close enough to grab a boulder is the easy half; firing the retro rockets to pull away from the star before it takes you is the other.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/55_PLUS_Neutron_Star_1983_Philips_EU"
  }
 },
 "vp_55_12": {
  "input": "joystick",
  "note": "This is the untouched original dump, kept for the archive &mdash; in this emulator it shows a grey screen after SELECT GAME. To actually play, use the <em>alt dump</em> version of Neutron Star: it carries a two-byte community fix (one redirected BIOS call) that routes around the snag and runs fine.",
  "manual": {
   "item": "55_PLUS_Neutron_Star_1983_Philips_EU",
   "pages": 4,
   "source": "Neutron Star (1983)(Philips)(EU)"
  },
  "video": {
   "id": "buF3DWJ_nPQ",
   "title": "Neutron Star (Odyssey 2 /Videopac...emu) 116"
  },
  "history": {
   "text": "You fly out to a dead planet, collect the fragments left of it and drop them into a neutron star to be incinerated. Getting close enough to grab a boulder is the easy half; firing the retro rockets to pull away from the star before it takes you is the other.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/55_PLUS_Neutron_Star_1983_Philips_EU"
  }
 },
 "vp_55_12fix": {
  "input": "joystick",
  "manual": {
   "item": "55_PLUS_Neutron_Star_1983_Philips_EU",
   "pages": 4,
   "source": "Neutron Star (1983)(Philips)(EU)"
  },
  "video": {
   "id": "buF3DWJ_nPQ",
   "title": "Neutron Star (Odyssey 2 /Videopac...emu) 116"
  },
  "history": {
   "text": "You fly out to a dead planet, collect the fragments left of it and drop them into a neutron star to be incinerated. Getting close enough to grab a boulder is the easy half; firing the retro rockets to pull away from the star before it takes you is the other.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/55_PLUS_Neutron_Star_1983_Philips_EU"
  }
 },
 "vp_53": {
  "input": "joystick",
  "manual": {
   "item": "53_PLUS_Nightmare_1983_Philips_en-de",
   "pages": 8,
   "source": "Nightmare (1983)(Philips)(en-de)"
  },
  "history": {
   "text": "An escape adventure for one or two players. Each nightmare is a run of three attempts to get out, and the computer shows how many you have left before the dream is over. The haunted-house theme is practically a family heirloom on this console: the original 1972 Magnavox Odyssey — the Odyssey²'s direct ancestor — shipped a Haunted House overlay game, arguably the first horror video game ever made, with one player as the detective and the other as the ghost. A decade on, Nightmare brought the haunting back to the family in real graphics instead of a plastic screen overlay.",
   "source": "the cartridge manual · haunted-house lineage: Computer History Museum",
   "url": "https://computerhistory.org/blog/the-haunted-house/"
  },
  "video": {
   "id": "WUlqZezZoB0",
   "title": "NIGHTMARE - 1983 survival horror game for Videopac G7000 (Odyssey2)"
  }
 },
 "vp_53pl": {
  "input": "joystick",
  "manual": {
   "item": "53_PLUS_Nightmare_1983_Philips_en-de",
   "pages": 8,
   "source": "Nightmare (1983)(Philips)(en-de)"
  },
  "history": {
   "text": "An escape adventure for one or two players. Each nightmare is a run of three attempts to get out, and the computer shows how many you have left before the dream is over. The haunted-house theme is practically a family heirloom on this console: the original 1972 Magnavox Odyssey — the Odyssey²'s direct ancestor — shipped a Haunted House overlay game, arguably the first horror video game ever made, with one player as the detective and the other as the ghost. A decade on, Nightmare brought the haunting back to the family in real graphics instead of a plastic screen overlay.",
   "source": "the cartridge manual · haunted-house lineage: Computer History Museum",
   "url": "https://computerhistory.org/blog/the-haunted-house/"
  },
  "video": {
   "id": "WUlqZezZoB0",
   "title": "NIGHTMARE - 1983 survival horror game for Videopac G7000 (Odyssey2)"
  }
 },
 "vp_56pl": {
  "input": "joystick",
  "manual": {
   "item": "56_PLUS_Norseman_1983_Philips_en-de",
   "pages": 11,
   "source": "56 PLUS - Norseman (1983)(Philips)(en-de)"
  },
  "video": {
   "id": "FOMMp5AY5n4",
   "title": "Videopac G7400 / Norseman [Game 0] 510"
  },
  "history": {
   "text": "A Videopac+ exclusive, set among the Vikings a thousand years ago. The screen is a courtyard divided into cells in a honeycomb pattern, with a warrior working his way through it.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/56_PLUS_Norseman_1983_Philips_en-de"
  }
 },
 "vp_02": {
  "input": "joystick",
  "manual": {
   "item": "pairs-space-rendezvous-logic-eur-philips-videopac-1980",
   "pages": 22,
   "source": "Pairs | Space Rendezvous | Logic (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "HBF_fbKmwus",
   "title": "PHILIPS VIDEOPAC 7000 ODYSSEY 2 3 GAMES Pairs   Space Rendezvous   Logic 1980PhilipsEu bin"
  },
  "history": {
   "text": "Three games. Pairs asks for two letters between A and T to turn symbols over. Space Rendezvous is the interesting one: land on the planet, then dock with the mother ship before the fuel runs out, with a crash costing you time.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/pairs-space-rendezvous-logic-eur-philips-videopac-1980"
  }
 },
 "vp_43": {
  "input": "joystick",
  "manual": {
   "item": "pickaxe-pete-eur-philips-videopac-1982",
   "pages": 28,
   "source": "Pickaxe Pete (EUR)(Philips Videopac)(1982)"
  },
  "history": {
   "text": "Pick Axe Pete!, known in Europe as Videopac 43 - Pickaxe Pete, is a 1982 platform video game released for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was created by American programmer Ed Averett and his wife Linda and published by Philips. The player takes the role of the miner Pick Axe Pete who searching the Misty Mountain Mine for gold. A national high score competition was held at the 1982 World's Fair. In Brazil, it was titled Didi na Mina Encantada based on the character Didi from the TV series Os Trapalhões.",
   "wikiTitle": "Pick Axe Pete!",
   "url": "https://en.wikipedia.org/wiki/Pick_Axe_Pete!"
  },
  "video": {
   "id": "xkIVZhTgZ48",
   "title": "Pick Axe Pete! for the Odyssey² | BIG Claims from a SO-SO Platformer?"
  }
 },
 "vp_43pl": {
  "input": "joystick",
  "manual": {
   "item": "pickaxe-pete-eur-philips-videopac-1982",
   "pages": 28,
   "source": "Pickaxe Pete (EUR)(Philips Videopac)(1982)"
  },
  "history": {
   "text": "Pick Axe Pete!, known in Europe as Videopac 43 - Pickaxe Pete, is a 1982 platform video game released for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was created by American programmer Ed Averett and his wife Linda and published by Philips. The player takes the role of the miner Pick Axe Pete who searching the Misty Mountain Mine for gold. A national high score competition was held at the 1982 World's Fair. In Brazil, it was titled Didi na Mina Encantada based on the character Didi from the TV series Os Trapalhões.",
   "wikiTitle": "Pick Axe Pete!",
   "url": "https://en.wikipedia.org/wiki/Pick_Axe_Pete!"
  },
  "video": {
   "id": "xkIVZhTgZ48",
   "title": "Pick Axe Pete! for the Odyssey² | BIG Claims from a SO-SO Platformer?"
  }
 },
 "vp_42": {
  "input": "mixed",
  "manual": {
   "item": "QuestForTheRingsManual1981",
   "pages": 28,
   "source": "The Quest for the Rings manual (1981) (Odyssey 2)"
  },
  "history": {
   "text": "Quest for the Rings is a fantasy themed board game/video game hybrid released in 1981 by Philips for the Magnavox Odyssey² also known as the Philips Videopac G7000. It is the first game in the \"Master Strategy\" series, a trio of video game/board game hybrids programmed by Ed Averett and designed by Steve Lehner and Rob Bradford for the Odyssey². In addition to the game cartridge, it was shipped with a physical game board and a number of tokens.",
   "wikiTitle": "Quest for the Rings",
   "url": "https://en.wikipedia.org/wiki/Quest_for_the_Rings"
  },
  "video": {
   "id": "k-m-_11Jjf8",
   "title": "Quest For The Rings Playthrough  - The Odyssey 2 hybrid board and video game from 1981!"
  }
 },
 "vp_01": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "QJECgFRqT5E",
   "title": "Race/Spin Out/Cryptogram (Videopac/Odyssey²) [#01]"
  }
 },
 "vp_01hack": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "QJECgFRqT5E",
   "title": "Race/Spin Out/Cryptogram (Videopac/Odyssey²) [#01]"
  }
 },
 "vp_01pl": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "yXNToAVW_50",
   "title": "Race/Spin-out/Cryptogram - Philips Videopac+ G7400 gameplay"
  }
 },
 "vp_15": {
  "input": "joystick",
  "manual": {
   "item": "Samurai_1978_Philips_en-de",
   "pages": 6,
   "source": "Samurai (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Reversi, under another name. You and your opponent take turns capturing each other's discs, and whoever holds the most at the end wins. There are time limits and a computer opponent to practise against.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Samurai_1978_Philips_en-de"
  },
  "video": {
   "id": "kCS9Y5F7AKg",
   "title": "Modul 15: Samurai | Philips Videopac / Magnavox Odyssey / G7000 / G7400"
  }
 },
 "vp_34": {
  "input": "joystick",
  "manual": {
   "item": "satellite-attack-eur-philips-videopac--1981",
   "pages": 20,
   "source": "Satellite Attack (EUR)(Philips Videopac+)(1981)"
  },
  "video": {
   "id": "Tqt29viIOjY",
   "title": "Magnavox Odyssey/Philips Videopac G7000 - Satellite Attack (o2em)"
  },
  "history": {
   "text": "UFO!, released in Europe as Videopac 34 - Satellite Attack, is a 1981 multidirectional shooter video game created by Ed Averett for the Magnavox Odyssey² otherwise known as the Philips Videopac G7000. Players take control of a flying saucer tasked with destroying swarms of enemy unidentified flying objects in outer space. It was published by Magnavox in North America and Philips in Europe and Brazil. It was also later released for the Philips Videopac+ G7400 in 1983. The game is frequently compared to Atari's 1979 video game Asteroids.",
   "wikiTitle": "UFO!",
   "url": "https://en.wikipedia.org/wiki/UFO!"
  }
 },
 "vp_34pl": {
  "input": "joystick",
  "manual": {
   "item": "satellite-attack-eur-philips-videopac--1981",
   "pages": 20,
   "source": "Satellite Attack (EUR)(Philips Videopac+)(1981)"
  },
  "video": {
   "id": "Tqt29viIOjY",
   "title": "Magnavox Odyssey/Philips Videopac G7000 - Satellite Attack (o2em)"
  },
  "history": {
   "text": "UFO!, released in Europe as Videopac 34 - Satellite Attack, is a 1981 multidirectional shooter video game created by Ed Averett for the Magnavox Odyssey² otherwise known as the Philips Videopac G7000. Players take control of a flying saucer tasked with destroying swarms of enemy unidentified flying objects in outer space. It was published by Magnavox in North America and Philips in Europe and Brazil. It was also later released for the Philips Videopac+ G7400 in 1983. The game is frequently compared to Atari's 1979 video game Asteroids.",
   "wikiTitle": "UFO!",
   "url": "https://en.wikipedia.org/wiki/UFO!"
  }
 },
 "vp_21": {
  "input": "mixed",
  "manual": {
   "item": "Secret_of_the_Pharaohs_1980_Philips_en-de",
   "pages": 6,
   "source": "Secret of the Pharaohs (1980)(Philips)(en-de)"
  },
  "video": {
   "id": "YOueTzbL2Ag",
   "title": "Secret of the Pharaohs - Odyssey 2 - Videopac"
  },
  "history": {
   "text": "Two pyramid builders race each other to get the stones into the right order and solve the pyramid. The winner grows in stature and blows his trumpet about it.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Secret_of_the_Pharaohs_1980_Philips_en-de"
  }
 },
 "vp_25": {
  "input": "joystick",
  "manual": {
   "item": "Skiing_1980_Philips_en-de",
   "pages": 6,
   "source": "Skiing (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Slalom skiing for one or two players against the clock. Where the posts line up vertically you cut side to side between them; the action button accelerates, which is how you make back the time you lost.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Skiing_1980_Philips_en-de"
  },
  "video": {
   "id": "Mwq5VtmlN-I",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Alpine Skiing! (1979) (Videopac 25) Longplay"
  }
 },
 "vp_22": {
  "input": "joystick",
  "manual": {
   "item": "space-monster-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Space Monster (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "eo2v95CVihw",
   "title": "Space Monster [Philips Videopac G7000 Longplay] (1980) Magnavox"
  },
  "history": {
   "text": "Alien Invaders - Plus!, known in Europe as Videopac 22 - Space Monster, is a 1980 fixed shooter video game developed by Ed and Linda Averett for the Magnavox Odyssey² also known as the Philips Videopac G7000. Similar to Space Invaders, the object of the game is to destroy all invading aliens while also avoiding enemy fire. It was published by Magnavox and Philips and was later rereleased for the Philips Videopac+ G7400. It reviewed favorably to Space Invaders with some critics considering the starring space monster, The Merciless Monstroth, to be a more interesting adversary. However it was criticized for only having one gameplay mode, contrary to the game's packaging.",
   "wikiTitle": "Alien Invaders - Plus!",
   "url": "https://en.wikipedia.org/wiki/Alien_Invaders_-_Plus!"
  }
 },
 "vp_22hack": {
  "input": "joystick",
  "manual": {
   "item": "space-monster-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Space Monster (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "eo2v95CVihw",
   "title": "Space Monster [Philips Videopac G7000 Longplay] (1980) Magnavox"
  },
  "history": {
   "text": "Alien Invaders - Plus!, known in Europe as Videopac 22 - Space Monster, is a 1980 fixed shooter video game developed by Ed and Linda Averett for the Magnavox Odyssey² also known as the Philips Videopac G7000. Similar to Space Invaders, the object of the game is to destroy all invading aliens while also avoiding enemy fire. It was published by Magnavox and Philips and was later rereleased for the Philips Videopac+ G7400. It reviewed favorably to Space Invaders with some critics considering the starring space monster, The Merciless Monstroth, to be a more interesting adversary. However it was criticized for only having one gameplay mode, contrary to the game's packaging.",
   "wikiTitle": "Alien Invaders - Plus!",
   "url": "https://en.wikipedia.org/wiki/Alien_Invaders_-_Plus!"
  }
 },
 "vp_20": {
  "input": "joystick",
  "manual": {
   "item": "Stone_Sling_1980_Philips_en-de",
   "pages": 6,
   "source": "Stone Sling (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Videopac 20 - Stone Sling is 1981 artillery video game released in Europe by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². In North America it was reworked by Robert Cheezem and published under the title Smithereens! in 1982. In the game, two players face off with catapults and attempt to knock each other's tower down. In North America, the game featured compatibility with \"The Voice of Odyssey²\" expansion module. It was also later released for the Philips Videopac+ G7400.",
   "wikiTitle": "Stone Sling",
   "url": "https://en.wikipedia.org/wiki/Stone_Sling"
  },
  "video": {
   "id": "sVFAzikfWWw",
   "title": "Videopac #20 - Stone Sling"
  }
 },
 "vp_20pl": {
  "input": "joystick",
  "manual": {
   "item": "Stone_Sling_1980_Philips_en-de",
   "pages": 6,
   "source": "Stone Sling (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Videopac 20 - Stone Sling is 1981 artillery video game released in Europe by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². In North America it was reworked by Robert Cheezem and published under the title Smithereens! in 1982. In the game, two players face off with catapults and attempt to knock each other's tower down. In North America, the game featured compatibility with \"The Voice of Odyssey²\" expansion module. It was also later released for the Philips Videopac+ G7400.",
   "wikiTitle": "Stone Sling",
   "url": "https://en.wikipedia.org/wiki/Stone_Sling"
  },
  "video": {
   "id": "sVFAzikfWWw",
   "title": "Videopac #20 - Stone Sling"
  }
 },
 "vp_50": {
  "input": "joystick",
  "manual": {
   "item": "super-bee-eur-philips-videopac-1983",
   "pages": 28,
   "source": "Super Bee (EUR)(Philips Videopac)(1983)"
  },
  "video": {
   "id": "T7321hqO1Xg",
   "title": "Super Bee for the Philips Videopac"
  },
  "history": {
   "text": "Super Bee eats his way through a magic garden that keeps filling with fruit, and the whole difficulty is steering: touch one of the fences or the magic barriers and he crashes.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/super-bee-eur-philips-videopac-1983"
  }
 },
 "vp_06": {
  "input": "joystick",
  "manual": {
   "item": "tenpin-bowling-basketball-eur-philips-videopac-1980",
   "pages": 12,
   "source": "Tenpin Bowling | Basketball (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "_SZMgiFthtY",
   "title": "Bowling! - (1978) - Odyssey 2 - gameplay HD"
  },
  "history": {
   "text": "Tenpin bowling and basketball on one cartridge, for two or three players, with a faster speed setting for the bowling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/tenpin-bowling-basketball-eur-philips-videopac-1980"
  }
 },
 "vp_06pl": {
  "input": "joystick",
  "manual": {
   "item": "tenpin-bowling-basketball-eur-philips-videopac-1980",
   "pages": 12,
   "source": "Tenpin Bowling | Basketball (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "_SZMgiFthtY",
   "title": "Bowling! - (1978) - Odyssey 2 - gameplay HD"
  },
  "history": {
   "text": "Tenpin bowling and basketball on one cartridge, for two or three players, with a faster speed setting for the bowling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/tenpin-bowling-basketball-eur-philips-videopac-1980"
  }
 },
 "vp_51pl": {
  "input": "joystick",
  "manual": {
   "item": "attack-of-the-timelord-us-odyssey-2-1982",
   "pages": 12,
   "source": "Attack Of The Timelord! (US)(Odyssey 2)(1982)"
  },
  "video": {
   "id": "KczthmZiqdQ",
   "title": "Terrahawks (Videopac G7000/Odyssey²)[#51]"
  },
  "history": {
   "text": "The Timelord sends fleet after fleet through the warp, each better armed than the last — missiles and antimatter mines, then homing annihilators that have to be dodged rather than out-shot.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/attack-of-the-timelord-us-odyssey-2-1982"
  }
 },
 "vp_46": {
  "input": "mixed",
  "manual": {
   "item": "Great_Wall_Street_Fortune_Hunt_The_19xx_Magnavox_US",
   "pages": 24,
   "source": "The Great Wall Street Fortune Hunt (19xx)(Magnavox)(US)"
  },
  "video": {
   "id": "4Wy9e5BLSao",
   "title": "Magnavox Odyssey 2 - Philips Videopac - Great Wall Street Fortune Hunt (1982) (Videopac 46) Longplay"
  },
  "history": {
   "text": "A stock market game with real companies in it — IBM, McDonald's, Texas Instruments — alongside invented flyers like Wildcat Oil Western. The point is to read the swings fast enough to buy and sell well, and they run differently every time you play.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Great_Wall_Street_Fortune_Hunt_The_19xx_Magnavox_US"
  }
 },
 "vp_47": {
  "input": "joystick",
  "manual": {
   "item": "Mousing_Cat_The_1982_Philips_en-de",
   "pages": 8,
   "source": "The Mousing Cat (1982)(Philips)(en-de)"
  },
  "video": {
   "id": "hykj8xsWtk8",
   "title": "The Mousing Cat for the Philips Videopac"
  },
  "history": {
   "text": "Cat and mouse, in eight variations for one or two players, each at seven levels of difficulty. A game runs to six encounters.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Mousing_Cat_The_1982_Philips_en-de"
  }
 },
 "vp_60_16": {
  "input": "joystick",
  "manual": {
   "item": "trans-american-rally-eur-philips-videopac-1983",
   "pages": 24,
   "source": "Trans American Rally (EUR)(Philips Videopac+)(1983)"
  },
  "video": {
   "id": "7dErbkKtNCg",
   "title": "Jogo Videopac : Trans American Rally!"
  },
  "history": {
   "text": "A rally across America, run on fuel rather than laps: cover as much ground as you can before it runs out, and every collision costs. Five scores stay on the rally board, with room to type in the drivers' names.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/trans-american-rally-eur-philips-videopac-1983"
  }
 },
 "vp_12": {
  "input": "mixed",
  "video": {
   "id": "W3bq-6PGKb8",
   "title": "Take the Money and Run! for the Magnavox Odyssey² / Philips Videopac"
  }
 },
 "Vp40_F": {
  "input": "mixed",
  "manual": {
   "item": "Four_in_1_row_1982_Philips_EU",
   "pages": 4,
   "source": "Odyssey 2 Manual: 4 in 1 Row"
  },
  "video": {
   "id": "upoIpYcwjaE",
   "title": "Odyssey 2 - 4 in 1 Row © 1982 Philips - Gameplay"
  },
  "history": {
   "text": "Connect four, played by a pussycat and a hounddog. Drop a ball into a column each turn and try to line up four across, down or diagonally; the computer applauds the winner for as long as you hold the button down.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Four_in_1_row_1982_Philips_EU"
  }
 },
 "Vp05_F": {
  "note": "Runs on the <strong>G7000 BIOS</strong> (o2rom.bin) &mdash; on the G7400 one this cartridge freezes on a green screen right after SHUFFLE, because its shuffle routine calls a random-number generator that only exists inside the original G7000 BIOS. The vault switches BIOS for this title automatically. Play: press the number of players, type your bet on the number keys and press <span class='kbd'>Enter</span>; answer <em>HIT ?</em> and <em>DOUBLE ?</em> with the YES / NO keys, which are <span class='kbd'>Y</span> and <span class='kbd'>N</span> on your keyboard.",
  "bios": "o2rom.bin",
  "input": "mixed",
  "manual": {
   "item": "Blackjack_1978_Philips_en-de",
   "pages": 6,
   "source": "Blackjack (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Blackjack against the computer, which deals, keeps its second card hidden and does the banking. One or two players, aces count one or eleven, and you can draw to a maximum of five cards.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Blackjack_1978_Philips_en-de"
  },
  "video": {
   "id": "Z7Cb7ubFV-E",
   "title": "Las Vegas Blackjack for the Magnavox Odyssey² / Philips Videopac"
  }
 },
 "Vp11+_F": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "Vp11_F": {
  "input": "joystick",
  "manual": {
   "item": "cosmic-conflict-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Cosmic Conflict (EUR)(Philips Videopac)(1980)"
  },
  "history": {
   "text": "Cosmic Conflict!, known in Europe as Videopac 11 - Cosmic Conflict, is a 1978 first-person shoot 'em up video game created by Sam Overton for the Magnavox Odyssey², also known as the Philips Videopac G7000. It was published by Magnavox and Philips and later rereleased for the Philips Videopac+ G7400. The player is a commander of the Centurion, an Earth Federation starship that guards a remote corner of the galaxy and defends against an invading alien fleet trying to enslave the Earth. It is frequently criticized for being too easy and for ending after only fifteen enemies are destroyed.",
   "wikiTitle": "Cosmic Conflict",
   "url": "https://en.wikipedia.org/wiki/Cosmic_Conflict"
  },
  "video": {
   "id": "Kb7QDYYEfcc",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Cosmic Conflict! (1978) (Videopac 11) Longplay"
  }
 },
 "Vp29_F": {
  "input": "joystick",
  "manual": {
   "item": "Dambuster_1981_Philips_en-de",
   "pages": 16,
   "source": "Dam Buster (1981)(Philips)(en-de)"
  },
  "video": {
   "id": "46SY8ltwihU",
   "title": "Odyssey 2 / Videopac Dam Buster [Variation 0/2] 7"
  },
  "history": {
   "text": "One player has sixty seconds to knock as many blocks as possible out of a dam; the other defends it with a shield. Then the handsets swap and the other one tries.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Dambuster_1981_Philips_en-de"
  }
 },
 "Vp35_F": {
  "input": "joystick",
  "manual": {
   "item": "electronic-billiards-eur-philips-videopac-1981",
   "pages": 24,
   "source": "Electronic Billiards (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "1c4VL8be2XM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Pocket Billiards! (1980) (Videopac 35) Longplay"
  },
  "history": {
   "text": "Pool, in two games: 8-Ball and Rotation. The manual is firm that you never press the action button or a key while you are moving the joystick.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-billiards-eur-philips-videopac-1981"
  }
 },
 "Vp36_F": {
  "input": "joystick",
  "manual": {
   "item": "electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981",
   "pages": 28,
   "source": "Electronic Soccer | Electronic Ice Hockey (EUR)(Philips Videopac)(1981)"
  },
  "video": {
   "id": "B8s5zSQDGDg",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Electronic Table Soccer! (1980) (Videopac 27) Longplay"
  },
  "history": {
   "text": "Soccer and ice hockey, red against blue, played in five-minute periods with the clock counting down at the bottom of the screen. Hold the action button and the ball keeps travelling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/electronic-soccer-electronic-ice-hockey-eur-philips-videopac-1981"
  }
 },
 "Vp28_F": {
  "input": "joystick",
  "manual": {
   "item": "electronic-volleyball-eur-philips-videopac-1981",
   "pages": 18,
   "source": "Electronic Volleyball (EUR)(Philips Videopac)(1981)"
  },
  "history": {
   "text": "Volleyball!, known in Europe as Videopac 28 - Electronic Volleyball, is a 1980 volleyball video game created by Ed Averett and published by Magnavox and Philips for the Magnavox Odyssey 2 also known as the Philips Videopac G7000. Players either compete with each other or a computer opponent by controlling six volleyball players simultaneously. The game received mixed reviews from critics, some of whom praised its attempt to recreate the feel of the original sport while others criticized it for being too much like Pong.",
   "wikiTitle": "Volleyball!",
   "url": "https://en.wikipedia.org/wiki/Volleyball!"
  },
  "video": {
   "id": "U95KWXplSzk",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Volleyball! (1980) (Videopac 28) Longplay"
  }
 },
 "Vp24_F": {
  "input": "joystick",
  "manual": {
   "item": "Flipper_Game_1980_Philips_en-de",
   "pages": 6,
   "source": "Flipper Game (1980)(Philips)(en-de)"
  },
  "video": {
   "id": "IPfgNqdVI0s",
   "title": "Videopac (Odyssey 2) - Flipper (fast game - 1) - Gameplay (plus4punk)"
  },
  "history": {
   "text": "Pinball, with the whole television turned into a table. The four small coloured targets at the very top are worth four thousand points each and are correspondingly hard to hit.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Flipper_Game_1980_Philips_en-de"
  }
 },
 "Vp52+_F": {
  "input": "joystick",
  "manual": {
   "item": "killer-bees-eur-philips-videopac-1983",
   "pages": 16,
   "source": "Killer Bees (EUR)(Philips Videopac)(1983)"
  },
  "history": {
   "text": "Killer Bees! is a 1983 action video game written by Bob Harris for the Magnavox Odyssey², known in Europe as the Philips Videopac G7000. Players take on the role of a swarm of bees who must sting five robots to death while avoiding swarms of enemy bees. It was developed by Magnavox and published by Philips who also released it for the Philips Videopac+ G7400. In North America, the game is compatible with \"The Voice of Odyssey²\", an expansion module that adds synthesized voice lines.",
   "wikiTitle": "Killer Bees!",
   "url": "https://en.wikipedia.org/wiki/Killer_Bees!"
  },
  "video": {
   "id": "bewkGthH8WM",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Killer Bees! (1983) (Videopac 52) Longplay"
  }
 },
 "Vp23_F": {
  "input": "mixed",
  "manual": {
   "item": "las-vegas-gambling-eur-philips-videopac-1980",
   "pages": 6,
   "source": "Las Vegas Gambling (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "TEOy5nIPLzE",
   "title": "Las Vegas Gambling (Euro) ~ Casino Slot Machine! (USA) - Odyssey 2 [MESS] [shortplay]"
  },
  "history": {
   "text": "A slot machine for up to four players. Line up three symbols along any of five lines — three across and two diagonal — and the machine pays out coin by coin. The computer keeps your balance.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/las-vegas-gambling-eur-philips-videopac-1980"
  }
 },
 "Vp18_F": {
  "input": "joystick",
  "manual": {
   "item": "laser-war-eur-philips-videopac-1980",
   "pages": 24,
   "source": "Laser War (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "DbAOS72ffdE",
   "title": "Laser War (Videopac G7000/Odyssey²)[#18]"
  },
  "history": {
   "text": "Red and yellow fighters among asteroids. You fire when an asteroid takes your own craft's colour, and the flying saucer explodes when the laser catches it. The American release called it Invaders from Hyperspace.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/laser-war-eur-philips-videopac-1980"
  }
 },
 "Vp07_F": {
  "input": "keyboard",
  "manual": {
   "item": "mathematician-echo-eur-philips-videopac-1978",
   "pages": 12,
   "source": "Mathematician | Echo (EUR)(Philips Videopac)(1978)"
  },
  "video": {
   "id": "hue_65oFTZY",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Math-a-Magic! / Echo! (1978) (Videopac 7) Longplay"
  }
 },
 "Vp45_F": {
  "input": "keyboard",
  "manual": {
   "item": "Morse_1982_Philips_EU",
   "pages": 4,
   "source": "Morse (1982)(Philips)(EU)"
  },
  "history": {
   "text": "A Morse tutor. The computer sends a signal, and if you don't recognise it, repeats it as dots and dashes on screen and tells you the letter. You answer on the keyboard, and pick your speed to start.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Morse_1982_Philips_EU"
  },
  "video": {
   "id": "nFWY3uMvHQg",
   "title": "Morse for the Videopac"
  }
 },
 "Vp42_F": {
  "input": "mixed",
  "manual": {
   "item": "QuestForTheRingsManual1981",
   "pages": 28,
   "source": "The Quest for the Rings manual (1981) (Odyssey 2)"
  },
  "history": {
   "text": "Quest for the Rings is a fantasy themed board game/video game hybrid released in 1981 by Philips for the Magnavox Odyssey² also known as the Philips Videopac G7000. It is the first game in the \"Master Strategy\" series, a trio of video game/board game hybrids programmed by Ed Averett and designed by Steve Lehner and Rob Bradford for the Odyssey². In addition to the game cartridge, it was shipped with a physical game board and a number of tokens.",
   "wikiTitle": "Quest for the Rings",
   "url": "https://en.wikipedia.org/wiki/Quest_for_the_Rings"
  },
  "video": {
   "id": "k-m-_11Jjf8",
   "title": "Quest For The Rings Playthrough  - The Odyssey 2 hybrid board and video game from 1981!"
  }
 },
 "vp01+_F": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "QJECgFRqT5E",
   "title": "Race/Spin Out/Cryptogram (Videopac/Odyssey²) [#01]"
  }
 },
 "Vp01_F": {
  "input": "mixed",
  "manual": {
   "item": "Race_1978_Philips_en-de",
   "pages": 6,
   "source": "Race / Spin-out / Cryptogram (1978)(Philips)(en-de)"
  },
  "history": {
   "text": "Cartridge number 1 in the official Philips line of games for the Philips Videopac contains three games: Race, Spin-out, and Cryptogram. In the United States, it was distributed for the Magnavox Odyssey² as Speedway / Spin-out / Cryptologic.",
   "wikiTitle": "Race – Spin-out – Cryptogram",
   "url": "https://en.wikipedia.org/wiki/Race_%E2%80%93_Spin-out_%E2%80%93_Cryptogram"
  },
  "video": {
   "id": "QJECgFRqT5E",
   "title": "Race/Spin Out/Cryptogram (Videopac/Odyssey²) [#01]"
  }
 },
 "Vp25_F": {
  "input": "joystick",
  "manual": {
   "item": "Skiing_1980_Philips_en-de",
   "pages": 6,
   "source": "Skiing (1980)(Philips)(en-de)"
  },
  "history": {
   "text": "Slalom skiing for one or two players against the clock. Where the posts line up vertically you cut side to side between them; the action button accelerates, which is how you make back the time you lost.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Skiing_1980_Philips_en-de"
  },
  "video": {
   "id": "Mwq5VtmlN-I",
   "title": "Magnavox Odyssey 2 - Philips Videopac: Alpine Skiing! (1979) (Videopac 25) Longplay"
  }
 },
 "Vp06_F": {
  "input": "joystick",
  "manual": {
   "item": "tenpin-bowling-basketball-eur-philips-videopac-1980",
   "pages": 12,
   "source": "Tenpin Bowling | Basketball (EUR)(Philips Videopac)(1980)"
  },
  "video": {
   "id": "_SZMgiFthtY",
   "title": "Bowling! - (1978) - Odyssey 2 - gameplay HD"
  },
  "history": {
   "text": "Tenpin bowling and basketball on one cartridge, for two or three players, with a faster speed setting for the bowling.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/tenpin-bowling-basketball-eur-philips-videopac-1980"
  }
 },
 "Vp47_F": {
  "input": "joystick",
  "manual": {
   "item": "Mousing_Cat_The_1982_Philips_en-de",
   "pages": 8,
   "source": "The Mousing Cat (1982)(Philips)(en-de)"
  },
  "video": {
   "id": "hykj8xsWtk8",
   "title": "The Mousing Cat for the Philips Videopac"
  },
  "history": {
   "text": "Cat and mouse, in eight variations for one or two players, each at seven levels of difficulty. A game runs to six encounters.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Mousing_Cat_The_1982_Philips_en-de"
  }
 },
 "Vp12_F": {
  "input": "mixed",
  "video": {
   "id": "loYjAVIlQTo",
   "title": "Prendre l'Argent et Fuir (Fra) - Odyssey 2 [MESS] [shortplay]"
  }
 },
 "pal_flashpoint": {
  "input": "joystick",
  "video": {
   "id": "p5xGrl8uPFc",
   "title": "Videopac G7400 / Flash Point 31,337"
  }
 },
 "pal_acrobats": {
  "input": "joystick",
  "manual": {
   "item": "p.-t.-barnums-acrobats-us-odyssey-2-1982",
   "pages": 12,
   "source": "P. T. Barnum's Acrobats! (US)(Odyssey 2)(1982)"
  },
  "history": {
   "text": "Videopac 33 - Jumping Acrobats, known in North America as P.T. Barnum's Acrobats!, is 1981 action video game by Philips N.V. for the Philips Videopac G7000, also known as the Magnavox Odyssey². It is very similar to Exidy's arcade game Circus, itself a rethemed version of Atari's Breakout. In late 1982, it was rethemed around the entertainment properties of P.T. Barnum by the Odyssey Software Development Group for its North American release. This version also included compatibility with \"The Voice of Odyssey²\" expansion module.",
   "wikiTitle": "Jumping Acrobats",
   "url": "https://en.wikipedia.org/wiki/Jumping_Acrobats"
  },
  "video": {
   "id": "l3oVdXPTF2Q",
   "title": "Videopac (Odyssey 2) - Jumping Acrobats (Kunstspringer) [Game 9] - Gameplay (plus4punk)"
  }
 },
 "pal_nimble-numbers-ned": {
  "input": "keyboard",
  "manual": {
   "item": "nimble-numbers-ned",
   "pages": 16,
   "source": "Nimble Numbers Ned (US)(Odyssey 2)(1982)"
  },
  "history": {
   "text": "Nimble Numbers Ned!, also known as Nimble Numbers N.E.D., is an 1982 educational video game with platforming elements released by North American Philips for the Magnavox Odyssey². It was developed by Bob Harris and released exclusively in North America as a launch title for the Odyssey²'s voice synthesis module, \"The Voice\". Players guide the player character Ned over a series of numbered stones while avoiding barrels and answering math and geometry questions. It was designed in collaboration with the University of Tennessee, Knoxville for children grades 1-9. Contemporary reviews found it to be a good educational tool but were mixed on the quality of game itself.",
   "wikiTitle": "Nimble Numbers Ned!",
   "url": "https://en.wikipedia.org/wiki/Nimble_Numbers_Ned!"
  },
  "video": {
   "id": "t4c9hM429t0",
   "title": "Magnavox Odyssey 2: Nimble Numbers Ned (1982) Longplay"
  }
 },
 "pal_type-and-tell": {
  "input": "keyboard",
  "manual": {
   "item": "TypeTellOdyssey21982",
   "pages": 12,
   "source": "Type & Tell game manual Odyssey 2 (1982)"
  },
  "history": {
   "text": "Type and Tell! is a speech synthesis program released in 1982 for the Magnavox Odyssey². It was designed by Robert Cheezum for North American Philips and released exclusively in North America as a launch title for the Odyssey²'s voice synthesis module, \"The Voice of Odyssey²\". Users can enter a short phrase which the voice module will attempt to read. Critics thought it was too simple to hold anyone's attention for long but were entertained by getting the voice module to say a wide variety of things. The Voice plugged into the cartridge slot with the game plugged into it in turn; the O2EM core used here does not emulate it, so the cart runs but stays silent.",
   "wikiTitle": "Type & Tell!",
   "url": "https://en.wikipedia.org/wiki/Type_%26_Tell!"
  },
  "video": {
   "id": "sUDD8bdO0Yo",
   "title": "Type & Tell for the Magnavox Odyssey²"
  }
 },
 "pb_frogger": {
  "input": "joystick",
  "manual": {
   "item": "Frogger_1982_Parker_Brothers_EU",
   "pages": 10,
   "source": "Frogger (1982)(Parker Brothers)(EU)"
  },
  "history": {
   "text": "Parker Brothers' conversion of the Konami arcade game. Get the frog across the traffic, then across the river to the home bays. Five frogs to lose.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Frogger_1982_Parker_Brothers_EU"
  },
  "video": {
   "id": "cdvXm6SkWGE",
   "title": "Frogger Odyssey 2 Videopac Gameplay"
  }
 },
 "pb_popeye": {
  "input": "joystick",
  "manual": {
   "item": "Popeye_1983_Parker_Brothers_EU",
   "pages": 11,
   "source": "Popeye (1983)(Parker Brothers)(EU)"
  },
  "history": {
   "text": "You are Popeye, catching Olive Oyl's falling hearts before they hit the water — and staying clear of Brutus, who is trying to knock you overboard. Every hundred points moves you to a harder round.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Popeye_1983_Parker_Brothers_EU"
  },
  "video": {
   "id": "yoZv0FdZlWs",
   "title": "Popeye - Odyssey 2 - VGDB"
  }
 },
 "pb_q-bert": {
  "input": "joystick",
  "manual": {
   "item": "Q-Bert_1983_Parker_Brothers_EU",
   "pages": 9,
   "source": "Q*Bert (1983)(Parker Brothers)(EU)"
  },
  "video": {
   "id": "fC8A8vZBawE",
   "title": "Magnavox Odyssey 2 - Q*Bert - QBert - Philips Videopac - 8bit Retrogaming - Video Game - Odyssey II"
  },
  "history": {
   "text": "Parker Brothers' conversion, licensed from Mylstar. Hop Q*bert onto every cube until the whole pyramid has changed colour.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Q-Bert_1983_Parker_Brothers_EU"
  }
 },
 "pb_super-cobra": {
  "input": "joystick",
  "video": {
   "id": "SH3FI1PrTN4",
   "title": "Super Cobra Magnavox Odyssey 2 Gameplay"
  }
 },
 "pr_clay-pigeon_pl": {
  "input": "joystick",
  "manual": {
   "item": "62_PLUS_Clay_Pigeon_1984_Philips_EU",
   "pages": 4,
   "source": "Clay Pigeon (1984)(Philips)(EU)"
  },
  "video": {
   "id": "N4LtnZ1sdJ8",
   "title": "Clay Pigeon! for the Magnavox Odyssey²/Philips Videopac"
  },
  "history": {
   "text": "Clay pigeon shooting, aimed with the joystick — and not the quiet afternoon it looks like. The manual promises unexpected hazards, ducks among them.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/62_PLUS_Clay_Pigeon_1984_Philips_EU"
  }
 },
 "pr_clay-pigeon_pl_alt": {
  "input": "joystick",
  "manual": {
   "item": "62_PLUS_Clay_Pigeon_1984_Philips_EU",
   "pages": 4,
   "source": "Clay Pigeon (1984)(Philips)(EU)"
  },
  "video": {
   "id": "N4LtnZ1sdJ8",
   "title": "Clay Pigeon! for the Magnavox Odyssey²/Philips Videopac"
  },
  "history": {
   "text": "Clay pigeon shooting, aimed with the joystick — and not the quiet afternoon it looks like. The manual promises unexpected hazards, ducks among them.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/62_PLUS_Clay_Pigeon_1984_Philips_EU"
  }
 },
 "pr_interpol": {
  "input": "joystick",
  "manual": {
   "item": "Interpol_1984_Philips_FR",
   "pages": 3,
   "source": "Interpol (1984)(Philips)(FR)"
  },
  "video": {
   "id": "2aKKwBK33Y8",
   "title": "INTERPOL by GSTvideo for VIDEOPAC & ODYSSEY2."
  },
  "history": {
   "text": "A French cartridge, played as police against spies: two spies try to get out of the country with what they have stolen, while the police close the airport and the harbour to stop them leaving by air or sea.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Interpol_1984_Philips_FR"
  }
 },
 "pr_martian-threat_alt": {
  "input": "joystick",
  "video": {
   "id": "-n1FXbzdmJE",
   "title": "Martian Threat (PROTOTYPE!) for the Philips Videopac"
  }
 },
 "pr_martian-threat": {
  "input": "joystick",
  "video": {
   "id": "-n1FXbzdmJE",
   "title": "Martian Threat (PROTOTYPE!) for the Philips Videopac"
  }
 },
 "pr_mission-impossible": {
  "input": "joystick",
  "manual": {
   "item": "Mission_Impossible_2006_Humanoid_Games_en-de",
   "pages": 6,
   "source": "Mission Impossible / Programmed Trip (2006)(Humanoid Games)(en-de)"
  },
  "history": {
   "text": "An unreleased cartridge with a written-out setting: the year is 2425, the twelve known planets are colonised, and Earth is largely abandoned, kept as a staging post on the run between Mars and Venus.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Mission_Impossible_2006_Humanoid_Games_en-de"
  },
  "video": {
   "id": "DbmrAiLBr54",
   "title": "Mission Impossible  [prototype] ~ Magnavox Odyssey 2"
  }
 },
 "pr_nightfighter": {
  "input": "joystick",
  "video": {
   "id": "pgZrhf-ZXiI",
   "title": "Nightfighter (Euro, Prototype) - Odyssey 2 [MESS] [shortplay]"
  }
 },
 "pr_pinball": {
  "input": "joystick",
  "video": {
   "id": "juvol4UDWog",
   "title": "Videopac G7000 / Flipper Game [Slow] 248,110"
  },
  "note": "Nudge the ball into play with the <span class='kbd'>W</span> <span class='kbd'>A</span> <span class='kbd'>S</span> <span class='kbd'>D</span> joystick, and work the flippers with <span class='kbd'>G</span> — the two handsets split between launching and flipping."
 },
 "pr_playtag": {
  "input": "joystick",
  "video": {
   "id": "0WQ1hcMF-_8",
   "title": "Play Tag (PROTOTYPE!) for the Philips Videopac"
  }
 },
 "pr_red-baron": {
  "input": "joystick",
  "note": "This unreleased prototype shares its engine and title screen with <a href=\"game.html?id=vp_58_12\">Air Battle (VP58)</a>, so the same take-off drill applies: hold <span class='kbd'>&#8593;</span> (stick forward) to build speed, wait for the take-off indicator to flash, then pull <span class='kbd'>&#8595;</span> to climb.",
  "video": {
   "id": "xCFb7B_N-n8",
   "title": "Red Baron  [prototype] ~ Magnavox Odyssey 2"
  }
 },
 "pr_red-baron_alt": {
  "input": "joystick",
  "video": {
   "id": "xCFb7B_N-n8",
   "title": "Red Baron  [prototype] ~ Magnavox Odyssey 2"
  }
 },
 "pr_robot-city": {
  "input": "joystick",
  "video": {
   "id": "fDspASB-0YQ",
   "title": "Robot City (PROTOTYPE!) for the Philips Videopac"
  }
 },
 "pr_shark-hunter": {
  "input": "joystick",
  "video": {
   "id": "7xmm7FVlxiI",
   "title": "Shark Hunter Europe  Magnavox Odyssey 2 HYPERSPIN NOT MINE VIDEOSProto VIDEOPAC PHILIPS VIDEOPAC"
  }
 },
 "pr_spiderman_alt": {
  "input": "joystick",
  "manual": {
   "item": "Spiderman_198x_Parker_Brothers_EU",
   "pages": 5,
   "source": "Spider-Man (198x)(Parker Brothers)(EU)"
  },
  "video": {
   "id": "btS0vIHpAhg",
   "title": "Spider Man (Odyssey 2 /Videopac...emu) 102"
  },
  "history": {
   "text": "The Green Goblin has wired New York's skyscrapers with bombs. You climb as Spider-Man, and can shoot a web downwards to descend — but only once you have climbed up from where you started.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Spiderman_198x_Parker_Brothers_EU"
  }
 },
 "pr_spiderman": {
  "input": "joystick",
  "manual": {
   "item": "Spiderman_198x_Parker_Brothers_EU",
   "pages": 5,
   "source": "Spider-Man (198x)(Parker Brothers)(EU)"
  },
  "video": {
   "id": "btS0vIHpAhg",
   "title": "Spider Man (Odyssey 2 /Videopac...emu) 102"
  },
  "history": {
   "text": "The Green Goblin has wired New York's skyscrapers with bombs. You climb as Spider-Man, and can shoot a web downwards to descend — but only once you have climbed up from where you started.",
   "source": "the cartridge manual",
   "url": "https://archive.org/details/Spiderman_198x_Parker_Brothers_EU"
  }
 },
 "pr_tutankham": {
  "input": "joystick",
  "video": {
   "id": "6IgcEyfp8s0",
   "title": "Tutankham Videopac / Odyssey2"
  }
 },
 "csv1": {
  "input": "keyboard",
  "video": {
   "id": "5FbDu6vu8u4",
   "title": "Kinder im Verkehr 1 for the Philips Videopac"
  },
  "history": {
   "text": "Philips and CSV put a G7000 and two traffic-safety cartridges into primary schools in one small region of West Germany, to teach children how to behave on the road. They were never sold to the public and only a few hundred exist, which is why they are often left out of the released set altogether. This is the first of the two. It was later retitled Kinder im Verkehr 1 and given away to members of the German Commander-ROM club as Videopac \"V\".",
   "source": "Video Game Kraken — German games rarity list",
   "url": "https://videogamekraken.com/philips-videopac-german-games-rarity-list"
  }
 },
 "csv2": {
  "input": "keyboard",
  "video": {
   "id": "7IRqjZ0sAgU",
   "title": "Kinder im Verkehr 1 & 2 (Videopac/1981) - Verkehrserziehung einmal anders [Gameplay]"
  },
  "history": {
   "text": "Philips and CSV put a G7000 and two traffic-safety cartridges into primary schools in one small region of West Germany, to teach children how to behave on the road. They were never sold to the public and only a few hundred exist, which is why they are often left out of the released set altogether. The second cartridge never had a second life the way the first one did — it stayed exclusive to the school scheme, and is rated extremely rare.",
   "source": "Video Game Kraken — German games rarity list",
   "url": "https://videogamekraken.com/philips-videopac-german-games-rarity-list"
  }
 },
 "br_9434": {
  "input": "joystick",
  "video": {
   "id": "8iSp7y_FYCw",
   "title": "Modul 46: The Great Wall Street Fortune Hunt (European Videopac release)"
  },
  "history": {
   "text": "The sensitivity of different types of investments to this news is graphically demonstrated on an entirely new type of game board. This will give players the necessary information to make buying and selling decisions through the alphanumeric keyboard.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9434",
   "pages": 13,
   "source": "Wall Street - manual scan, odysseyclube.com"
  },
  "relatedTo": {
   "note": "Wall Street is the standalone Brazilian G7000 release of <a href=\"game.html?id=vp_46\">The Great Wall Street Fortune Hunt</a>, part of Philips' Master Strategy Series - see it there for the board, tokens and multi-language manual that shipped in other regions' boxes."
  }
 },
 "br_9461": {
  "input": "joystick",
  "video": {
   "id": "lCJkKrzsaIA",
   "title": "Bombardeio Submarino! + Tiro ao Alvo! - Videogame Odyssey"
  },
  "history": {
   "text": "Seven submerged submarines must be destroyed with the help of a cannon and a sight. The submarines are destroyed in parts and you have a load of 99 shots. Great skill is needed to not waste your ammunition.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9461",
   "pages": 9,
   "source": "Bombardeio Submarino! / Tiro ao Alvo! - manual scan, odysseyclube.com"
  }
 },
 "br_9462": {
  "input": "joystick",
  "video": {
   "id": "VGq72TL8jeQ",
   "title": "Desafio Chinês - Videogame Odyssey"
  },
  "history": {
   "text": "A true electronic puzzle, where the player fights against the clock to reorder the numbers with the minimum number of transfers possible. The numbers, which are at point \"A\" in descending order, must be transferred to point \"B\" in ascending order.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9462",
   "pages": 9,
   "source": "Desafio Chinês! - manual scan, odysseyclube.com"
  }
 },
 "br_9463": {
  "input": "joystick",
  "video": {
   "id": "xsvzIoMlB4s",
   "title": "O Malabarista / Jogo da Velha - Odyssey"
  },
  "history": {
   "text": "Here you can't pay too much attention: each ball passes through the maze and falls at any point, and must be caught by the juggler's hat. In 3 minutes, he must collect as many balls as possible!",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9463",
   "pages": 9,
   "source": "O Malabarista! / Jogo da Velha! - manual scan, odysseyclube.com"
  }
 },
 "br_9468": {
  "input": "joystick",
  "history": {
   "text": "Telegrapher is a simple, enjoyable, and step-by-step game for you to learn while playing something very serious. It's Morse Code, a universal communication system through which you can communicate.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9468",
   "pages": 13,
   "source": "Telegrafista! - manual scan, odysseyclube.com"
  },
  "video": {
   "id": "nFWY3uMvHQg",
   "title": "Morse for the Videopac"
  }
 },
 "br_9469": {
  "input": "joystick",
  "video": {
   "id": "hykj8xsWtk8",
   "title": "The Mousing Cat for the Philips Videopac (European release)"
  },
  "history": {
   "text": "In this exciting chase, the agile Mouse also has his weapons. To defend himself from Mr. Cat's threats, he must eat all the pieces of cheese that appear in his path.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9469",
   "pages": 13,
   "source": "O Gato e o Rato! - manual scan, odysseyclube.com"
  }
 },
 "br_9472": {
  "input": "joystick",
  "video": {
   "id": "eyB9yabbR8k",
   "title": "Super Bee - Odyssey Philips | Super Bee - Videopac"
  },
  "history": {
   "text": "Flying through a tangle of plants, the cheerful little bee follows her daily path in search of precious fruits that will feed her. During this super flight, you will have the mission of helping her.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9472",
   "pages": 9,
   "source": "Super Bee! - manual scan, odysseyclube.com"
  }
 },
 "br_9473": {
  "input": "joystick",
  "video": {
   "id": "lqACc54g6SU",
   "title": "Buraco Negro - Videogame Odyssey"
  },
  "history": {
   "text": "The great challenge of this space mission is to unravel the mystery of the Black Hole. Large meteorites appear at every moment and must be destroyed or led into the gravitational field of the Black Hole.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9473",
   "pages": 9,
   "source": "Buraco Negro! - manual scan, odysseyclube.com"
  }
 },
 "br_9474": {
  "input": "joystick",
  "video": {
   "id": "N4LtnZ1sdJ8",
   "title": "Clay Pigeon! for the Magnavox Odyssey² / Philips Videopac"
  },
  "history": {
   "text": "Grab the gun and take good aim at the plates. Otherwise, they will fall on your head, leaving you stunned. But the worst is yet to come, and it's good to have plenty of ammunition.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9474",
   "pages": 9,
   "source": "Clay Pigeon! - manual scan, odysseyclube.com"
  }
 },
 "br_9475": {
  "input": "joystick",
  "video": {
   "id": "HP8hLD5YdEA",
   "title": "Comando Noturno - Videogame Odyssey"
  },
  "history": {
   "text": "You are commanding your airplane at night and your mission is to destroy enemy bases. A game where the suspense is ever-growing and you need to defend yourself from the terrible obstacles that appear.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9475",
   "pages": 13,
   "source": "Comando Noturno! - manual scan, odysseyclube.com"
  }
 },
 "br_9476": {
  "input": "joystick",
  "video": {
   "id": "ccf2PbOQ-4E",
   "title": "Loony Balloon a.k.a. Balão Travesso - Odyssey 2"
  },
  "history": {
   "text": "All cheerful, the child enters the amusement park carrying her mischievous balloon. Between playing on the carousel, the slide, or the rocking horse - which score points - she has to take her balloon along.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9476",
   "pages": 9,
   "source": "Balão Travesso! - manual scan, odysseyclube.com"
  }
 },
 "br_9477": {
  "input": "joystick",
  "video": {
   "id": "0Sij7J6v3_M",
   "title": "Modul 58: Air Battle (European Videopac release)"
  },
  "history": {
   "text": "Your airplane will run along the bumpy runway. You must keep it on track until you reach the ideal speed to take off. In the air, you will face the planes of the fearsome Red Baron squadron.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9477",
   "pages": 9,
   "source": "Barão Vermelho! - manual scan, odysseyclube.com"
  }
 },
 "br_9483": {
  "input": "joystick",
  "video": {
   "id": "BXL_xYHQ7wc",
   "title": "Frogger - Videogame Odyssey"
  },
  "history": {
   "text": "A very fun and exciting game, in which you have to use all your skill and very fast reflexes to bring the little frogs home safely. It's not easy: they have to cross with fast jumps a busy highway.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9483",
   "pages": 13,
   "source": "Frogger - manual scan, odysseyclube.com"
  }
 },
 "br_9484": {
  "input": "joystick",
  "history": {
   "text": "In this action-packed game, you have to make Popeye go up and down stairs, cross beams, and escape from the bottles thrown by his enemy Brutus - all to win the heart of his beloved Olive Oyl.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9484",
   "pages": 9,
   "source": "Popeye - manual scan, odysseyclube.com"
  },
  "video": {
   "id": "yoZv0FdZlWs",
   "title": "Popeye - Odyssey 2 - VGDB"
  }
 },
 "br_9485": {
  "input": "joystick",
  "video": {
   "id": "xpwqv0X0pDk",
   "title": "Q*Bert - Odyssey 2 (VGDB)"
  },
  "history": {
   "text": "You have 7 Q*Berts to change the colors of the pyramid cubes, from an initial color to a target color. But there are several obstacles along the way - Red Danger, Purple Danger, Slick, Jumper, and more.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9485",
   "pages": 9,
   "source": "Q*bert - manual scan, odysseyclube.com"
  }
 },
 "br_9486": {
  "input": "joystick",
  "video": {
   "id": "OtVSLf09fyI",
   "title": "Super Cobra - Videogame Odyssey"
  },
  "history": {
   "text": "Here you will test your skill as an aviation ace, living an adventure with 13 miles of obstacles in a raid through enemy territory. Steep mountains, tall buildings, and irregular tunnels are barriers.",
   "url": "https://odysseyclube.com/en/colecoes/philips-brasil",
   "source": "Odyssey Clube"
  },
  "manual": {
   "item": "br_9486",
   "pages": 9,
   "source": "Super Cobra - manual scan, odysseyclube.com"
  }
 },
 "c64_boulder_dash": {
  "input": "joystick",
  "video": {
   "id": "evvZDmVWHbo",
   "title": "Boulder Dash (C64 Longplay)"
  },
  "history": {
   "text": "Guide Rockford through caves of dirt, boulders and diamonds where every block you loosen obeys ruthless gravity. Written by Peter Liepa with Chris Gray and published by First Star in 1984, it became one of the few home-computer originals ported TO the arcades rather than from them, and it is still the gold standard of the dig-and-dodge genre."
  }
 },
 "c64_impossible_mission": {
  "input": "joystick",
  "video": {
   "id": "WXZjocPhAE4",
   "title": "Impossible Mission (C64 Longplay)"
  },
  "history": {
   "text": "\"Another visitor! Stay a while... stay FOREVER!\" Dennis Caswell's agents somersault past killer robots in Elvin Atombender's stronghold, searching furniture for puzzle pieces before the world ends. Its digitised speech and fluid rotoscoped animation felt like witchcraft in 1984, and the sampled scream on falling still lands."
  }
 },
 "c64_last_ninja": {
  "input": "joystick",
  "video": {
   "id": "sUHfSygbSBo",
   "title": "Commodore 64 Longplay [026] The Last Ninja (EU)"
  },
  "history": {
   "text": "An isometric quest of combat and cunning as Armakuni sets out to avenge his slaughtered clan. Gorgeous scenery, notoriously precise jumps across streams, and a Ben Daglish / Anthony Lees soundtrack that regularly tops lists of the best SID music ever written. One of the best-selling C64 games of all."
  }
 },
 "c64_wizball": {
  "input": "joystick",
  "video": {
   "id": "BAwz1Qlxfbw",
   "title": "Commodore 64 Longplay [282] Wizball (EU)"
  },
  "history": {
   "text": "A grey, joyless world needs its colour back, and only a bouncing wizard-in-a-ball and his cat Nifta can restore it. Sensible Software's shooter starts maddening and becomes sublime — it plays like nothing before or since, and Martin Galway's title tune is among the most loved on the machine. Zzap!64's Game of the Year for 1987."
  }
 },
 "c64_uridium": {
  "input": "joystick",
  "video": {
   "id": "u7fbvTYWFe0",
   "title": "Uridium (C64 Longplay)"
  },
  "history": {
   "text": "Pilot the Manta fighter across the hulls of fifteen enemy super-dreadnoughts in the slickest-scrolling shooter the C64 ever saw. Andrew Braybrook's metallic sheen and buttery 50fps scrolling made owners of rival machines openly jealous, and the flip-to-dodge manoeuvre still feels great."
  }
 },
 "c64_paradroid": {
  "input": "joystick",
  "video": {
   "id": "gCdIXJsIuu0",
   "title": "C64-Longplay - Paradroid (720p)"
  },
  "history": {
   "text": "Board a drifting freighter fleet and clear it of rogue robots — not by outgunning them, but by hijacking their bodies through a brilliant circuit-logic transfer mini-game. Braybrook's masterpiece was endlessly imitated and never bettered; Zzap!64 eventually rated it the best C64 game of all time."
  }
 },
 "c64_turrican2": {
  "input": "joystick",
  "video": {
   "id": "JIaabMWupmQ",
   "title": "Commodore 64 Longplay [004] Turrican II: The Final Fight (EU)"
  },
  "history": {
   "text": "Manfred Trenz pushed the C64 far past what anyone thought possible: vast multidirectional levels, screen-filling bosses, a morph-into-a-wheel mode, and Markus Siebold's thunderous SID rendition of Chris Hülsbeck's score. The machine's late-era technical high-water mark."
  }
 },
 "c64_maniac_mansion": {
  "input": "joystick",
  "video": {
   "id": "0dVqe4a4oDo",
   "title": "Commodore 64 Longplay [378] Maniac Mansion (US)"
  },
  "history": {
   "text": "Break into Dr. Fred's mansion to rescue a kidnapped cheerleader, armed with three playable teenagers and the very first SCUMM engine — written by Ron Gilbert on this machine. Hamster jokes, meteor police and multiple endings: the entire LucasArts adventure tradition starts here, on the C64. The Edison mansion itself was modelled on the Main House at Skywalker Ranch, and the Computer History Museum counts this among the best-known of all haunted-house games — a theme video games had been chasing since the very first Odyssey console in 1972.",
   "source": "Chris Garcia, Computer History Museum",
   "url": "https://computerhistory.org/blog/the-haunted-house/"
  }
 },
 "c64_zak_mckracken": {
  "input": "joystick",
  "note": "Zak is a three-disk game, so the single boot disk wouldn&rsquo;t start. This is the OneLoad64 cartridge with every disk built in. Let the intro run to the menu, then with <strong>ZAK McKRACKEN</strong> highlighted at the top press <strong>G</strong> (fire) to launch it. It&rsquo;s point-and-click: move the cursor with the joystick, <strong>G</strong> to select.",
  "video": {
   "id": "5iB768s266k",
   "title": "Commodore 64 Longplay [379] Zak McKracken and the Alien Mindbenders (US)"
  },
  "history": {
   "text": "A tabloid journalist, aliens running a stupidity machine that slowly dumbs down humanity, and a broken French bread that doubles as a puzzle item. David Fox's globe-trotting SCUMM adventure sends Zak from Seattle to Mars with a smirk the whole way."
  }
 },
 "c64_elite": {
  "input": "joystick",
  "note": "Right after it loads you'll hit a red <strong>DO YOU WANT TO USE THE FAST LOADER? (Y/N)</strong> screen &ndash; press <strong>N</strong>. Elite's own fast loader talks to the disk drive directly, and this vault runs disks in a quick virtual-device mode (so every other game loads instantly) that can't keep up with it, so <strong>Y</strong> just sits there forever with no error and no way out. <strong>N</strong> uses the normal loader instead &ndash; a few seconds slower, but it actually reaches the title screen and &lsquo;Load New Commander (Y/N)?&rsquo;.",
  "video": {
   "id": "LhTTpV5qFrs",
   "title": "C64-Longplay - Elite (720p)"
  },
  "history": {
   "text": "Eight galaxies, thousands of planets, and total freedom to trade, smuggle or turn pirate — squeezed into 64K of wireframe 3D. Braben and Bell's game invented the open-ended space sim, and the 1985 C64 conversion is its definitive 8-bit home. Right on, Commander."
  }
 },
 "c64_ik_plus": {
  "input": "joystick",
  "video": {
   "id": "FMGI0HoXNBA",
   "title": "Commodore 64 Longplay [035] IK+ (EU)"
  },
  "history": {
   "text": "Three karateka on screen at once, fighting simultaneously with razor-sharp controls, Rob Hubbard music and sly humour — wait for the fish, and mind the trousers falling down. Archer Maclean's masterpiece remains one of the finest fighting games of the 8-bit era."
  }
 },
 "c64_bruce_lee": {
  "input": "joystick",
  "note": "Cracked release: press <strong>G</strong> (fire) at the REMEMBER intro to reach the DOCUMENTS screen, then start with the C64 <strong>RUN/STOP</strong> key — press <strong>Right Shift</strong> for the on-screen keyboard, arrow to <em>R/S</em> and press Enter. In game: joystick moves, hold a direction + G to punch or kick, push up to jump.",
  "video": {
   "id": "s7RCUa50lf0",
   "title": "Bruce Lee (C64 Longplay)"
  },
  "history": {
   "text": "Collect lanterns through twenty chambers while a ninja and the waddling Green Yamo hound your every step. Short, stylish and endlessly replayable — and player two controls the Yamo, an arrangement few friendships survived intact."
  }
 },
 "c64_commando": {
  "input": "joystick",
  "video": {
   "id": "ZkC7yqlHOD0",
   "title": "Commodore 64 Longplay [048] Commando (EU)"
  },
  "history": {
   "text": "Capcom's arcade assault crammed into the C64 by Chris Butler in a matter of weeks for Christmas 1985 — and elevated to legend by Rob Hubbard's driving SID anthem, a soundtrack many rate above the game itself. The game, for the record, is very good."
  }
 },
 "c64_bubble_bobble": {
  "input": "joystick",
  "video": {
   "id": "s6vTqG17cB4",
   "title": "Commodore 64 Longplay [143] Bubble Bobble (EU)"
  },
  "history": {
   "text": "Bub and Bob blow bubbles through a hundred single-screen caves in the definitive couch co-op game of the eighties. The C64 port of Taito's arcade hit nails the charm, the chaos, and that melody you will be humming for a week."
  }
 },
 "c64_giana_sisters": {
  "input": "joystick",
  "video": {
   "id": "QL3fje5WRrY",
   "title": "Commodore 64 Longplay [001] The Great Giana Sisters (EU)"
  },
  "history": {
   "text": "The platformer so shamelessly close to a certain plumber that legal pressure saw it pulled from sale, making original copies collector's gold. Beneath the notoriety sit tight controls, Manfred Trenz level design and a Chris Hülsbeck title tune for the ages."
  }
 },
 "c64_katakis": {
  "input": "joystick",
  "video": {
   "id": "BYr_QA1748U",
   "title": "Commodore 64 Longplay [006] Katakis (EU)"
  },
  "history": {
   "text": "Manfred Trenz's answer to R-Type — so convincing that Activision's lawyers came knocking, and so good that the same team was then hired to make the official R-Type conversion. Twelve sectors of gorgeous, ferocious blasting."
  }
 },
 "c64_creatures": {
  "input": "joystick",
  "video": {
   "id": "JEHo7A4ydvE",
   "title": "Commodore 64 Longplay [018] Creatures (EU)"
  },
  "history": {
   "text": "Clyde Radcliffe rescues his fellow Fuzzy Wuzzies from gloriously grisly torture screens in a platformer dripping with colour, character and cheerfully macabre humour. The Rowlands brothers at full power, on hardware everyone else had written off."
  }
 },
 "c64_mayhem": {
  "input": "joystick",
  "video": {
   "id": "UBEVxH5ORnw",
   "title": "Commodore 64 Longplay [024] Mayhem in Monsterland (EU)"
  },
  "history": {
   "text": "A console-quality platformer released when the C64 was supposedly dead, moving at speeds the hardware had no right to reach. Commodore Format famously scored it 100% — the machine's glorious commercial swan song."
  }
 },
 "c64_archon": {
  "input": "joystick",
  "note": "Cracked release with a scrolling intro. Start it with the C64 <strong>RUN/STOP</strong> key — press <strong>Right Shift</strong> for the on-screen keyboard, arrow to <em>R/S</em> and press Enter. Then it's chess-with-combat: joystick to move a piece, G to select and to fight.",
  "video": {
   "id": "RSy1Jma6iL0",
   "title": "Archon: The Light and the Dark (C64 Longplay)"
  },
  "history": {
   "text": "Chess where the pieces fight back: land on an occupied square and the two pieces battle it out arcade-style, with the board's shifting light cycle tilting the odds. One of Electronic Arts' launch titles, and a two-player classic that still fills a living room with shouting."
  }
 },
 "c64_mule": {
  "input": "joystick",
  "video": {
   "id": "AWeqk7EBKBU",
   "title": "C-64 M.U.L.E. Longplay - Beginner difficulty"
  },
  "history": {
   "text": "Four settlers colonise the planet Irata through land grabs, mule-powered farming and tense real-time auctions. Dan Bunten's supply-and-demand masterclass was decades ahead of its time — and is somehow riotous fun with four players around one machine."
  }
 },
 "c64_california_games": {
  "input": "joystick",
  "note": "The plain c64.com dump was one side of a multi-disk crack and kept asking to insert another side. This is the ESI &lsquo;side-load&rsquo; version — everything on one disk, no swapping. Press <strong>Space</strong> to click through the two crack-intro screens and it loads. Then joystick + <strong>G</strong> to play; on the roster/ceremony screen, wiggle the joystick to take part.",
  "video": {
   "id": "1i2aZ-Ivncs",
   "title": "California Games (C64 Longplay)"
  },
  "history": {
   "text": "Epyx traded Olympic solemnity for halfpipes, footbags and rolling BMX wipeouts, all set to a SID rendition of Louie Louie. The most laid-back entry in the Games series — and the best-selling one."
  }
 },
 "c64_winter_games": {
  "input": "joystick",
  "video": {
   "id": "VbYgwJFXrW0",
   "title": "Winter Games (C64 Longplay)"
  },
  "history": {
   "text": "Ski jump face-plants, biathlon rhythm and the fiendish triple loop of figure skating — Epyx's winter Olympiad shines in its event variety and that stately opening ceremony everyone let play through at least once."
  }
 },
 "c64_pitstop2": {
  "input": "joystick",
  "video": {
   "id": "zI6zmRHUWaw",
   "title": "Pitstop II (C64 Longplay)"
  },
  "history": {
   "text": "The first great split-screen racer: watch your tyres change colour as they wear, dive into the pits, and fumble the fuel hose while your rival streaks past on the other half of the screen."
  }
 },
 "c64_defender_crown": {
  "input": "joystick",
  "video": {
   "id": "60ih81-o04g",
   "title": "Defender of the Crown (C64 Longplay)"
  },
  "history": {
   "text": "Saxons versus Normans in Cinemaware's interactive movie of jousts, castle sieges and midnight raids. The C64 version trims the Amiga original's gloss but keeps the swashbuckling heart intact."
  }
 },
 "c64_barbarian": {
  "input": "joystick",
  "video": {
   "id": "9Yn4FLp-0aY",
   "title": "Barbarian - The Ultimate Warrior (C64 Longplay)"
  },
  "history": {
   "text": "Sword-fighting with a flying head-lop finisher and a goblin who punts the remains off-screen. Maria Whittaker's box art scandalised the British tabloids; the head-rolling two-player mode scandalised nobody's sleepover schedule whatsoever."
  }
 },
 "c64_microprose_soccer": {
  "input": "joystick",
  "video": {
   "id": "CcfFEecaYPc",
   "title": "Microprose Soccer - C64 Longplay / Walkthrough"
  },
  "history": {
   "text": "Overhead football with outrageous after-touch banana shots and a six-a-side indoor mode. Sensible Software's first crack at the beautiful game — the direct ancestor of Sensible Soccer, so the entire future of top-down footy starts here."
  }
 },
 "c64_paperboy": {
  "input": "joystick",
  "note": "Start with the C64 <strong>RUN/STOP</strong> key — press <strong>Right Shift</strong> for the on-screen keyboard, arrow to <em>R/S</em> and press Enter. Then joystick to steer and pedal, G to throw papers.",
  "video": {
   "id": "_djAJNxWKm8",
   "title": "Commodore 64 Longplay [214] Paperboy (EU)"
  },
  "history": {
   "text": "Atari Games' arcade hit brought home by Elite: pedal down Easy Street lobbing the Daily Sun onto subscribers' doormats and through the windows of everyone who dared cancel. The 1986 C64 port, with Mark Cooksey's take on the arcade tune, became one of Elite's biggest sellers — breakables and all."
  }
 },
 "c64_test_drive": {
  "input": "joystick",
  "note": "This is the OneLoad64 cartridge (the old cracked disk wouldn't load). It boots straight to a menu — pick <strong>test drive (tape)</strong> by pressing <strong>Down</strong> then <strong>G</strong> to launch (the &lsquo;disk&rsquo; entry\'s loader stalls in the browser). In the game: <strong>+</strong> / <strong>&minus;</strong> select a car, <strong>S</strong> to start driving.",
  "video": {
   "id": "drLKG0EKKMg",
   "title": "C64 Longplay - Test Drive"
  },
  "history": {
   "text": "Pick a Ferrari Testarossa, Lamborghini Countach or Porsche 911 Turbo and blast up a cliffside highway, dodging traffic and radar cops between fuel stops. Distinctive Software's 1987 original founded the entire Test Drive franchise — and the same Vancouver studio later built the first Need for Speed."
  }
 },
 "c64_target_renegade": {
  "input": "joystick",
  "video": {
   "id": "2qXyop3y1As",
   "title": "Commodore 64 Longplay [065] Target: Renegade (EU)"
  },
  "history": {
   "text": "A vengeful street brawler drags Renegade hero Mister X through pool halls and back alleys to rescue his girlfriend from a crime boss, mixing one-on-one beat-em-up combat with light platforming. Published by Imagine Software (an Ocean Software label) in 1988 as the sequel to the Renegade arcade conversion, the C64 version dropped the two-player mode found elsewhere but was still praised for capturing the arcade's punchy combat feel."
  }
 },
 "c64_sword_of_fargoal": {
  "input": "joystick",
  "video": {
   "id": "SZzDwAKaslM",
   "title": "C64-Longplay - Sword Of Fargoal"
  },
  "history": {
   "text": "Descend a randomly-regenerating dungeon in search of the titular sword, fighting monsters and hauling treasure back to the surface before a time limit expires. Written by Jeff McCord and published by Epyx, it predates Rogue's PC popularity on home micros and is regarded as one of the earliest and most influential roguelike-style dungeon crawlers on 8-bit hardware."
  }
 },
 "c64_shadow_of_the_beast": {
  "input": "joystick",
  "video": {
   "id": "8sBqUFlzPlw",
   "title": "Commodore 64 Longplay [047] Shadow of the Beast (EU)"
  },
  "history": {
   "text": "Stripped of its Amiga original's multi-plane parallax scrolling, this C64 conversion still delivers the same grim revenge story of a man transformed into a beast fighting through a nightmarish world. Handled by DMA Design (later of Grand Theft Auto and Lemmings fame) and published by Psygnosis in 1990, it's remembered more as a technical curiosity than as a great C64 game in its own right."
  }
 },
 "c64_operation_wolf": {
  "input": "joystick",
  "video": {
   "id": "KCUJawJq-Ng",
   "title": "Commodore 64 Longplay [080] Operation Wolf (US)"
  },
  "history": {
   "text": "Mow down an endless tide of soldiers and hostages-you'd-better-not-shoot with a stationary machine gun, converted from Taito's arcade light-gun cabinet down to joystick control. Published by Ocean Software in 1988, it swaps the arcade's plastic Uzi for a fire button but keeps the frantic pacing, and became one of the C64's best-selling shooters despite the inevitable loss of the light-gun's precision."
  }
 },
 "c64_double_dragon": {
  "input": "joystick",
  "video": {
   "id": "BQbVgyBfKLA",
   "title": "Double Dragon Longplay (C64: Binary Design) [50 FPS]"
  },
  "history": {
   "text": "Billy and Jimmy Lee punch and kick their way through city streets to rescue Marian from the Black Warriors gang, in a conversion of Technos' seminal arcade brawler. Published by Melbourne House in 1988 after a troubled development that saw the original build scrapped and secretly rebuilt by uncredited programmers \"Ash and Dave\" in six weeks, it was savaged by critics on release and stands as a cautionary tale of a rushed arcade port."
  }
 },
 "c64_spy_vs_spy": {
  "input": "joystick",
  "video": {
   "id": "PhIwB52iUjc",
   "title": "Spy vs Spy (C64) - Longplay"
  },
  "history": {
   "text": "Two agents ransack the same embassy, racing to find the briefcase, gun and passport while booby-trapping rooms against each other. Programmed by Michael Riedel and published by First Star Software in 1984, it pioneered the split-screen simultaneous two-player format, later spawning two sequels and a lasting rivalry-game formula."
  }
 },
 "c64_ghostbusters": {
  "input": "joystick",
  "video": {
   "id": "X1jKHHeufS0",
   "title": "C64 Longplay - Ghostbusters"
  },
  "history": {
   "text": "Drive Ecto-1 across town catching roaming ghosts and stopping a giant Marshmallow Man before Manhattan floods with slime. Designed by David Crane and published by Activision in 1984, it was one of the first games built directly off a movie license with input from the film's producers, and its business-management layer made it an early hybrid of action and simulation."
  }
 },
 "c64_pool_of_radiance": {
  "input": "joystick",
  "video": {
   "id": "pF7jt4UBbFA",
   "title": "Commodore 64 Longplay SSI Pool Of Radiance 1988"
  },
  "history": {
   "text": "Lead a six-member party through the ruins of New Phlan, fighting turn-based battles and building toward a showdown with the tyrant Tyranthraxus. Released by SSI in 1988, it was the first AD&D \"Gold Box\" computer RPG and set the template that the whole subgenre followed for the next decade. Note: an 8-disk game; only disk 1 is wired up for boot/character-creation so far, the rest sit alongside it for manual swapping."
  }
 },
 "c64_turrican": {
  "input": "joystick",
  "video": {
   "id": "_0Cs0z3AnxU",
   "title": "Turrican I - Longplay - C64 - (1990) - Walkthrough"
  },
  "history": {
   "text": "Armored warrior Turrican blasts, rolls and grapples through sprawling side-scrolling levels crawling with bio-mechanical enemies, using a screen-clearing Lightning smart-bomb as his signature move. Designed and programmed by Manfred Trenz for Factor 5 and published by Rainbow Arts in 1990, it pushed the C64 far past its supposed limits and is widely considered the platform's best action game."
  }
 },
 "c64_wasteland": {
  "input": "joystick",
  "video": {
   "id": "WRqYoeJAHdQ",
   "title": "C64-Longplay - Wasteland (720p)"
  },
  "history": {
   "text": "Survive a nuclear wasteland as a squad of Desert Rangers, cross-referencing numbered paragraphs from a printed book for story text the disks couldn't hold. Developed by Interplay and published by Electronic Arts in 1988, it introduced a skill-based, consequence-driven RPG structure years ahead of its time and is a direct ancestor of Fallout."
  }
 },
 "c64_dropzone": {
  "input": "joystick",
  "video": {
   "id": "MNTpt69sTiY",
   "title": "C64 Longplay - Dropzone (HQ)"
  },
  "history": {
   "text": "Trapped astronauts need rescuing from a hostile alien base while you blast waves of attackers in a single-screen arena, Robotron-meets-Defender style. Archer Maclean coded it first on the Atari 8-bit under the alias Arena Graphics before personally converting it to the C64, and U.S. Gold published both. Its unforgiving difficulty curve and tight joystick control made it a benchmark for skill-based arcade action on 8-bit home computers."
  }
 },
 "c64_laser_squad": {
  "input": "joystick",
  "video": {
   "id": "UENotBtsnyE",
   "title": "C64-Longplay - Laser Squad (720p)"
  },
  "history": {
   "text": "Command a small tactical squad through turn-based, action-point-driven firefights across five scenarios of increasing complexity. Written by Julian Gollop with his brother Nick handling the C64 conversion, and originally published by Target Games in 1988, it laid the groundwork for the systems Gollop would later expand into X-COM, and remains a landmark for introducing genuinely tactical, line-of-sight combat to home computers."
  }
 },
 "c64_congo_bongo": {
  "input": "joystick",
  "video": {
   "id": "gG01_Z1jmik",
   "title": "C64 Longplay - Congo Bongo (HQ)"
  },
  "history": {
   "text": "Climb, jump and dodge across an isometric jungle as an explorer being pelted by a vengeful gorilla, in Sega's pseudo-3D answer to Donkey Kong. Sega published the C64 cartridge conversion in 1983. Its skewed perspective made platform judging notoriously tricky, giving it a reputation as one of the harder early-80s arcade ports on the system."
  }
 },
 "c64_frogger": {
  "input": "joystick",
  "video": {
   "id": "efx9Z6TACPo",
   "title": "Longplay of Frogger (Sierra)"
  },
  "history": {
   "text": "Hop a frog through speeding traffic and a log-strewn river to reach home safely, one of the defining \"cross the screen alive\" designs of the arcade era. Sierra On-Line licensed Konami/Sega's 1981 arcade hit and had Chuck Benton program this C64 conversion in 1983. Its simple rules and split-second timing made it one of the most widely ported games of its generation."
  }
 },
 "c64_castle_wolfenstein": {
  "input": "joystick",
  "note": "This one's keyboard-only in disguise. Press <strong>Tab</strong> (Game Focus) the moment it loads &ndash; without it, RETURN and several other keys are grabbed as joystick input before they ever reach the C64, so &lsquo;PRESS RETURN TO BEGIN&rsquo; just sits there. With Game Focus on: <strong>Return</strong> to begin, <strong>Ctrl+N</strong> for a new game, then <strong>K</strong> for keyboard control (or <strong>J</strong> for joystick &ndash; but you'll still need the keyboard to actually fire). Movement isn't arrows or WASD, it's a 3&times;3 block: <strong>E R T</strong> / <strong>D F G</strong> / <strong>C V B</strong> (up-left/up/up-right, left/stop/right, down-left/down/down-right &ndash; F halts). Fire is the C64's own &larr; key, top-left of the keyboard, not the cursor arrows &ndash; easiest to reach via the on-screen keyboard (<strong>Right Shift</strong>) if your keyboard doesn't have one. <strong>Q</strong> throws a grenade, <strong>Space</strong> searches bodies/doors/chests, <strong>Return</strong> checks your inventory, and <strong>RUN/STOP</strong> saves your position and quits. Keep Game Focus on throughout &ndash; several of these (G, T, Q) double as this vault's joystick keys otherwise.",
  "video": {
   "id": "tJNAXh-LVnk",
   "title": "C64 Longplay - Castle Wolfenstein (HQ)"
  },
  "history": {
   "text": "Sneak, bluff and shoot your way out of a Nazi fortress, stealing disguises and secret plans while guards patrol a randomized, replayable layout. Written by Silas Warner and published by Muse Software in 1983, it introduced stealth mechanics to computer gaming years before the term existed, and its title and premise were later revived — and radically reinvented — as id Software's Wolfenstein 3D."
  }
 },
 "c64_blood_money": {
  "input": "joystick",
  "note": "A dual-plane side-scrolling shooter &ndash; your ship can shift between two parallel layers, so half the challenge is picking which plane to be on. Press <strong>1</strong> for 1-player from the title screen once the credits finish drawing in.",
  "video": {
   "id": "an7SVBWH_lE",
   "title": "Commodore 64 Longplay [209] Blood Money (EU)"
  },
  "history": {
   "text": "DMA Design's second shoot-'em-up, coded by Mike Dailly with art by Tony Smith and published by Psygnosis in 1990. This C64 port carries the same organic, fleshy alien art style as the Amiga original across four sprawling worlds, each with a boss and an in-between shop for buying weapon upgrades &ndash; a genre DMA Design was known for before Lemmings made them famous, and again before Grand Theft Auto made them Rockstar North. This vault's PC shelf also carries the DOS release of the same game."
  }
 },
 "pc_doom": {
  "input": "keyboard",
  "note": "This vault ships id Software's free 1993 shareware episode, <strong>Knee-Deep in the Dead</strong> &ndash; the same disk that made Doom a phenomenon before anyone had paid a cent for it. Arrow keys move, <strong>Ctrl</strong> fires, <strong>Space</strong> opens doors and flips switches, <strong>Shift</strong> runs, and the number keys swap weapons. Click into the window once to give it your mouse for looking around; <strong>Esc</strong> opens DOSBox's own menu (exit, fullscreen, etc.), not the game's. If you own a full copy of Doom, its DOOM.WAD can replace the shareware DOOM1.WAD in a rebuilt DOOM.zip to unlock all three episodes &ndash; see the notes in the Vault project docs.",
  "video": {
   "id": "RzpOomy9iYQ",
   "title": "Doom (Episode 1: Knee-Deep in the Dead) (id Software) (MS-DOS) [1993] [PC Longplay]"
  },
  "history": {
   "text": "id Software's first-person shooter did more than popularize a genre it didn't quite invent - it redefined what a PC could look and feel like at a moment when most games still looked like Doom's own predecessor, Wolfenstein 3D. Built by John Carmack, John Romero, Tom Hall and Adrian Carmack and released in December 1993, its shareware episode spread across bulletin boards and campus networks faster than id could have sold it in stores, and the studio made more money giving a third of the game away than most publishers made selling the whole thing. Its network deathmatch mode, sprite-based enemies rendered in a true 3D world, and moddable WAD format shaped shooters, and PC gaming's business model, for the rest of the decade."
  }
 },
 "pc_wolfenstein3d": {
  "input": "keyboard",
  "note": "This vault ships the full six-episode registered version &ndash; the original trilogy plus the three <strong>Nocturnal Missions</strong> episodes. Arrow keys move, <strong>Ctrl</strong> fires, <strong>Space</strong> opens doors, <strong>Shift</strong> runs, and <strong>Alt</strong> strafes. Full mouse-look isn't part of the original engine &ndash; expect a Doom-style keyboard shooter, not a modern one. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "L9ucEzJQvIk",
   "title": "Wolfenstein 3D (1992) DOS Longplay"
  },
  "history": {
   "text": "id Software's breakout hit predates Doom by a year and effectively invented the first-person shooter as a commercial genre, built on a fast raycasting engine John Carmack wrote to squeeze real-time 3D out of 1992 PCs. Loosely inspired by Muse Software's 1981 stealth game of the same name (also on this vault's C64 shelf), it swapped sneaking for a room-by-room shootout through a Nazi stronghold, and its shareware-first release - Episode 1 free, two more sold by mail order - became the template id repeated a year later with Doom."
  }
 },
 "pc_commander_keen": {
  "input": "keyboard",
  "note": "The first shareware episode, <strong>Marooned on Mars</strong>. Arrow keys move, <strong>Alt</strong> jumps, and <strong>Ctrl</strong> fires Keen's pogo stick (also how he bounces onto ledges). <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "TxSRyOm64AU",
   "title": "Commander Keen 1: Marooned on Mars (PC) Longplay [1990]"
  },
  "history": {
   "text": "Built in a matter of weeks by John Carmack, Tom Hall, John Romero and Adrian Carmack while all four were still working day jobs at Softdisk, Commander Keen proved a PC could do the kind of smooth side-scrolling Nintendo had made its name on - Carmack's adaptive tile refresh technique was the trick that made it possible. The four left to found id Software on the strength of it. Invasion of the Vorticons shipped shareware-first through Apogee in December 1990: the first episode free, two more sold direct, the same distribution playbook id would run again on Wolfenstein 3D and Doom."
  }
 },
 "pc_duke_nukem_2": {
  "input": "keyboard",
  "note": "The full four-episode registered version. Arrow keys move, <strong>Ctrl</strong> fires, <strong>Alt</strong> jumps &ndash; the game's own options screen confirms the exact layout if a key doesn't do what you expect. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "tofpXhxv64U",
   "title": "Longplay: Duke Nukem II - Episode 1 (1993) [MS-DOS]"
  },
  "history": {
   "text": "A straight side-scrolling platformer, closer in spirit to Commander Keen than to the 3D shooter Duke would become - the original Duke Nukem (1991) and this sequel were both 2D Apogee games, and it was only 3D Realms' 1996 Duke Nukem 3D that reinvented the character as a shooter icon and trademarked the number stunt-double name change to dodge a Duke Nukem'em trademark dispute. Duke Nukem II added parallax-scrolling backgrounds and a wider arsenal to the run-and-gun format, and shipped the same way its stablemates did: a free first episode, more sold by mail order."
  }
 },
 "pc_prince_of_persia": {
  "input": "keyboard",
  "note": "Arrow keys walk, run and jump; <strong>Shift</strong> makes Prince step carefully or grip a ledge instead of falling. Precision matters more than speed here &ndash; missing a jump or misjudging a guard's blade is how runs end. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "EBbbDXtRJ6g",
   "title": "Prince of Persia (Jordan Mechner) (MS-DOS) [1990] [PC Longplay]"
  },
  "history": {
   "text": "Jordan Mechner rotoscoped his own brother's movements on a camcorder to give Prince of Persia's animation a fluidity nothing else on DOS had in 1989 - the same technique he'd used on Karateka. Built almost single-handedly over three years and published by Broderbund, its sixty real-time minutes, sword duels and lethal spike traps turned platforming into something that punished carelessness rather than reflexes alone, and its engine and animation approach went on to shape Mechner's own Prince of Persia 2 and, later, Ubisoft's Assassin's Creed."
  }
 },
 "pc_leisure_suit_larry": {
  "input": "keyboard",
  "manual": {
   "item": "pc_leisure_suit_larry",
   "pages": 13,
   "source": "Leisure Suit Larry in the Land of the Lounge Lizards (PC, 1987) - original manual, scan via archive.org (Leisure_Suit_Larry_1_-_Manual)"
  },
  "note": "A text-parser graphic adventure, not an action game &ndash; type what Larry should do (<code>look</code>, <code>get money</code>, <code>talk to bartender</code>) and use the arrow keys to walk once he's on his feet. The game opens with an age/trivia gate typical of Sierra's adult-comedy line at the time; answer its questions to get past the title screen. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "V0k5nzLbnNU",
   "title": "Leisure Suit Larry in the Land of the Lounge Lizards — Longplay (EGA)"
  },
  "history": {
   "text": "Al Lowe built Larry out of an earlier, tamer Sierra game called Softporn Adventure, reworking it into an AGI-engine graphic adventure that leaned all the way into its double entendres rather than away from them. Sierra almost didn't ship it, worried a comedy about a middle-aged loser trying (and mostly failing) to get a date would embarrass the company; instead it became one of Sierra's best-selling titles and spawned a franchise that ran for decades. Its trivia-question age gate at the start - meant only to keep casual browsers out, and trivially skippable - became as much a part of its reputation as the jokes inside."
  }
 },
 "pc_softporn": {
  "input": "keyboard",
  "note": "Pure text, no pictures &ndash; a two-word parser: <code>look</code>, <code>north</code>, <code>get money</code>, <code>talk bartender</code>, <code>buy whiskey</code>. Click the screen once before typing so the keys reach DOS (the first keystroke otherwise gets swallowed). You start with $2,500 and everything is overpriced, so the casino is not optional. <strong>Esc</strong> opens DOSBox's own menu, not the game's. Adult humour throughout, as the box says: for adults only.",
  "video": {
   "id": "nBNirHuD4Xg",
   "title": "PC Longplay [914] Softporn Adventure"
  },
  "history": {
   "text": "Before Larry there was Softporn. Chuck Benton wrote it in Applesoft BASIC in 1981 as a way of learning database programming, and On-Line Systems (the company that became Sierra) published it with a box photo of three women and a waiter in a hot tub - one of the women being Roberta Williams, the company's co-founder. It sold a reported 25,000 copies at a time when only a few hundred thousand Apple IIs existed, drew enough hate mail that it was quietly pulled from the catalogue, and six years later Al Lowe rebuilt its exact puzzles and geography as Leisure Suit Larry in the Land of the Lounge Lizards. This PC version is Gary Thompson's: a fan who had kept a printout of the Apple BASIC and rewrote it in C in 1991, released it as shareware, and only then discovered he had recreated the game underneath Larry. Sierra liked it enough to put it on the 1994 Leisure Suit Larry's Greatest Hits (and Misses) CD as the game's official history lesson, and Al Lowe later offered it as a free download on his own site. Play it next to Larry 1 and you'll recognise every room."
  }
 },
 "pc_lsl1_vga": {
  "input": "mouse",
  "manual": {
   "item": "pc_leisure_suit_larry",
   "pages": 13,
   "source": "Leisure Suit Larry 1 (1987) manual - same booklet the VGA remake shipped with, scan via archive.org (Leisure_Suit_Larry_1_-_Manual)"
  },
  "note": "Point-and-click: the icon bar at the top of the screen (or right-click to cycle) gives you walk, look, touch, talk and the inventory &ndash; no typing this time. It opens with the same age-check quiz as the original; get a question wrong and it politely throws you out. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "9lmGg1-GI0A",
   "title": "Leisure Suit Larry in the Land of the Lounge Lizards VGA (Full Playthrough)"
  },
  "history": {
   "text": "Four years after the original, Sierra redrew Larry's first night out in 256-colour VGA on its point-and-click SCI engine, the same treatment King's Quest I and Space Quest I got. The parser is gone, the rooms, jokes and puzzles are not, and the Lefty's bar, the casino and the honeymoon suite look the way most people who played Larry in the nineties remember them. The 1987 AGI original is on its own page on this shelf; this is the version Sierra kept selling, which is also why GOG still does – so the Vault can't host it, only show you where a preserved copy lives."
  }
 },
 "pc_lsl2": {
  "input": "keyboard",
  "manual": {
   "item": "pc_lsl2",
   "pages": 8,
   "source": "Leisure Suit Larry Goes Looking for Love (PC, 1988) - original manual incl. the 'little black book' photos the copy protection asks about, scan via archive.org (Leisure_Suit_Larry_2_-_Manual)"
  },
  "note": "Text parser plus arrow keys, like the original: type what Larry should do and steer him with the arrows. The copy-protection check at the start wants a phone number from the manual's \"little black book\" &ndash; see the Manual section on this page, or the scan linked under Where to get it. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "xs1POSo5dGI",
   "title": "PC Longplay [043] Leisure Suit Larry 2 - Goes Looking for Love (In Several Wrong Places)"
  },
  "history": {
   "text": "Larry's second outing (1988) sends him from a lottery win to a cruise ship, a tropical island and a mad scientist's lair, on Sierra's newer SCI0 engine with a proper soundtrack and much bigger screens. Al Lowe toned the sex down after the mail Sierra got for the first game and turned the dial up on slapstick instead; it's the one where the disguises, the KGB agents and the wrong-place-wrong-time gags really start. Still sold as part of Sierra's Larry bundle, so bring your own copy."
  }
 },
 "pc_lsl3": {
  "input": "keyboard",
  "manual": {
   "item": "pc_lsl3",
   "pages": 24,
   "source": "Leisure Suit Larry III (PC, 1989) - original manual incl. the pages the copy protection asks about, scan via archive.org (Leisure_Suit_Larry_3_-_Manual)"
  },
  "note": "Text parser plus arrow keys. Halfway through you switch characters and play Passionate Patti, chasing Larry &ndash; the inventory changes with her. Copy protection asks for a girl's measurements from the manual. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "L_S4wpqENWk",
   "title": "PC Longplay [475] Leisure Suit Larry 3 (Adult)"
  },
  "history": {
   "text": "Passionate Patti in Pursuit of the Pulsating Pectorals (1989) is the one where Larry gets divorced, stranded on the island resort of Nontoonyt, and, for the second half of the game, replaced as the player character by Patti, the lounge pianist chasing after him. Al Lowe wrote it as a farewell to the series – the ending has Larry and Patti fall into the Sierra offices – and there was famously no Larry 4 at all, a running joke the later games keep alive. Still sold in Sierra's bundle; the Vault only tells you where a preserved copy lives."
  }
 },
 "pc_lsl5": {
  "input": "mouse",
  "manual": {
   "item": "pc_lsl5",
   "pages": 9,
   "source": "Leisure Suit Larry 5 (PC, 1991) - 'PlaySpy' magazine-style manual, scan via archive.org (lsl5-playspy)"
  },
  "note": "Point-and-click on Sierra's icon bar, no typing; you alternate between Larry (scouting three women for a TV show) and Patti (undercover for the FBI). No copy protection. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "_mccH_HsVg4",
   "title": "Leisure Suit Larry 5 (PC DOS, 1991) Longplay"
  },
  "history": {
   "text": "Released in 1991 straight after the missing fourth game – the joke being that Larry 4 was never made, and Larry 5 opens with Larry having lost his memory of it – this was the series' move to 256-colour VGA and to point-and-click. Larry works for a soft-porn video company scouting talent across New York, Atlantic City and Miami while Patti goes undercover for the FBI in the record industry; the two threads meet at the end. Gentler and broader than the earlier games, and the last one Al Lowe wrote with a parser-free interface before the CD-ROM era. Still sold, so it isn't hosted here."
  }
 },
 "pc_lsl6": {
  "input": "mouse",
  "manual": {
   "item": "pc_lsl6",
   "pages": 3,
   "source": "Leisure Suit Larry 6 (PC, 1993) - manual, scan via archive.org (Leisure_Suit_Larry_6_-_Manual)"
  },
  "note": "Point-and-click. The CD version linked below has full voice acting; expect a long load, because the whole 469 MB is unpacked in the browser before it starts. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "0Bj3TSdYZNY",
   "title": "PC Longplay [044] Leisure Suit Larry 6 - Shape Up or Slip Out"
  },
  "history": {
   "text": "Shape Up or Slip Out! (1993) puts Larry in a health spa full of women he'll never get, with a bigger budget, hand-painted backgrounds and, on the CD-ROM release, voices for everyone including Jan Rabson as Larry. It was Sierra's last DOS Larry before Love for Sail, and one of the first of its adventures built with a talkie release in mind rather than patched with one later. Still sold in Sierra's bundle; the Vault shows you where a preserved copy lives."
  }
 },
 "c64_hb_c64anabalt": {
  "input": "joystick",
  "video": {
   "id": "elIoPajS_zk",
   "title": "C64anabalt Canabalt Demake C64 Commodore Longplay Gameplay Playthrough"
  },
  "history": {
   "text": "RGCD's 16KB cartridge conversion of Adam Saltsman's 2009 Flash hit Canabalt, released as a compo game in 2012. It strips the endless-runner down to pure timing and silhouette, proving the C64 could still do \"one button, infinite fall\" as well as any browser — free to download, or pay what you think is fair."
  }
 },
 "c64_hb_rescuing_orc": {
  "input": "joystick",
  "note": "Fire on the title screen starts the game. Jump with <strong>&#8593;</strong>, slash your sword with fire (<strong>G</strong>), duck/action with <strong>&#8595;</strong>. Pause with <strong>1</strong>.",
  "video": {
   "id": "y3HkZD5LmHs",
   "title": "C64 Longplay: Rescuing Orc (2017)"
  },
  "history": {
   "source": "Juan J. Martínez (reidrac), usebox.net; loading screen by Vanja Utne.",
   "url": "https://www.usebox.net/jjm/rescuing-orc/",
   "text": "Your best friend Orc (an orc, coincidentally) hasn't shown up for tea in two weeks, so you &ndash; a goblin &ndash; set out across the World of Magica to find him: five areas of jump-and-slash platforming from the Black Forest to Bluestone Keep. A 2017 release, in PAL and NTSC, by the same one-man studio behind the vault's Alien Intruder, Gold Mine Run! and The Return of Traxtor on the PC shelf. Free under CC BY-NC-SA (boxed disk, tape and cartridge editions exist via Poly Play); the open licence is why this vault hosts the download itself."
  }
 },
 "c64_hb_doc_cosmos": {
  "input": "joystick",
  "video": {
   "id": "bFM8HU7inxk",
   "title": "[Commodore 64] Doc Cosmos (2019) Longplay"
  },
  "history": {
   "text": "Simon Jameson's entry for RGCD's 2019 16k Cartridge Game Development Competition, a sci-fi adventure squeezed into the same 16KB ceiling as several other homebrew standouts of the decade. Part of a small wave of jam-born C64 games proving the machine's old constraints still make for good design discipline."
  }
 },
 "c64_hb_tenebra2": {
  "input": "joystick",
  "video": {
   "id": "sBcdpFPzNE8",
   "title": "Commodore 64 -=Tenebra 2=-"
  },
  "history": {
   "text": "The coder known as Haplo followed up 2016's Tenebra with this 2022 puzzle sequel, layering roguelike trappings — permadeath runs, procedurally-flavoured rooms — onto tight C64 puzzle design. Released across an unusually wide spread of 8-bit platforms simultaneously, a hallmark of the modern homebrew scene's cross-platform toolchains."
  }
 },
 "c64_hb_bomberland": {
  "input": "joystick",
  "video": {
   "id": "R9vDwO3QxWQ",
   "title": "[Commodore 64] Bomberland (2018) Longplay"
  },
  "history": {
   "text": "A coder going by \"Master\" built this Bomberman-style bomb-em-up for up to five simultaneous players, a rarity given the C64's limited native multiplayer input options. Version 1.1 shipped in 2018, part of the homebrew scene's steady output of party games designed for the machine's joystick ports rather than its keyboard."
  }
 },
 "c64_hb_bruce_lee_return_of_fury": {
  "input": "joystick",
  "video": {
   "id": "Pqc_KfSBoyw",
   "title": "Commodore 64 Longplay [281] Bruce Lee: Return of Fury (Public Domain)"
  },
  "history": {
   "text": "The demo group Megastyle built this unofficial sequel to 1984's Bruce Lee, keeping the original's ladders-and-lanterns platforming while expanding the moveset and level design well past what the 8-bit original attempted. Free and released into the public domain, it's a fan continuation rather than a licensed product."
  }
 },
 "c64_hb_rocket_smash_ex": {
  "input": "joystick",
  "video": {
   "id": "KoYlskxx-10",
   "title": "Rocket Smash EX Longplay (C64) [50 FPS]"
  },
  "history": {
   "text": "Richard Bayliss expanded his RGCD 16k Cart Compo 2013 entry into a full 64KB cartridge release in 2015, adding extra levels and polish to a fast, vertical-scrolling rocket-dodging shooter built originally under the compo's tight size limit."
  }
 },
 "c64_hb_micro_hexagon": {
  "input": "joystick",
  "video": {
   "id": "6RG5gEL84tg",
   "title": "Micro Hexagon Gameplay (C64)"
  },
  "history": {
   "text": "Onslaught's demake of Terry Cavanagh's Super Hexagon, squeezed into 16KB for the RGCD cartridge compo of 2013 — pure reflex geometry, rotating walls, and a game-over screen you'll see constantly."
  }
 },
 "c64_hb_wolfling": {
  "input": "joystick",
  "video": {
   "id": "uMYWehJ_DHU",
   "title": "Wolfling Longplay (C64) [50 FPS]"
  },
  "history": {
   "text": "Lazycow, one of the most prolific names in modern C64 homebrew, put out Wolfling's version 1.4 in 2019 — a tight platformer starring a wolf cub, trading the studio's usual puzzle leanings for straightforward jump-and-run action."
  }
 },
 "c64_hb_runn_n_gunn": {
  "input": "joystick",
  "video": {
   "id": "PprvKlzquBU",
   "title": "Modern Retro Review - Runn'n'Gunn (Commodore 64)"
  },
  "history": {
   "text": "Excess built Runn'n'Gunn in 2021 as a throwback to arcade run-and-gun shooters, splitting the action between platforming and near-constant enemy fire — one of a steady stream of releases from a group that's become a fixture of the current C64 scene."
  }
 },
 "c64_hb_grid_pix": {
  "input": "joystick",
  "video": {
   "id": "a9dV1OB79RQ",
   "title": "Grid Pix (C64) - RGN Quick Play"
  },
  "history": {
   "text": "Excess turned to logic puzzles for Grid Pix in 2020, a nonogram/Picross game filling a genre almost entirely absent from the original C64 library — later picked up for a boxed cartridge release by Thalamus Digital / RGCD."
  }
 },
 "c64_hb_super_bread_box": {
  "input": "joystick",
  "video": {
   "id": "USdUkFSE8Eo",
   "title": "Super Bread Box (C64 2012) (Gameplay)"
  },
  "history": {
   "text": "Paulko64 ported the 2010 indie arcade game Bread Box (better known by its later name, Super Crate Box) to the C64 in 2012, fitting the whole thing into a 16KB cartridge. Grab a crate, get a random new gun, survive the horde, repeat."
  }
 },
 "c64_hb_hero_is_back": {
  "input": "joystick",
  "video": {
   "id": "sZ9C8Vo4QAc",
   "title": "H.E.R.O. Is Back (C64 Longplay)"
  },
  "history": {
   "text": "Excess and Hokuto Force joined forces in 2025 to build an unofficial sequel to Activision's 1984 mining-rescue classic H.E.R.O., over four decades after the original. Same jetpack, same dynamite, a fresh set of caverns to burn through."
  }
 },
 "c64_hb_luftrauserz": {
  "input": "joystick",
  "video": {
   "id": "MUKSBemVAOA",
   "title": "Luftrauserz - C64 version of the PC indie hit shooter LUFTRAUSERS"
  },
  "history": {
   "text": "Triad's 2017 conversion took the 2014 PC dogfighter Luftrausers and squeezed its frantic, physics-driven plane combat onto real C64 hardware. Pick a hull, pick a weapon, and try to stay airborne against wave after wave of enemy planes and subs."
  }
 },
 "c64_hb_bagman_strikes_back": {
  "input": "joystick",
  "video": {
   "id": "fnWU-SIreGw",
   "title": "Bagman Strikes Back (C64) - Longplay - Hard difficulty, All 24 stages"
  },
  "history": {
   "text": "LC-Games' 2022 unofficial follow-up to the 1983 arcade platformer Bagman keeps the core loop intact — a mustachioed thief hauling sacks of gold up ladders while dodging guards — nearly forty years after the coin-op original."
  }
 },
 "c64_hb_galaxian_dx": {
  "input": "joystick",
  "video": {
   "id": "W5ujiphcfak",
   "title": "Galaxian DX (Commodore 64)"
  },
  "history": {
   "text": "Army of Darkness reworked Namco's 1979 shoot-em-up Galaxian for the C64 in 2021, keeping the diving alien-formation attacks but adding smoother scrolling and modern touches — a loving tribute rather than a straight port."
  }
 },
 "pc_civilization": {
  "input": "keyboard",
  "note": "Turn-based, menu-driven throughout &ndash; arrow keys and Enter move the cursor and confirm, and most screens also list a single-letter shortcut (<code>B</code> to build, <code>P</code> to found a city on the map, and so on). The very first launch asks <em>Select graphics mode</em> before anything else appears: press <strong>1</strong> for VGA. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "js42DMyAFGM",
   "title": "Sid Meier's Civilization (MPS Labs) — MS-DOS Longplay"
  },
  "history": {
   "text": "Sid Meier and Bruce Shelley built Civilization at MicroProse by asking what a board game like Risk or Empire would feel like if it ran across the whole of human history instead of one war. The turn-based loop it settled on &ndash; found cities, research technology, manage happiness, out-build or out-fight the neighbours &ndash; became the template the entire 4X genre still measures itself against, and the series it started is still being made today. This original 1991 DOS release is the one Meier and Shelley actually shipped, before Civilization II and everything after it layered on."
  }
 },
 "pc_simcity": {
  "input": "mouse",
  "note": "Almost entirely mouse-driven &ndash; click the toolbar on the left to pick a tool (road, zone, power line), then click or drag on the map to place it. The keyboard is only needed for typing a city name and setting the starting budget. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "LHYMFgs20oE",
   "title": "SimCity — original 1989 MS-DOS Longplay"
  },
  "history": {
   "text": "Will Wright had already written the city-simulation engine while working on a level editor for a different game and realised the editor was more fun than the game it was building levels for. Maxis published it in 1989 as SimCity, with no win condition and no enemy &ndash; just a budget, a map, and a population that would riot, catch fire or move away depending on how well the city was actually run. It's usually credited as the game that invented the city-builder genre outright, and the one that made \"management sim\" a shelf category all its own."
  }
 },
 "pc_dune2": {
  "input": "mouse",
  "note": "Select units by dragging a box around them with the mouse, then right-click (or left-click, depending on the command) to move or attack &ndash; the toolbar on the right builds units and structures. There's a long animated intro before the first mission; if it drags, <strong>Esc</strong> skips ahead (DOSBox's own menu also lives on Esc once in-game, so tap it just once to test which you get).",
  "video": {
   "id": "EiJLOjeyDxs",
   "title": "Dune II: The Building of a Dynasty — MS-DOS Longplay"
  },
  "history": {
   "text": "Westwood Studios had already made a strategy game set on Dune's desert planet Arrakis, but for the sequel they threw out the turn-based structure and let everything happen in real time &ndash; base-building, resource harvesting (the all-important spice) and combat, all running simultaneously against the clock instead of waiting for a turn. Command & Conquer, Warcraft and the whole real-time strategy genre trace their lineage straight back to this one; loosely tied to Frank Herbert's Dune, three noble houses (Atreides, Harkonnen, Ordos) fighting over the same desert Denis Villeneuve's films later put on screen."
  }
 },
 "pc_tim": {
  "input": "mouse",
  "note": "Drag parts from the shelf on either side into the workspace, then press Go to run the contraption &ndash; there's no typing at all, just placing pulleys, fans, balloons and the occasional cat until the chain reaction actually works. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "pTbSMKGQ_rU",
   "title": "The Incredible Machine (1993) — MS-DOS Longplay"
  },
  "history": {
   "text": "Dynamix built The Incredible Machine as a physics-toy dressed up as a puzzle game: every level hands over a scattering of Rube Goldberg parts &ndash; ropes, gears, balloons, a cat, a bowling ball &ndash; and a goal (get the ball in the basket, pop the balloon) with no fixed way to solve it. Sierra published it in 1993 and it spawned a run of sequels through the 90s; its open-ended, build-anything-that-works design is the direct ancestor of it later spiritual successor Contraption Maker, made by two of TIM's own original designers."
  }
 },
 "pc_oregon_trail": {
  "input": "keyboard",
  "note": "Menu-driven &ndash; number keys pick options at every screen, including the opening choice between travelling the trail, learning about it, or checking the Oregon Top Ten. The hunting minigame (option on the trail itself) uses the keyboard to aim and fire. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "29mzk7nZ6pA",
   "title": "The Oregon Trail (1990, MECC) — MS-DOS Longplay"
  },
  "history": {
   "text": "The Oregon Trail began in 1971 as a text-only teletype program three student teachers wrote in a couple of weeks to teach Minnesota schoolkids what the 1840s wagon migration actually involved; MECC picked it up, gave it graphics, and it became the software practically every American who went through a school computer lab in the 80s and 90s remembers &ndash; fording rivers, rationing food, and, for a startling number of players, dying of dysentery. This 1990 MS-DOS release is the MECC-era graphical version, not the original 1971 teletype game or the later CD-ROM Deluxe remake."
  }
 },
 "pc_keen2": {
  "input": "keyboard",
  "note": "Keyboard-only &ndash; arrow keys move and climb, Ctrl fires the raygun, Alt/pogo jumps. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "MLvFMPp6MJc",
   "title": "Commander Keen: Invasion of the Vorticons EP#2 The Earth Explodes [1990]"
  },
  "history": {
   "text": "Built in about two months at the end of 1990 by John Carmack, John Romero, Tom Hall and Adrian Carmack while all four were still moonlighting at Softdisk, this episode continued the Invasion of the Vorticons trilogy that convinced them their shareware sales could support a real company. Id Software was founded two months later, in February 1991."
  }
 },
 "pc_keen3": {
  "input": "keyboard",
  "note": "Same keyboard-only controls as the earlier episodes &ndash; arrow keys move, Ctrl fires, Alt pogos. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "kPvWYDw8UvY",
   "title": "[Longplay] Commander Keen 3 - Keen Must Die! (1990, PC DOS)"
  },
  "history": {
   "text": "The third and final episode of Invasion of the Vorticons, finished in the same end-of-1990 crunch as episodes one and two. Its strong shareware sales over that Christmas were the direct proof id Software's four founders needed that self-publishing shareware games could actually pay the bills."
  }
 },
 "pc_keen4": {
  "input": "keyboard",
  "note": "Keyboard-only, same scheme as the Vorticons trilogy. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "yCGABUTxAlE",
   "title": "[Longplay] Commander Keen 4 - Secret of the Oracle (1991, PC DOS)"
  },
  "history": {
   "text": "The first half of the two-episode Goodbye Galaxy set, sold together with Episode 5. It was among 1992's best-selling shareware titles and marked a visual step up from the Vorticons trilogy, with denser levels and a proper overworld map."
  }
 },
 "pc_keen5": {
  "input": "keyboard",
  "note": "Keyboard-only, same scheme as Episode 4. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "66JKlQEbaWc",
   "title": "Longplay: Commander Keen 5 - The Armageddon Machine (1991) [MS-DOS]"
  },
  "history": {
   "text": "Concludes the Goodbye Galaxy duology and was effectively id's last shareware episode before the studio pivoted to Wolfenstein 3D the following year, moving the company from 2D platformers to the first-person shooter genre it would go on to define."
  }
 },
 "pc_keen6": {
  "input": "keyboard",
  "note": "Keyboard-only, same scheme as the rest of the series. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "F7DLyZKNePs",
   "title": "[Longplay] Commander Keen 6: Aliens Ate My Babysitter"
  },
  "history": {
   "text": "Sold as a standalone retail game through FormGen rather than as Apogee shareware &ndash; a deal reportedly brokered by Mark Rein that upset Apogee's Scott Miller at the time. It was the last Commander Keen game id Software developed in-house."
  }
 },
 "pc_duke_nukem": {
  "input": "keyboard",
  "note": "All three episodes are included &ndash; press <strong>1</strong>, <strong>2</strong> or <strong>3</strong> at the launch menu to choose one. Keyboard-only side-scrolling platformer &ndash; arrow keys run and climb, Ctrl fires, Alt jumps. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "kYzZcko3F50",
   "title": "Longplay: Duke Nukem - Episode 1: 'Shrapnel City' (1991) [MS-DOS]"
  },
  "history": {
   "text": "The original Duke Nukem, three episodes of side-scrolling platforming released a year before Duke Nukem II refined the formula. Prototyped under the working title \"Heavy Metal,\" with young John Carmack pitching in on low-level assembly work before he left to co-found id Software. It sold a respectable 60,000-70,000 copies as shareware."
  }
 },
 "pc_duke_nukem_3d": {
  "input": "both",
  "note": "Keyboard moves and turns, mouse aims &ndash; the classic Doom-era WASD-plus-mouse control scheme works here too. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "hxHCC3abKsA",
   "title": "Duke Nukem 3D (PC) All Episodes Longplay & Ending"
  },
  "history": {
   "text": "Built on 3D Realms' own Build engine, Duke Nukem 3D paired genuinely destructible, interactive environments (shootable windows, working strippers' poles, flushable toilets) with Duke's wisecracking one-liners, becoming one of the best-selling and most influential shooters of the DOS era. This is the original 1996 DOS release, not the 2016 \"20th Anniversary World Tour,\" which is a separate Windows-only rebuild with no DOS executable."
  }
 },
 "pc_kq1": {
  "input": "keyboard",
  "note": "Keyboard text parser &ndash; arrow keys walk, and you type short commands like <code>open door</code> or <code>get key</code>. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "y69CtXCyWO4",
   "title": "Kings Quest: Quest for the Crown SCI / VGA Remake - Complete Walkthrough / Playthrough HD"
  },
  "history": {
   "text": "Commissioned by IBM to showcase the PCjr, the original 1984 King's Quest ran on Sierra's new AGI engine, which let King Graham walk in front of and behind background scenery instead of standing on a flat static screen &ndash; a real technical first. This 1990 SCI remake rebuilt the same game on the more capable engine used for King's Quest IV, and became the version Sierra itself kept selling as \"King's Quest I.\""
  }
 },
 "pc_kq2": {
  "input": "keyboard",
  "note": "Keyboard text parser, same interface as KQ1. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "gfyOiqpJwKM",
   "title": "King's Quest II - Romancing The Throne - Full Playthrough - Perfect Score"
  },
  "history": {
   "text": "A direct sequel sending King Graham to rescue his future queen Valanice, reusing the AGI engine with an expanded parser vocabulary. The development team included future Space Quest creators Scott Murphy and Mark Crowe, and composer Al Lowe &ndash; talent that would go on to define Sierra's late-80s golden age."
  }
 },
 "pc_kq3": {
  "input": "keyboard",
  "note": "Keyboard text parser. Some puzzles run on a real-time clock, so expect to reload often on a first run. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "7Xd1Ne5Ri5U",
   "title": "King's Quest 3 - To Heir Is Human DOS / PC Longplay HD"
  },
  "history": {
   "text": "Breaks from the series' rescue-the-royal formula, casting the player as a slave (secretly Graham's kidnapped son) forced to do chores for the wizard Manannan before the real plot unfolds. Its real-time wizard-patrol timer makes it widely regarded as the hardest and most obtuse AGI-era Sierra game."
  }
 },
 "pc_kq4": {
  "input": "keyboard",
  "note": "Keyboard text parser &ndash; the last mainline King's Quest to use one. The game runs on a day/night clock, so some puzzles only solve at certain times. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "k8V0sIOQqCA",
   "title": "King's Quest IV: The Perils of Rosella - DOS Version - English Longplay"
  },
  "history": {
   "text": "The first major commercial graphical adventure with a female protagonist, sending Princess Rosella to save her dying father. It debuted Sierra's SCI0 engine at double AGI's resolution, and was the first PC game to support add-on sound cards like AdLib and Roland instead of just the PC speaker, with an original orchestral score by TV composer William Goldstein."
  }
 },
 "pc_kq5": {
  "input": "mouse",
  "note": "The first King's Quest to drop the text parser for full point-and-click &ndash; right-click (or the icon bar) cycles look/action/talk cursors. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "JQ2yh0bo550",
   "title": "PC Longplay [854] Kings Quest V: Absence Makes the Heart Go Yonder"
  },
  "history": {
   "text": "The series' hinge point: it replaced typed commands with full point-and-click mouse control and introduced hand-painted VGA backgrounds that were a genuine visual showcase in 1990. It won the SPA Excellence in Software award and Computer Gaming World's Adventure Game of the Year, though the loss of the parser (and the notoriously oversized desert map) remains a point of fan debate."
  }
 },
 "pc_kq6": {
  "input": "mouse",
  "note": "Point-and-click with an icon toolbar (walk/look/action/talk). <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "EvrZ5haT9rE",
   "title": "PC Longplay [855] King's Quest VI: Heir Today, Gone Tomorrow"
  },
  "history": {
   "text": "Widely regarded as the series' creative peak. Prince Alexander searches for Princess Cassima across the mysterious Isles of the Sirens, with two divergent story paths depending on player choices, co-designed by Roberta Williams and novelist Jane Jensen. The CD-ROM \"talkie\" edition added full voice acting and a landmark fully-rendered opening cinematic, and sold roughly 400,000 copies in its first week."
  }
 },
 "pc_kq7": {
  "input": "mouse",
  "note": "Point-and-click with a \"smart cursor\" that changes shape over interactive objects &ndash; no separate verb bar like KQ6. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "egrOUpT_0EE",
   "title": "King's Quest VII - The Princeless Bride - [1994 - DOS - Full Playthrough]"
  },
  "history": {
   "text": "The last King's Quest from Sierra's original creative team, co-designed by Roberta Williams and Lorelei Shannon, and the first to fully replace the parser-era interface with an auto-highlighting smart cursor &ndash; a real usability leap, though its Disney-inspired art style split longtime fans. It's the only King's Quest with two playable protagonists (Valanice and Rosella) and the only one split into discrete chapters."
  }
 },
 "pc_doom2": {
  "input": "keyboard",
  "note": "Arrow keys move/turn, Ctrl fires, Space uses &ndash; mouse can aim but only turns left/right, it can't look up or down. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "4cCfbyhh6nc",
   "title": "Retro Longplay #113 - DOOM II: Hell on Earth (PC) [HD]"
  },
  "history": {
   "text": "Id Software's first title sold at retail rather than given away as shareware. It reused the original Doom engine with denser, more maze-like levels, doubled the non-boss monster roster and added the Super Shotgun, and became the best-selling piece of US software of 1994."
  }
 },
 "pc_final_doom_tnt": {
  "input": "keyboard",
  "note": "Same controls as Doom II. The maps run large and maze-like &ndash; keep an eye on the automap. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "RERSUIwKMpI",
   "title": "Final DOOM : TNT Evilution Full Playthrough [60 FPS/FULL HD]"
  },
  "history": {
   "text": "Originally built as a free megawad by the fan collective TeamTNT and finished in October 1995 for free release, until John Romero brokered a last-minute publishing deal that turned it commercial overnight. It runs on the same DOOM2.EXE engine as Doom II, just with a different set of levels (TNT.WAD)."
  }
 },
 "pc_final_doom_plutonia": {
  "input": "keyboard",
  "note": "Same controls as Doom II. Widely considered the hardest official Doom content ever shipped &ndash; expect to need to memorize ambushes. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "Nj6rhctEl3c",
   "title": "Final DOOM : The Plutonia Experiment Full Playthrough [60 FPS/FULL HD]"
  },
  "history": {
   "text": "Brothers Dario and Milo Casali were hired by id after impressing lead artist American McGee with a sample level, and finished all 32 Plutonia maps in about four months, largely unrevised before shipping. Same DOOM2.EXE engine as Doom II and TNT Evilution, just a different level set (PLUTONIA.WAD), sold together with TNT in the same Final Doom box."
  }
 },
 "pc_spear_of_destiny": {
  "input": "keyboard",
  "note": "All three campaigns are included &ndash; at the launch menu press <strong>1</strong> for Spear of Destiny, <strong>2</strong> for Return to Danger or <strong>3</strong> for Ultimate Challenge. Same controls as Wolfenstein 3D &ndash; no dedicated strafe key by default, diagonal movement takes practice. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "UXuftq-EiQM",
   "title": "PC Longplay [609] Spear of Destiny"
  },
  "history": {
   "text": "Id Software's first standalone retail-boxed spin-off, built on the Wolfenstein 3D engine with new enemies, bosses, textures, and a 21-level campaign &ndash; roughly double the length of a standard Wolfenstein episode. A prequel to Wolfenstein 3D's story, following B.J. Blazkowicz's earlier hunt for a Nazi holy relic."
  }
 },
 "pc_xcom_ufo_defense": {
  "input": "mouse",
  "video": {
   "id": "gMgLQC4wccc",
   "title": "X-COM: UFO Defence (PC/DOS) Superhuman Difficulty, 1994, MicroProse"
  },
  "note": "Point-and-click throughout &ndash; watch each soldier's Time Units closely, since actions cost TUs and it's easy to strand someone with none left. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "history": {
   "text": "Released in Europe as UFO: Enemy Unknown, X-COM blends strategic geoscape base-and-research management with turn-based squad tactics against a slowly escalating alien invasion. It defined the entire \"X-COM-like\" subgenre and directly inspired Firaxis's 2012 reboot; IGN named it the best PC game of all time in a 2007 readers' poll."
  }
 },
 "pc_sq1": {
  "input": "keyboard",
  "note": "Keyboard text parser &ndash; arrow keys walk, and you type short commands like <code>look</code> or <code>get keycard</code>. This is the 1986 AGI original, not the 1991 VGA remake. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "UboQ_Td7NIk",
   "title": "Space Quest: The Sarien Encounter (PC/DOS) Longplay, 1986, Sierra On-Line"
  },
  "history": {
   "text": "Launched Sierra's parody-heavy sci-fi comedy line built around hapless janitor Roger Wilco, created by \"The Two Guys from Andromeda\" (Scott Murphy and Mark Crowe) as a deliberate B-movie spoof. This is the original 1986 release, built on Sierra's AGI engine with a typed text parser &ndash; the version that established the series before the 1991 VGA remake rebuilt it on SCI with a point-and-click interface."
  }
 },
 "pc_sq2": {
  "input": "keyboard",
  "note": "Keyboard text parser &ndash; type short direct verbs and save before any unfamiliar area. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "oCUwStdSoMM",
   "title": "Space Quest 2 - Vohaul's Revenge DOS/PC Longplay HD"
  },
  "history": {
   "text": "The direct sequel escalates the parody with an ambitious jungle-planet rescue plot and introduces series antagonist Sludge Vohaul. Built on the same AGI engine and keyboard parser as the original, praised at the time for an improved parser but still notorious for the series' signature unfair instant deaths."
  }
 },
 "pc_sq3": {
  "input": "keyboard",
  "note": "Keyboard text parser is primary; the mouse can help you walk but doesn't replace typed verbs. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "0lirgkHZ-fE",
   "title": "Space Quest III - The Pirates of Pestulon (Full Playthrough)"
  },
  "history": {
   "text": "Breaks the fourth wall harder than its predecessors, opening with Roger literally trapped in the scrap-compactor of the company that makes his own games &ndash; a jab at Sierra itself &ndash; before a space-pirate plot proper kicks in. The last Space Quest built on the AGI engine, and the first to add rudimentary mouse-assisted movement."
  }
 },
 "pc_sq4": {
  "input": "mouse",
  "note": "Point-and-click via an icon/verb bar &ndash; the first Space Quest where you never need to type anything. This is the CD talkie release, so the dialogue is fully voiced; the <strong>TEXT</strong> button on the pause screen switches back to subtitles. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "DpXuGxT7LuA",
   "title": "Space Quest IV: Roger Wilco and the Time Rippers (PC) Playthrough"
  },
  "history": {
   "text": "A fan-favorite turning point for the series: a time-travel plot that lets Roger visit deliberately clashing versions of the series' own past (blocky EGA) and future (a slick, hypothetical sequel-within-the-sequel), used as an extended joke about changing art styles in gaming itself. Moved the series fully to Sierra's SCI1 engine with a point-and-click interface, dropping the text parser entirely."
  }
 },
 "pc_sq5": {
  "input": "mouse",
  "note": "Point-and-click, same icon-bar flow as SQ4. The game includes a printed-manual copy-protection puzzle, so keep the manual (or a walkthrough) handy. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "z-QFguqJOms",
   "title": "Space Quest V: The Next Mutation (PC/DOS) Longplay, 1993"
  },
  "history": {
   "text": "With series creators Scott Murphy and Mark Crowe stepping back, Sierra's sister studio Dynamix took the reins and recast Roger as captain of his own ship, leaning harder into Star Trek parody than the earlier entries. Generally regarded as tonally the odd one out in the series &ndash; competent, but noticeably different in humor and pacing from the games around it."
  }
 },
 "pc_sq6": {
  "input": "mouse",
  "note": "Point-and-click via a verb bar closer to LucasArts' games than earlier Sierra titles. Launch the DOS executable, not <code>SIERRAW.EXE</code>, with the CD mounted. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "EUxFxz7XWK4",
   "title": "Space Quest 6: Roger Wilco in The Spinal Frontier - English Longplay"
  },
  "history": {
   "text": "The last mainline entry with direct involvement from series co-creator Scott Murphy, and the first built on Sierra's newer SCI32 engine, adding full-motion \"Robot\" video cutscenes. Frequently cited as a fan-favorite high point for the series' comedy writing, even as Sierra's adventure-game business was beginning its mid-90s decline."
  }
 },
 "pc_lemmings": {
  "input": "mouse",
  "note": "The mouse builds and destroys the level; the eight skill icons along the bottom (Climber, Floater, Bomber, Blocker, Builder, Basher, Miner, Digger) assign a job to whichever lemming you click. The main menu opens straight into a machine-type prompt from the original installer &ndash; press <strong>Return</strong> once to accept &quot;PC compatibles&quot; and reach the real title screen. <strong>F1</strong> starts 1-player. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "xIuxB1oR2WQ",
   "title": "Lemmings full playthrough (DOS)"
  },
  "history": {
   "text": "DMA Design's puzzle-strategy breakout, published by Psygnosis in 1991, tasked players with steering an endless column of suicidally literal-minded green-haired creatures to safety by assigning a handful of them special jobs &ndash; digger, blocker, builder, bomber &ndash; before they walked off a cliff or into a fire. Built around a simple idea and an even simpler control scheme, it became one of the best-selling games of the early 90s and was ported to nearly every platform sold at the time, including this DOS release and, on this vault's other shelf, the Commodore 64."
  }
 },
 "pc_onml": {
  "input": "mouse",
  "note": "The first Lemmings expansion pack &ndash; same eight skills, all-new levels pitched harder than the original's. Same machine-type prompt as the original on boot: press <strong>Return</strong> once for &quot;PC compatibles&quot;. <strong>F1</strong> starts 1-player. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "-ug5vxX8Vic",
   "title": "Oh No! More Lemmings (Amiga 500 longplay) — no separate DOS longplay circulates; the DOS release plays identically"
  },
  "history": {
   "text": "Released only months after the original, this stand-alone expansion swapped in 100 new, noticeably meaner levels while changing nothing about the core rules &ndash; the same read-the-terrain, assign-a-job puzzle logic, just tuned for players who had already cleared the first game. Its hardest difficulty tier was blunt about it: renamed from \"Mayhem\" to simply \"Tame\" on some releases' menus wouldn't have been out of place, since even its easiest levels out-punished the original's hardest."
  }
 },
 "pc_xmas_lemmings": {
  "input": "mouse",
  "note": "A free four-level Christmas demo Psygnosis mailed out to registered Lemmings owners in 1992 &ndash; same controls, a snow-themed skin, and a much shorter level set. Boots into a &quot;PC Lemmings Demo Machine Type Selection Screen&quot;: press <strong>1</strong> then <strong>Return</strong> for the VGA game. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "su7bymGu-CA",
   "title": "Longplay: Xmas Lemmings 1991 (1991) [MS-DOS]"
  },
  "history": {
   "text": "Psygnosis's yearly holiday freebie for owners who'd mailed back their registration card &ndash; four new snow-and-present-themed levels on the same engine as the full game, sent out on a single disk with no purchase required. It's the same promotional lineage that became Holiday Lemmings in later years; this vault also carries the 1994 edition under that later name."
  }
 },
 "pc_holiday_lemmings": {
  "input": "mouse",
  "note": "The last of Psygnosis's free yearly holiday Lemmings episodes, mailed to registered owners &ndash; a handful of new snow-themed levels, same skills and controls as the full game. <strong>F1</strong> starts the game straight from its own title screen, no machine-select prompt this time. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "su7bymGu-CA",
   "title": "Longplay: Xmas Lemmings 1991 (1991) [MS-DOS] — the closest matching longplay; Holiday Lemmings 1994 is the same free yearly format's final release and doesn't have its own circulating longplay"
  },
  "history": {
   "text": "Psygnosis kept sending registered Lemmings owners a free seasonal level pack every winter from 1991 through 1994, renaming it from Xmas Lemmings to Holiday Lemmings partway through as the pack grew to cover more than just Christmas. This 1994 edition was the last of the series, bundled here alongside the earlier Xmas Lemmings 1992 release this vault also carries."
  }
 },
 "pc_lemmings2": {
  "input": "mouse",
  "note": "A much bigger sequel &ndash; ten lemming tribes, each with its own set of skills and look, and a hub map instead of a flat level list. Mouse-driven front end; click <strong>PLAY</strong> to pick a tribe and level. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "RSByEMmPJw8",
   "title": "Amiga Longplay Lemmings 2: The Tribes (Part 1 of 3) — no single-video DOS longplay circulates; a DOS playlist exists but isn't linkable as one video ID"
  },
  "history": {
   "text": "DMA Design's 1993 sequel kept the core save-the-lemmings idea but multiplied it: ten tribes (Classic, Egyptian, Highland, Polar and more) each carry a themed subset of skills instead of the original's fixed eight, spread across a hub-style world map rather than one long level list. Bigger, more varied, and less punishing than Oh No! More Lemmings, it's often cited as the series' most ambitious entry even if the original stayed the more iconic one."
  }
 },
 "pc_anwol": {
  "input": "mouse",
  "note": "The third mainline sequel, retitled \"The Lemmings Chronicles\" in some releases &ndash; a moodier, more atmospheric take with pre-rendered cutscenes. Boots straight into an animated intro; click through or wait for the main menu. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "FbtLfaP6S9k",
   "title": "All New World of Lemmings [1994] MS DOS - 5 minute gameplay - no commentary"
  },
  "history": {
   "text": "Psygnosis's third full Lemmings sequel traded the earlier games' bright cartoon look for a darker, more painterly art style and framed its four themed worlds (Egyptian, Roman, Norse, Chinese) with rendered cutscenes rather than static menus &ndash; a noticeably more expensive-looking production than 1991's original. Reception was more divided than the earlier entries; some found the new tone a genuine step up, others missed the earlier games' immediacy."
  }
 },
 "pc_blood_money": {
  "input": "keyboard",
  "note": "A side-scrolling shoot-'em-up, not a Lemmings game &ndash; DMA Design's other 1990 release. Arrow keys move, the fire key (bindable) shoots; four worlds, each ending in a boss. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "_gZf1wBCQ7E",
   "title": "Blood Money gameplay (PC Game, 1989)"
  },
  "history": {
   "text": "Before Lemmings made DMA Design famous, the Dundee studio built its name on shoot-'em-ups &ndash; Blood Money was its second, a four-world horizontal/vertical shooter with a distinctly alien, organic art style and a shop between levels for upgrading the ship. Published by Psygnosis in 1990 across Amiga, Atari ST, DOS and, as this vault's C64 shelf also carries, a Commodore 64 port."
  }
 },
 "pc_hb_gates": {
  "input": "keyboard",
  "note": "A from-scratch first-person dungeon RPG built the way the genre worked in 1990 &ndash; create a party at the Guild, then walk the maze in real time fighting whatever finds you. Menu-driven throughout: single letters pick every option, on both the Guild screen and in the dungeon itself. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "AxoEh9BaP74",
   "title": "Gates Of Integrity: Intro, character creation and first fights"
  },
  "history": {
   "source": "Tarjan's own devlogs on itch.io, where the game has had a dedicated MS-DOS build since 2022 alongside its original Windows release.",
   "text": "One of the more actively maintained pieces of new DOS-native software being written today &ndash; Tarjan has kept shipping numbered point releases (past v1.22) years after the first version, with a from-scratch first-person dungeon-crawler engine built specifically to run on real DOS hardware rather than as a retro-styled Windows game."
  }
 },
 "pc_hb_disksweeper": {
  "input": "keyboard",
  "note": "Minesweeper reframed as repairing a corrupted floppy disk sector by sector &ndash; the rules are the same, the chrome is pure early-90s file-manager. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {"title": "DISKSWEEPER gameplay clip"},
  "history": {
   "source": "voxel's itch.io page, where DISKSWEEPER shipped as an entry to the DOS Games August Jam 2022.",
   "text": "Built for the DOS Games August Jam 2022, one of the recurring themed jams (see also DOSember every December) that make up most of the active new-DOS-software scene today."
  }
 },
 "pc_hb_pantsmo": {
  "input": "keyboard",
  "note": "A side-scrolling platformer riffing openly on early-90s Apogee/Epic shareware trilogies, credits screen jokes included. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "history": {
   "source": "eviltentacle's itch.io page."
  }
 },
 "pc_hb_noudar": {
  "input": "keyboard",
  "note": "Arrow keys move and turn, <strong>Z</strong>/<strong>X</strong> strafe, <strong>S</strong> (or 1-3) cycles the inventory, <strong>A</strong> picks up items, <strong>Space</strong> uses the current item &ndash; all straight from the game's own title screen. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "fy8xPw_W32s",
   "title": "New RPG for Dos (Dungeons of Noudar 3d)"
  },
  "history": {
   "source": "Daniel \"MontyOnTheRun\" Monteiro's GitHub repository (open source) and archive.org preservation copy.",
   "text": "A first-person, tile-based dungeon crawler written in C++ with fixed-point math and pure software rendering, built 2014-2018 and still one of the most referenced examples of what a solo developer can do writing native DOS code today rather than emulating the look of it."
  }
 },
 "pc_hb_alienintruder": {
  "input": "keyboard",
  "note": "A single-screen jump-and-shoot in the mould of Miner 2049er or Jumpman: 50 stages, 60 seconds each &ndash; rescue the crew, reach the exit, and grab the pizza, soda and diskettes on the way. Arrows move, <strong>Z</strong> fires, <strong>X</strong> jumps, <strong>P</strong> pauses. <strong>Esc</strong> quits to DOSBox's own menu, not the game's.",
  "video": {
   "id": "cakmTfZWtOw",
   "title": "Longplay: Alien Intruder (2024) [MS-DOS]"
  },
  "history": {
   "source": "Juan J. Martínez (reidrac), usebox.net &ndash; also covered by Indie Retro News the week it shipped.",
   "url": "https://www.usebox.net/jjm/alien-intruder/",
   "text": "\"In space no one can hear you scream, so use your blaster instead!\" A commercial spacecraft's crew has been captured by aliens, and you're the rescue mission: 50 single-screen stages, 60 seconds apiece, on anything from a 286 with VGA up. Released free in December 2024 under a Creative Commons licence (CC BY-NC-SA) by Juan J. Martínez, a Spanish developer who has spent years writing genuinely native games for DOS, MSX, Amstrad CPC, ZX Spectrum and C64 &ndash; real 8/16-bit code, not a modern engine in retro clothes. There's even a boxed Collector's Edition through Poly Play for cartridge-and-manual people. The open licence is why this vault can host the download outright."
  }
 },
 "pc_hb_goldmine": {
  "input": "keyboard",
  "note": "Grab every piece of gold before the 60-second clock runs out &ndash; dawdle and a time monster comes for you. Coloured keys open matching doors, the pickaxe buys a moment of protection. Arrows move, <strong>Z</strong> jumps, <strong>P</strong> pauses. 30 stages.",
  "video": {
   "id": "9GLnL8Vasdw",
   "title": "Longplay: Gold Mine Run! (2023) [MS-DOS] | 4K/60"
  },
  "history": {
   "source": "Juan J. Martínez (reidrac), usebox.net",
   "url": "https://www.usebox.net/jjm/gold-mine-run/",
   "text": "A single-screen gold-grabbing platformer in the spirit of the early-80s arcades, from the same one-man studio as Alien Intruder &ndash; and a DOS descendant of his own MSX game Night Knight. Native 386 protected-mode code with VGA graphics, released free under CC BY-NC-SA; the open licence is why this vault hosts the download itself."
  }
 },
 "pc_hb_traxtor": {
  "input": "keyboard",
  "video": {
   "id": "h3IgPyMcMLQ",
   "title": "IBM PC/XT -=The Return of Traxtor=-"
  },
  "note": "Catch blocks with your tractor beam, load the bay, and fire them back into the descending wall &ndash; three of a kind clears them before they cross your defense line. Arrows move the ship, <strong>Space</strong> (or <strong>&#8593;</strong>) fires. 25 levels.",
  "history": {
   "source": "Juan J. Martínez (reidrac), usebox.net",
   "url": "https://www.usebox.net/jjm/return-of-traxtor-dos/",
   "text": "A match-3 puzzler that runs on a genuine 8086 IBM PC/XT with CGA graphics and PC speaker sound &ndash; the whole game is a single 16-kilobyte .COM file, built for the DOS COM Game Jam in 2023. Set a thousand years after the legendary Traxtor's last stand. Free under CC BY-NC-SA, from the same developer as Alien Intruder and Gold Mine Run!."
  }
 },
 "pc_hb_queens": {
  "input": "keyboard",
  "video": {
   "id": "-xpRxEJPeps",
   "title": "The Queen's Footsteps walkthrough (68K Mac - Davide Bucci)"
  },
  "note": "A classic text parser adventure &ndash; type commands, read carefully. Boots straight into the introduction text; type <strong>help</strong> for the full instruction list.",
  "history": {
   "source": "Davide Bucci's itch.io page (darwinne.itch.io/the-queens-footsteps), where the game is also released as open source.",
   "text": "A steampunk-Italy text adventure whose author later open-sourced the whole project &ndash; one of several genuinely open homebrew DOS titles active today."
  }
 },
 "pc_hb_spacecavern": {
  "input": "keyboard",
  "video": {
   "id": "ThWeT8z1Jb4",
   "title": "Space Cavern Blaster - All Levels (Amiga version)"
  },
  "note": "A cave-flyer shooter/platformer released simultaneously for C64, Amiga, Atari ST, DOS and Sega Genesis &ndash; same design, five 8/16-bit targets. Boots into the credits screen; press <strong>Return</strong> (or Start) to begin.",
  "history": {
   "source": "dotmos's itch.io page (dotmos.itch.io/space-cavern-blaster), originally built for Retro Platform Jam #6."
  }
 },
 "pc_hb_barren": {
  "input": "keyboard",
  "video": {
   "id": "rCXYR26CQr8",
   "title": "Barren Planet Developer Play livestream"
  },
  "note": "A turn-based sci-fi strategy game, source available on GitHub. Boots straight into the title screen; press <strong>Fire</strong> to begin.",
  "history": {
   "source": "Cyningstan's itch.io page (cyningstan.itch.io/barren-planet) and GitHub repository (github.com/cyningstan/barren)."
  }
 },
 "pc_hb_chambers": {
  "input": "keyboard",
  "video": {
   "id": "zA4PRdhEpPM",
   "title": "The Chambers Beneath Launch Stream"
  },
  "note": "A dungeon-crawling roguelike from the same developer as Barren Planet. Boots into a short loading screen before the title.",
  "history": {
   "source": "Cyningstan's itch.io page (cyningstan.itch.io/the-chambers-beneath)."
  }
 },
 "pc_hb_hibernated1": {
  "input": "keyboard",
  "video": {
   "id": "0wZRNXyw6Yo",
   "title": "Hibernated 1: Director's Cut walkthrough (C64 - Puddle Software)"
  },
  "note": "An Infocom-style text adventure originally written for the C64, later ported natively to DOS. Pay-what-you-want on itch.io; still needs adding to emulator/roms.",
  "history": {
   "source": "Stefan Vogt's itch.io page (8bitgames.itch.io/hibernated1)."
  }
 },
 "pc_hb_eightfeet": {
  "input": "keyboard",
  "note": "A standalone side-story to Hibernated 1, from the same author. Pay-what-you-want on itch.io; still needs adding to emulator/roms.",
  "history": {
   "source": "Stefan Vogt's itch.io page (8bitgames.itch.io/eight-feet-under)."
  }
 },
 "pc_hb_lake": {
  "input": "keyboard",
  "note": "A short text adventure built on the AGT engine. Boots straight into the title screen.",
  "history": {
   "source": "B.J. Best's itch.io page (bjbest60.itch.io/lake-adventure)."
  }
 },
 "pc_hb_acronia": {
  "input": "keyboard",
  "note": "A smooth-scrolling VGA action game, originally a DOS Games Jam prototype. Boots into the main menu with <strong>NEW GAME</strong> already highlighted &ndash; press <strong>Return</strong>.",
  "video": {
   "id": "cM_0QdRptEw",
   "title": "Acronia | official teaser trailer"
  },
  "history": {
   "source": "Hadrosaurus Software's itch.io page (hadrosaurus.itch.io/acronia), first shown at the DOS Games Spring Jam 2021."
  }
 },
 "pc_hb_catsbroombas": {
  "input": "keyboard",
  "note": "A puzzle game about cats and broomsticks, built for DOS from the ground up. Boots into a hand-drawn title screen.",
  "video": {
   "id": "JEZq1GlYD7I",
   "title": "Cats on Broombas Demo Release Trailer"
  },
  "history": {
   "source": "Eigen Lenk's itch.io page (eigen.itch.io/cats-on-broombas)."
  }
 },
 "pc_gta1": {
  "input": "keyboard",
  "manual": {
   "item": "pc_gta1",
   "pages": 13,
   "source": "Grand Theft Auto (PC, 1997) - original printed manual, scanned copy via oldgames.sk"
  },
  "note": "Top-down, arrow keys to drive. <strong>Space</strong> is the handbrake, <strong>Enter</strong> gets you in/out of a car. Once you're on foot and armed: <strong>Ctrl</strong> fires, <strong>Z</strong>/<strong>X</strong> cycle to the previous/next weapon. On first launch you'll see a text-mode Miles Sound System hardware-detection screen before the game itself starts &ndash; press a key to continue through it, this only needs doing once per session. <strong>F1</strong> brings up the in-game help/controls screen if you get stuck. <strong>Esc</strong> opens DOSBox's own menu, not the game's.",
  "video": {
   "id": "Akmg6dUkwKc",
   "title": "GTA 1 Longplay: Full Playthrough 100% (No Commentary)"
  },
  "history": {
   "text": "DMA Design's last game before the studio became Rockstar North &ndash; a top-down crime spree across three fictional cities (Liberty City, San Andreas, Vice City, names the later 3D sequels would reuse) that let players steal cars, run from police and rack up points for chaos, developed under the working title \"Race'n'Chase.\" Published by BMG Interactive in Europe and ASC Games in North America; it drew tabloid controversy on release for rewarding crime rather than punishing it, and its top-down engine and free-roaming city design became the template for the franchise's next three decades."
  }
 },
 "c64_outrun": {
  "input": "joystick",
  "note": "When it boots you&rsquo;ll see a blue <strong>UNLIMITED TIME ? (Y/N)</strong> trainer prompt &ndash; press <strong>N</strong> for the normal game (or <strong>Y</strong> to never run out of time). Steer left/right at the &ldquo;Select music&rdquo; screen to pick a tune, then press <strong>Fire</strong> to start. Controls use the <strong>second</strong> joystick set: on the keyboard that&rsquo;s <strong>W</strong> accelerate, <strong>S</strong> brake, <strong>A</strong>/<strong>D</strong> steer, and <strong>Q</strong> for gear-shift and to start the race.",
  "video": {
   "id": "pnuYHmSLUY4",
   "title": "Commodore 64 Longplay [308] OutRun (US Gold) (EU)"
  },
  "history": {
   "text": "Sega's 1986 arcade smash, brought to the C64 for Mindscape's US release (credited to Martin Webb, Dennis Webb, Chris Oberth and Lou Haehn) with US Gold handling the European release. Squeezes Yu Suzuki's branching, checkpoint-based route selection and pick-your-track soundtrack (Passing Breeze, Splash Wave, Magical Sound Shower) onto 8-bit hardware &ndash; no small feat for a game built around a scaling, forking road."
  }
 },
 "c64_samantha_fox_strip_poker": {
  "input": "joystick",
  "video": {
   "id": "A6Fw91h7ez0",
   "title": "Samantha Fox Strip Poker (Martech, 1986) – Commodore 64 – completed (aca0808)"
  },
  "manual": {
   "source": "Retro Vault",
   "text": "<p><strong>How to play.</strong> The C64 version is <strong>five-card draw</strong>, one-on-one against Sam. You both start with 100 credits and ante 5. Look at your five cards, then <strong>BET</strong> (05, 10, 15 or 20), <strong>STAND</strong> (check) or <strong>FOLD</strong>; when Sam bets back you get <strong>CALL / RAISE / FOLD</strong>. In the draw, pick the cards to throw away on the <strong>-1- to -5-</strong> bar and confirm with the arrow to get new ones. After a second round of betting the best hand wins the pot. As you take Sam's credits she sheds a layer; if she wins them back, she can put it back on.</p><p><strong>Controls:</strong> joystick left/right (arrow keys) to highlight, fire (<strong>G</strong>) to choose; <strong>Space</strong> at the title screen starts the deal.</p><p><strong>Best hands, high to low:</strong> straight flush, four of a kind, full house, flush, straight, three of a kind, two pair, one pair.</p><p>New to poker? Our two-page guide covers hand rankings, ties, betting and what to keep in the draw: <a href=\"extras/c64_samantha_fox_strip_poker-how-to-play-poker.pdf\" target=\"_blank\" rel=\"noopener\">How to play poker (PDF)</a>. For the full rules of every variant, see <a href=\"https://www.pokerstars.be/en/poker/games/rules/\" target=\"_blank\" rel=\"noopener\">PokerStars' poker rules</a>.</p>"
  },
  "history": {
   "text": "Martech's 1986 cash-in on the era's biggest pin-up: 5-card stud against a digitised Samantha Fox, who sheds a layer every time you clean her out. Critics were lukewarm (Commodore Format later crowned it the most unerotic strip poker game ever), but the outrageous concept made it a cult classic. The cheesy covers of The Entertainer and The Stripper are credited to “John York” – years later Rob Hubbard admitted the alias was his."
  }
 },
 "pc_outrun": {
  "input": "keyboard",
  "note": "Arrow keys drive: <strong>Up</strong> accelerates, <strong>Down</strong> brakes, <strong>Left</strong>/<strong>Right</strong> steer. <strong>Space</strong> shifts gears. <strong>Ctrl+P</strong> pauses, <strong>Ctrl+Q</strong> toggles sound, <strong>Ctrl+J</strong>/<strong>Ctrl+K</strong> swap between joystick and keyboard control. On first launch you'll be asked to pick a graphics mode &ndash; press <strong>3</strong> for EGA/VGA.",
  "video": {
   "id": "pTf9s7iTJn4",
   "title": "Out Run (Unlimited Software) (MS-DOS) [1989] [PC Longplay]"
  },
  "history": {
   "text": "Sega's 1986 arcade smash, ported to MS-DOS in 1989 by Unlimited Software &ndash; the porting arm of Distinctive Software, the Vancouver studio that later became EA Canada &ndash; for Mindscape. Trades the arcade's sit-down cabinet and moving hardware for CGA/EGA/VGA graphics and a PC speaker/AdLib rendition of the soundtrack, but keeps the branching, checkpoint-based route selection intact."
  }
 },
 "c64_hb_munchkin64": {
  "input": "joystick",
  "note": "A free-roam K.C. Munchkin homage: random maze generation plus a built-in maze editor, ten user-made mazes, and a 96-level Arcade mode. Same original-cartridge chase the Videopac shelf's own K.C. Munchkin! ran in 1981.",
  "video": {
   "id": "EvJ9rJYgoyA",
   "title": "Munchkin 64 PL Pretzel Logic 2MODES COMMODORE 64 PACMAN CLONE PAC MAN ELEMENTS LOOK INDIE RETRO NEWS"
  },
  "history": {
   "text": "Pretzel Logic's 2022 C64 recreation of K.C. Munchkin &ndash; the Videopac maze-eater whose resemblance to Pac-Man got it pulled from sale after Atari sued (see this vault's own vp_38). Munchkin 64 rebuilds the chase from scratch for the C64: random mazes, a maze editor, ten hand-built mazes to try, and a 96-level arcade mode. Free, name-your-own-price, with all donations going to cancer research."
  }
 },
 "c64_hb_roguebot": {
  "input": "keyboard",
  "video": {
   "id": "XuIZqFJ0YS4",
   "title": "Commodore 64 -=Roguebot=-"
  },
  "history": {
   "text": "A 2023 deck-building roguelike dungeon crawler for the C64 from drmortalwombat &ndash; better known for the C compiler/toolchain (oscar64) much of the modern C64 homebrew scene builds with. Draft and play cards to fight your way deeper into a procedurally generated dungeon."
  }
 },
 "c64_hb_veggies_vs_undead": {
  "input": "joystick",
  "video": {
   "id": "XAQ70gO0UQs",
   "title": "Commodore 64 -=Veggies vs Undead=-"
  },
  "history": {
   "text": "drmortalwombat's 2023 C64 demake of Plants vs. Zombies &ndash; lane-based tower defense with the same read-the-wave, plant-your-defenses rhythm, squeezed into 8-bit hardware. Free download; source published on GitHub."
  }
 },
 "c64_hb_shallow_domains": {
  "input": "keyboard",
  "video": {
   "id": "Ruipg2cFJ7o",
   "title": "Commodore 64 -=Shallow Domains=-"
  },
  "history": {
   "text": "A 2022 round-based strategy game for the C64 by drmortalwombat, played on a hexagonal map &ndash; pay-what-you-want, with the source code later published on GitHub."
  }
 },
 "c64_hb_comchinko": {
  "input": "joystick",
  "video": {
   "id": "_otmF7kUfOc",
   "title": "Commodore 64 -=Comchinko=-"
  },
  "history": {
   "text": "A 2026 pachinko-inspired casual game for the C64 by drmortalwombat &ndash; drop balls down a pegboard for chain-reaction bonuses, with Infinite, Highscore and Achievement modes."
  }
 },
 "c64_hb_broken_altars": {
  "input": "joystick",
  "video": {
   "id": "moGEyj685f8",
   "title": "Commodore 64 -=Broken Altars=-"
  },
  "history": {
   "text": "A 2026 puzzle game for the C64 by drmortalwombat &ndash; play archaeologist \"Fumbling Fred\", excavating gold and fragments to piece sixteen ancient altars back together. Supports mouse and keyboard."
  }
 },
 "c64_hb_trenchangle": {
  "input": "joystick",
  "video": {
   "id": "otT7XVQ89JQ",
   "title": "c64 - trenchangle (tower defense game on the c64)"
  },
  "history": {
   "text": "A 2026 tower-defense game for the C64 by drmortalwombat, with six tower types, a gold economy, and a meta-currency tech tree of permanent upgrades between runs."
  }
 },
 "c64_hb_overload": {
  "input": "keyboard",
  "history": {
   "text": "A 2024 incremental/idle clicker for the C64 by drmortalwombat &ndash; manually detonate fuel pellets in a nuclear reactor, then automate production, aiming for one billion energy units."
  }
 },
 "c64_hb_plekthora": {
  "input": "joystick",
  "video": {
   "id": "4zQDyaXHRKg",
   "title": "Plekthora (2021 Shmup) - C64 Gameplay"
  },
  "history": {
   "text": "A 2021 homebrew shoot-'em-up for the Commodore 64 by drmortalwombat, released free of charge."
  }
 },
 "c64_hb_terminal_walker": {
  "input": "joystick",
  "video": {
   "id": "HSfxhuy4ajY",
   "title": "Commodore 64 -=Terminal Walker=-"
  },
  "history": {
   "text": "A 2025 first-person stealth-infiltration game for the C64 by drmortalwombat, set in a 2029 AI datacenter &ndash; disable four control points and escape before the reactor overheats, avoiding slow-moving maintenance robots across 16 elevator-linked levels."
  }
 },
 "c64_hb_soiled_iron": {
  "input": "joystick",
  "video": {
   "id": "d6qIzRTU_vg",
   "title": "Commodore 64 -=Soiled Iron=-"
  },
  "history": {
   "text": "A 2024 two-player barbarian-style sword-fighting game for the C64 by drmortalwombat, with a single-player Quest mode (dungeon exploration with an auto-map and healing potions) alongside one-on-one duels. Music by Crisps."
  }
 },
 "c64_hb_portal_buster": {
  "input": "joystick",
  "video": {
   "id": "nas_f3KeI90",
   "title": "Commodore 64 -=Portal Buster=-"
  },
  "history": {
   "text": "A 2024 horizontally-scrolling shooter for the C64 by drmortalwombat, across a 32,000-pixel-wide level with nine weapon power-ups and color-coded hyperspace portals. Music by Crisps."
  }
 },
 "c64_hb_mineshaft_gap": {
  "input": "joystick",
  "video": {
   "id": "gAV8hlKNnLA",
   "title": "Commodore 64 -=Mineshaft Gap=-"
  },
  "history": {
   "text": "A 2024 real-time strategy game for the C64 by drmortalwombat &ndash; manage up to 32 dwellers in a post-nuclear-war underground bunker, balancing oxygen, minerals and research against rival bunkers. A nod to Dr. Strangelove's \"mineshaft gap\"."
  }
 },
 "c64_hb_metal_mayhem": {
  "input": "joystick",
  "video": {
   "id": "l-n6xwA_TtI",
   "title": "Commodore 64 -=Metal Mayhem=-"
  },
  "history": {
   "text": "A 2024 vertical split-screen tank battle for the C64 by drmortalwombat &ndash; two-player (or vs. computer) capture-the-flag combat, addressing what the developer called \"a severe lack of vertical split screen scrolling games\" on the platform."
  }
 },
 "c64_hb_corescape": {
  "input": "joystick",
  "video": {
   "id": "e-uqijgkWco",
   "title": "Commodore 64 -=Corescape=-"
  },
  "history": {
   "text": "A 2024 arcade space shooter for the C64 by drmortalwombat &ndash; fight through eight memorization-heavy stages to escape a galactic empire's hub station. Optional trainer modes for casual play."
  }
 },
 "c64_hb_missile_defence": {
  "input": "mouse",
  "video": {
   "id": "B8t8H-FPX6s",
   "title": "Commodore 64 -=Missile Defence=-"
  },
  "history": {
   "text": "A 2023 Missile Command-style conversion for the C64 by drmortalwombat &ndash; defend six cities with three anti-missile batteries against incoming ICBMs, with 1351 mouse support and dual-SID audio by Crisps."
  }
 },
 "c64_hb_balls_like_a_frog": {
  "input": "joystick",
  "video": {
   "id": "36fvpUFDm_M",
   "title": "Balls like a Frog / C64"
  },
  "history": {
   "text": "A 2023 Zuma-style puzzle game for the C64 by drmortalwombat &ndash; fire projectiles from a temple frog to clear rolling spheres before they reach the skull, across 76 levels in Adventure mode plus Gauntlet and Training."
  }
 },
 "c64_hb_minotrace": {
  "input": "joystick",
  "video": {
   "id": "oRCoTpERrvM",
   "title": "Commodore 64 -=Minotrace=-"
  },
  "history": {
   "text": "A 2022 maze racing game for the C64 by drmortalwombat, built around a fast grid-based ray-casting routine for 3D labyrinth visuals &ndash; race the clock through 27 levels across eight maze-generation styles."
  }
 },
 "c64_hb_ball_and_chain": {
  "input": "joystick",
  "video": {
   "id": "7q5xXS5AURM",
   "title": "Commodore 64 -=Ball and Chain=-"
  },
  "history": {
   "text": "A 2022 endless runner for the C64 by drmortalwombat &ndash; control a helium-filled bouncy ball tethered to a heavy iron ball, shortening or releasing the chain to steer past enemies and walls. Music by Crisps."
  }
 },
 "c64_hb_gates_of_the_ancient": {
  "input": "joystick",
  "video": {
   "id": "h82gPUcPcS0",
   "title": "Commodore 64 -=Gates of the Ancient=-"
  },
  "history": {
   "text": "A 2021 3D space exploration and combat game for the C64 by drmortalwombat, in the Elite tradition &ndash; explore wormhole-linked galaxies, trade and fight pirates, and upgrade your ship in a roguelike loop where death lets you restart with accumulated credits."
  }
 },
 "am_sqrxz": {
  "input": "joystick",
  "video": {
   "id": "TCORbwf5Q78",
   "title": "Sqrxz - Mindblasting Frustration Deluxe! (Amiga OCS)"
  },
  "history": {
   "text": "A 2012 Amiga OCS port of Retroguru's minimalist, brutally hard platformer &ndash; one screen at a time, instant death, and a Sokoban-esque puzzle sensibility layered onto pixel-perfect jumping."
  }
 },
 "am_sqrxz3": {
  "input": "joystick",
  "video": {
   "id": "E0-95KOtX2M",
   "title": "Amiga Longplay: Sqrxz 3"
  },
  "history": {
   "text": "Sqrxz 3: Adventure for Love, released for Amiga OCS in 2015 &ndash; the series keeps its one-hit-death platforming but adds new hazards and a longer campaign than the original."
  }
 },
 "am_sqrxz4": {
  "input": "joystick",
  "video": {
   "id": "MN_5mF6cqTU",
   "title": "Amiga Longplay: Sqrxz 4 - Cold Cash"
  },
  "history": {
   "text": "Sqrxz 4: Cold Cash, a 2018 Amiga OCS release &ndash; the fourth entry in Retroguru's uncompromising platform series, with the same instant-death, memorize-and-retry design as the rest."
  }
 },
 "am_wizzys_quest": {
  "input": "joystick",
  "video": {
   "id": "MtLfBuGVSPg",
   "title": "Amiga 500 Longplay [370] Wizzy's Quest (Public Domain)"
  },
  "history": {
   "text": "A 1990 public-domain Amiga puzzle-platformer by Guido and Sören Appenzeller, built around pushing and stacking blocks Boulder-Dash style to clear a path to the exit on each screen."
  }
 },
 "am_cybernetix": {
  "input": "joystick",
  "video": {
   "id": "fuKtR_ATXDk",
   "title": "1GO Short Play - Cybernetix: The First Battle (Amiga)"
  },
  "history": {
   "text": "Cybernetix: The First Battle, a 1991 Amiga shoot-'em-up from Vision Software (Paul Andrews, Rodney Smith, Blair Zuppicich) with side-scrolling combat and a distinctive sci-fi look."
  }
 },
 "am_deluxe_galaga": {
  "input": "joystick",
  "model": "A500P_STOCK",
  "video": {
   "id": "MRY22mFcACs",
   "title": "Deluxe Galaga [Amiga 600 Longplay] (1995) Edgar Vigdal"
  },
  "history": {
   "text": "Deluxe Galaga, Edgar Vigdal's freeware Amiga tribute to Namco's arcade classic, first released in the early 1990s and refined across several later updates."
  }
 },
 "am_megaball": {
  "input": "mouse",
  "video": {
   "id": "6WLBiZt8RbI",
   "title": "Gameplay Megaball v4 Commodore Amiga 720p"
  },
  "history": {
   "text": "MegaBall, Ed and Al Mackey's mouse-controlled Breakout/Arkanoid-style Amiga classic &ndash; clear each brick layout with power-ups and multi-ball chaos, steering the paddle with the mouse."
  }
 },
 "am_zerg": {
  "input": "keyboard",
  "video": {
   "id": "7OXhnQJ-4PA",
   "title": "AMIGA Zerg By Mike Shapiro (1990)"
  },
  "history": {
   "text": "A 1989 shareware/PD dungeon-crawler RPG by Mike Shapiro &ndash; simple keyboard-driven stats and combat, one of the more ambitious solo-coder RPGs to come out of the Amiga PD scene."
  }
 },
 "am_doctor_strange_2": {
  "input": "joystick",
  "video": {
   "id": "hkoaiyo_hKk",
   "title": "Amiga Longplay: Doctor Strange 2 (reupload with better quality)"
  },
  "history": {
   "text": "A 1995 freeware platformer by Ouija Board (distributed via 17-Bit Software) &ndash; the pick-armed hero returns with a green squirting gun, collecting his way through single-screen levels."
  }
 },
 "am_pollymorf": {
  "input": "joystick",
  "video": {
   "id": "vSxNQwFAX4E",
   "title": "Amga Longplay: Pollymorf"
  },
  "history": {
   "text": "A 1993 public-domain puzzle game by Andrew Campbell &ndash; group balls of matching colour together to clear them, with a gentle start and a sharp difficulty ramp."
  }
 },
 "am_dogfight": {
  "input": "joystick",
  "video": {
   "id": "fWMkUdoBWco",
   "title": "AMIGA Dogfight OTHER GAME AMIGA OCS v1.1 AMOS 19xx By Richard Ling"
  },
  "history": {
   "text": "A 1996 public-domain two-player biplane dogfighting game by Richard Ling, built in AMOS &ndash; a PD scene favourite for split-screen First World War dogfights against a friend."
  }
 },
 "am_drip": {
  "input": "joystick",
  "video": {
   "id": "fKuW8EadQGw",
   "title": "AMIGA DRIP AMIGA OCS OTHER GAME By Skiles Art In 1989 PD adf"
  },
  "history": {
   "text": "A 1989 public-domain puzzle game by Art Skiles &ndash; guide a drip of water along a network of pipes, turning them rusty red, on a fresh screen layout every time you play."
  }
 },
 "am_bobs_garden": {
  "input": "joystick",
  "video": {
   "id": "a8gyZeAJdcA",
   "title": "Bob's Garden Amiga"
  },
  "history": {
   "text": "A 1993 shareware Mr. Do! clone by Justin Leck &ndash; dig through a single-screen garden collecting cherries while avoiding the enemies chasing you down."
  }
 },
 "am_super_obliteration": {
  "input": "joystick",
  "video": {
   "id": "UzGfOl1ub-4",
   "title": "Amiga 500 Longplay [414] Super Obliteration (Public Domain)"
  },
  "history": {
   "text": "A 1993 public-domain Pang clone by David Papworth, set in a futuristic sci-fi setting &ndash; pop the descending bubbles before they split, land, and crush you."
  }
 },
 "am_asteroids": {
  "input": "joystick",
  "video": {
   "id": "jSyuFwGEKRw",
   "title": "cabaret asteroids for Amiga"
  },
  "history": {
   "text": "Cabaret Asteroids, a 1991 shareware arcade-perfect port of the coin-op classic by Vertical Developments &ndash; the same stark black-and-white vector look, rendered on the Amiga."
  }
 },
 "am_alien_fish_finger": {
  "input": "joystick",
  "video": {
   "id": "y1VVQhdSiu8",
   "title": "Amiga 500 Longplay [394] Alien Fish Finger (Public Domain)"
  },
  "history": {
   "text": "A 1996 platformer by Skull Army (David Cruickshank) &ndash; one of the Amiga PD scene's most fondly remembered platform games, still being updated years after its original release."
  }
 },
 "am_wibble_world_giddy": {
  "input": "joystick",
  "video": {
   "id": "wsphnFR68s8",
   "title": "Wibble World Giddy: Wibble Mania! (Amiga Longplay)"
  },
  "history": {
   "text": "A 1993 public-domain platformer by Phillip Ruston &ndash; a well-loved take on the Dizzy games, popular enough on the PD scene that it was later updated for the PC too."
  }
 },
 "am_crazy_sue": {
  "input": "joystick",
  "video": {
   "id": "ECQD0vXzwYo",
   "title": "Amiga 500 Longplay [112] Crazy Sue (Public Domain)"
  },
  "history": {
   "text": "A 1991 public-domain platformer published by MC Publications &ndash; its clear references to The Great Giana Sisters made it an instant PD scene favourite, popular enough to get its own sequel."
  }
 },
 "am_pengo2": {
  "input": "joystick",
  "kickstart": "aros",
  "model": "ENGINE_DEFAULT",
  "video": {
   "id": "4Zxi7GXUA54",
   "title": "pengo 2 for Amiga"
  },
  "history": {
   "text": "Pengo 2, a 1994 giftware maze game by Reploid &ndash; push and crush the enemies between ice blocks, in the Amiga PD scene's spin on the Sega arcade classic."
  }
 },
 "am_toado": {
  "input": "joystick",
  "video": {
   "id": "Es7QK3FEhC8",
   "title": "Amiga 500 - Toado (Public Domain)"
  },
  "history": {
   "text": "A 1994 public-domain Frogger clone by J. Wills &ndash; guide your character across traffic and a river of hazards to safety, with lovely hand-drawn graphics for a PD title."
  }
 },
 "am_deluxe_pacman": {
  "input": "joystick",
  "kickstart": "aros",
  "model": "ENGINE_DEFAULT",
  "video": {
   "id": "EDAPh3Tk7mw",
   "title": "Amiga 1200 Longplay [014] Deluxe Pac-Man (Public Domain)"
  },
  "history": {
   "text": "A 1992 shareware Pac-Man clone by Edgar Vigdal, the same author as the vault's own Deluxe Galaga &ndash; updated repeatedly over the years to near-arcade-perfect polish."
  }
 },
 "am_llamatron": {
  "input": "joystick",
  "video": {
   "id": "Zp5bSasqHC0",
   "title": "Llamatron on the Amiga"
  },
  "history": {
   "text": "Llamatron: 2112, Jeff Minter's 1991 shareware reworking of Robotron: 2084 for Llamasoft &ndash; blast waves of enemies from every direction while rescuing llamas, sheep in tow."
  }
 },
 "am_gorf": {
  "input": "joystick",
  "video": {
   "id": "8aIHVhpH23o",
   "title": "Commodore Amiga GORF [Remake] Gameplay"
  },
  "history": {
   "text": "A 1993 shareware tribute to the classic multi-stage arcade shooter Gorf, by Towerbyte &ndash; fly through a gauntlet of distinct space-combat stages back to back."
  }
 },
 "am_dropzone": {
  "input": "joystick",
  "video": {
   "id": "HQa8NmWIee8",
   "title": "Dropzone - Commodore Amiga (No Commentary)"
  },
  "history": {
   "text": "DropZone, a 1994 shareware Defender-style side-scrolling shooter by Richard Tunstall &ndash; rescue stranded troopers from the surface while fending off waves of alien attackers."
  }
 },
 "am_elevation": {
  "input": "joystick",
  "video": {
   "id": "mRqzq-98CPE",
   "title": "Elevation - Commodore Amiga Longplay Public Domain/Freeware"
  },
  "history": {
   "text": "A 1995 shareware arcade game by Delta-9 &ndash; move your character across the screen while dodging the lifts, a clever twist on a familiar avoid-the-hazard format."
  }
 },
 "am_trailblazer": {
  "input": "joystick",
  "video": {
   "id": "v-9asLyNNww",
   "title": "trailblazer for Amiga"
  },
  "history": {
   "text": "A 1992 public-domain update of the C64 classic by Alchemy Productions &ndash; roll your ball along a tiled, hazard-strewn courseway as fast as you dare."
  }
 },
 "am_space_taxi": {
  "input": "joystick",
  "video": {
   "id": "cooHU5hipoA",
   "title": "AMIGA Space Taxi AMIGA OCS 19xx Effect PD adf"
  },
  "history": {
   "text": "A public-domain update of the C64 classic Space Taxi by Effect &ndash; land precisely on numbered pads to pick up and deliver fares across the galaxy."
  }
 },
 "am_robocop": {
  "manual": {
   "item": "am_robocop",
   "pages": 2,
   "source": "RoboCop (Ocean, 1988) - the 8-bit tape edition's inlay, as no Amiga manual scan is online; the story and gameplay match, but loading and controls are for the C64, Spectrum and Amstrad. Scan via archive.org (RoboCop_1988_Ocean_Software_Ltd_2252_Instructions)"
  },
  "input": "joystick",
  "video": {
   "id": "WWXne7Z3IYY",
   "title": "RoboCop [Amiga Longplay] (1989) Ocean"
  },
  "history": {
   "text": "Ocean's conversion of the Robocop arcade/movie license – five levels of street-cleaning action as Alex Murphy's cybernetic alter ego, armed with the Auto-9 pistol."
  }
 },
 "am_jimmywhite": {
  "input": "mouse",
  "video": {
   "id": "oDibtKZQaiE",
   "title": "JIMMY WHITE'S 'WHIRLWIND' SNOOKER | Commodore Amiga (1991)"
  },
  "history": {
   "text": "Archer Maclean's snooker simulation, built around the same physics engine that made his earlier International Karate famous – still considered one of the best snooker games ever made."
  }
 },
 "am_ohnomorelemmings": {
  "input": "mouse",
  "video": {
   "id": "glWTIKqT1CA",
   "title": "Amiga Longplay Oh No! More Lemmings (part 1 of 2)"
  },
  "history": {
   "text": "Psygnosis' stand-alone follow-up to Lemmings, with 100 new (and considerably harder) levels across five difficulty tiers, using the same eight skills to guide the lemmings to safety."
  }
 },
 "am_bubblebobble": {
  "input": "joystick",
  "model": "A500P_STOCK",
  "video": {
   "id": "ualveckK6is",
   "title": "BUBBLE BOBBLE - Amiga Longplay (Walkthrough! ALL LEVELS! No umbrella! 2-Players)"
  },
  "history": {
   "text": "Taito's arcade classic, ported by Software Creations for Firebird – Bub and Bob blow bubbles to trap enemies across 100 single-screen levels, solo or in two-player co-op."
  }
 },
 "am_turrican": {
  "manual": {
   "item": "am_turrican",
   "pages": 9,
   "source": "Turrican (Rainbow Arts, 1990) - the multi-format instructions covering the Amiga as well as the 8-bit versions. Scan via archive.org (Turrican_1990_Rainbow_Arts_4499_Instructions)"
  },
  "input": "joystick",
  "video": {
   "id": "j58lRNoa2c0",
   "title": "Turrican [Amiga Longplay] (1990) Rainbow Arts"
  },
  "history": {
   "text": "Manfred Trenz's run-and-gun landmark for Rainbow Arts – huge scrolling levels, a screen-clearing smart bomb, and the rolling-ball transformation that became the series' signature."
  }
 },
 "am_stuntcarracer": {
  "manual": {
   "item": "am_stuntcarracer",
   "pages": 2,
   "source": "Stunt Car Racer (Kixx budget re-release) - the multi-format instructions, Amiga included. Scan via archive.org (Stunt_Car_Racer_19xx_Kixx_1411_Instructions)"
  },
  "input": "joystick",
  "video": {
   "id": "q7w_0yP5RwU",
   "title": "Amiga Longplay: Stunt Car Racer"
  },
  "history": {
   "text": "Geoff Crammond's physics-driven stunt racer – elevated wireframe tracks over a ravine, where falling off costs you the run. Widely regarded as one of the best racing games of the 16-bit era."
  }
 },
 "am_lotusturbo2": {
  "input": "joystick",
  "video": {
   "id": "P3sE4I30WjU",
   "title": "Lotus Turbo Challenge 2 [Amiga Longplay] (1991) Gremlin Graphics"
  },
  "history": {
   "text": "Magnetic Fields' sequel to Lotus Esprit Turbo Challenge – three Lotus models, split-screen two-player, and a marble-run of shortcuts, jumps and traffic across the championship circuit."
  }
 },
 "am_megamaid": {
  "input": "joystick",
  "note": "This is a demo, not a game: it boots from the disk and plays by itself, with nothing to control. It displays a scanned magazine photograph and is <strong>not safe for work</strong>.",
  "history": {
   "text": "Not a game but a demo – a 1989 production by the Norwegian groups Pixar and The Band, placed fifth in the demo competition at the IMP-666 Megaparty in Arendal. It is one enormous 320×825 HAM photograph, scanned in three and a half parts from a men's magazine (as the scrolltext itself cheerfully admits) and stitched back together, carrying what its authors claimed was the first scrolltext ever run across a HAM picture."
  }
 },
 "am_act_of_war": {
  "input": "mouse",
  "video": {
   "id": "jxqA5lGOVO8",
   "title": "act of war for Amiga"
  },
  "history": {
   "text": "A public-domain Laser Squad tribute written in AMOS by David Smith – turn-based squad combat on a grid, with only the opening missions in the free release."
  }
 },
 "am_alien_bash": {
  "input": "joystick",
  "video": {
   "id": "4XtiO86QnxQ",
   "title": "ALIEN BASH (AMIGA - FULL GAME)"
  },
  "history": {
   "text": "A top-down corridor shooter in the Alien Breed mould, written by Glen Cumming and Stuart Law and given away through the PD libraries; amigapd.com rates the 1995 sequel higher still."
  }
 },
 "am_ant_wars": {
  "input": "mouse",
  "video": {
   "id": "dn3Vf6gGdOQ",
   "title": "1GO Short Play - Ant Wars (Amiga)"
  },
  "history": {
   "text": "An AMOS strategy game from the Paranoid group, distributed as public domain with its source code included on the disk."
  }
 },
 "am_atoms": {
  "input": "mouse",
  "video": {
   "id": "oj8oxjHeoJI",
   "title": "AMIGA Atoms! by Tom Kuhn"
  },
  "history": {
   "text": "A track-laying puzzler by Tom Kuhn: roll each ball home by flipping the points before it reaches them."
  }
 },
 "am_biplanes": {
  "input": "joystick",
  "video": {
   "id": "AbQqcimGW5o",
   "title": "1GO Short Play - Biplanes (Amiga)"
  },
  "history": {
   "text": "Two-player First World War dogfighting by Peter Mason, inspired by the Intellivision original – one joystick each, one sky, last plane flying wins."
  }
 },
 "am_black_dawn": {
  "input": "joystick",
  "video": {
   "id": "IvRx6UC5ZsM",
   "title": "1GO Short Play - Black Dawn (Amiga)"
  },
  "history": {
   "text": "Andrew Campbell's corridor crawler — step-by-step first-person dungeon shooting written in AMOS and released as public domain. Campbell also wrote Pollymorf, already on this shelf."
  }
 },
 "am_colonial_conquest2": {
  "input": "mouse",
  "video": {
   "id": "8ZgrlkMr6FE",
   "title": "Amiga 500 Longplay [103] Colonial Conquest II (Public Domain)"
  },
  "history": {
   "text": "Christian Mumenthaler's AMOS strategy game about planting and defending colonies across the galaxy – the sequel to his 1993 original, and like it distributed as giftware."
  }
 },
 "am_diplomacy": {
  "input": "mouse",
  "video": {
   "id": "2LkHXjR4zfA",
   "title": "AMIGA Diplomacy by Steve Douthat"
  },
  "history": {
   "text": "Steve Douthat's Amiga conversion of the Avalon Hill board game – pre-First-World-War Europe, seven powers, and orders written in secret each turn."
  }
 },
 "am_donkey_kong": {
  "input": "joystick",
  "video": {
   "id": "FzhhfViWeWc",
   "title": "Donkey Kong (Bignonia Conversion) for the Commodore Amiga"
  },
  "history": {
   "text": "Bignonia's public-domain conversion of the 1981 Nintendo arcade cabinet, built from the C64 version's layouts – amigapd.com calls it near arcade-perfect."
  }
 },
 "am_doody": {
  "input": "joystick",
  "video": {
   "id": "10vDkpPvckI",
   "title": "doody for Amiga"
  },
  "history": {
   "text": "A Mario Bros-style single-screen platformer from W.G.S.S., written for Amiga Format – amigapd.com gives it five stars and calls it one of the best platform games in the Amiga public domain."
  }
 },
 "am_elevation2": {
  "input": "joystick",
  "video": {
   "id": "icEFGDJ3GoU",
   "title": "Elevation 2 - Commodore Amiga Longplay"
  },
  "history": {
   "text": "Lee C. Wilson's AMOS sequel for Delta-9, following Elevation – already on this shelf. The disk carries no release date; TOSEC records it only as 199x."
  }
 },
 "am_hellzone": {
  "input": "joystick",
  "video": {
   "id": "jH1QfK7_Cw4",
   "title": "hellzone: carnage extreme for Amiga"
  },
  "history": {
   "text": "An Australian shareware shoot-'em-up from Interscan – the disk's own notice asks A$12 of anyone who keeps playing it. The free release carries the first two levels."
  }
 },
 "am_knights": {
  "input": "joystick",
  "video": {
   "id": "rmNELaGZmrQ",
   "title": "AMIGA Knights v2.4 by Reaper (1994)"
  },
  "history": {
   "text": "A medieval jousting game in AMOS from the Reaper group, released as freeware in 1994 and revised later the same year."
  }
 },
 "am_mayhem": {
  "input": "joystick",
  "video": {
   "id": "fs30DLGxqhs",
   "title": "AMIGA Mayhem by Ensignia"
  },
  "history": {
   "text": "A public-domain release from the Ensignia group. The disk boots to Ensignia's own menu — the game is the third entry, alongside a greetings screen and a vector demo."
  }
 },
 "am_particle_man": {
  "input": "joystick",
  "video": {
   "id": "NMu4xZcnNdQ",
   "title": "Amiga Longplay: Particle Man"
  },
  "history": {
   "text": "Paul Nordovics' AMOS platformer, given away as public domain with its full source code on the disk. TOSEC records no release year beyond 199x."
  }
 },
 "am_sqrxz2": {
  "input": "joystick",
  "video": {
   "id": "vpwD8kWvsGA",
   "title": "Amiga Longplay: Sqrxz 2"
  },
  "history": {
   "text": "The middle chapter of Retroguru's deliberately merciless platform series – the vault already carries Sqrxz, Sqrxz 3 and Sqrxz 4, and this completes the run."
  }
 },
 "am_tanx": {
  "input": "joystick",
  "video": {
   "id": "IHuz0BqzkPE",
   "title": "Tanx | Amiga"
  },
  "history": {
   "text": "Gaz Robertz's take on the artillery duel – pick an angle and a charge, drop a shell on the other tank, adjust for the wind. Given away on an Amiga Computing coverdisk and through the PD libraries."
  }
 },
 "am_top_secret": {
  "input": "joystick",
  "video": {
   "id": "AUJe6oPBFRM",
   "title": "Amiga Longplay - Top Secret"
  },
  "history": {
   "text": "A public-domain release from the group The Hidden, distributed through the Amiga PD libraries in 1992."
  }
 },
 "am_transplant": {
  "input": "joystick",
  "video": {
   "id": "sXQW7q1fOOk",
   "title": "Transplant (Amiga PD)"
  },
  "history": {
   "text": "A split-screen shoot-'em-up from Jumping Jack Flash – one or two players, level passwords, and a difficulty curve that earned it a place on amigapd.com's PD lists."
  }
 },
 "am_trap_runner": {
  "input": "joystick",
  "video": {
   "id": "FgOfDo3uPS0",
   "title": "Commodore Amiga -=Trap Runner=-"
  },
  "history": {
   "text": "A modern Amiga OCS platformer by Night Owl Design, published by Retroguru in 2018 – bright, fast, and built to run on a stock A500."
  }
 },
 "am_turboraketti": {
  "input": "joystick",
  "video": {
   "id": "okf-8-PkJIA",
   "title": "AMIGA TurboRaketti by Heikki Kosola (1992)"
  },
  "history": {
   "text": "A Finnish two-player caveflyer by Heikki Kosola – Thrust-like ships fighting gravity through tight caverns while shooting at each other. The game is in Finnish throughout."
  }
 },
 "am_arkanoid2": {
  "input": "mouse",
  "manual": {
   "item": "am_arkanoid2",
   "pages": 4,
   "source": "Arkanoid: Revenge of Doh (Imagine, 1988) - the C64 edition's inlay, as no Amiga manual scan is online; the story, controls, scoring and capsule list match the Amiga game, but the loading instructions are for the C64. In English, French and German. Scan via archive.org (Arkanoid_2_Revenge_of_Doh_1988_Imagine_Software)"
  },
  "video": {
   "id": "Aywky7cfb4o",
   "title": "Amiga 500 Longplay [274] Arkanoid: Revenge of DOH"
  },
  "history": {
   "text": "Taito's sequel to Arkanoid, converted to the Amiga by Peter Johnson for Imagine – thirty-three new screens, new capsules, and a choice of route through the level tree."
  }
 },
 "am_battle_squadron": {
  "input": "joystick",
  "video": {
   "id": "fkXK9lgqDAo",
   "title": "Amiga 500 Longplay [308] Battle Squadron"
  },
  "history": {
   "text": "Cope-Com's vertical shooter, still one of the Amiga's most admired – fifty frames a second, a two-player co-op mode, and a soundtrack by Ron Klaren."
  }
 },
 "am_blood_money": {
  "input": "joystick",
  "video": {
   "id": "qxciUa4YmeY",
   "title": "Amiga Longplay Blood Money"
  },
  "history": {
   "text": "DMA Design's follow-up to Menace – four hostile worlds, a shop between stages, and the cash you collect doubling as both score and ammunition budget."
  }
 },
 "am_bubble_ghost": {
  "input": "joystick",
  "video": {
   "id": "yjWmnvCdlzo",
   "title": "Bubble Ghost - Overview & Gameplay (Commodore Amiga 1988)"
  },
  "history": {
   "text": "Christophe Andreani's puzzler: you are a ghost who cannot touch anything, blowing a fragile soap bubble through sixty rooms of spikes, candles and fans."
  }
 },
 "am_chuck_rock": {
  "input": "joystick",
  "video": {
   "id": "Tojq1k5RXqY",
   "title": "Chuck Rock Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "Core Design's prehistoric platformer – a belly-flopping caveman looking for Ophelia, with some of the best-drawn parallax backdrops on the machine."
  }
 },
 "am_double_dragon": {
  "input": "joystick",
  "video": {
   "id": "6RDgt26Zcio",
   "title": "Double Dragon Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "The Amiga conversion of Technos' arcade beat-'em-up – Billy and Jimmy Lee, the Black Warriors, and a baseball bat whenever you can take one off somebody."
  }
 },
 "am_dynablaster": {
  "input": "joystick",
  "video": {
   "id": "plQv_V4d3xY",
   "title": "Amiga 500 Longplay [151] Dyna Blaster"
  },
  "history": {
   "text": "The European name for Bomberman – a maze, a pile of soft blocks, and up to five players racing to blow each other up. The Amiga version is widely held to be the best of its era."
  }
 },
 "am_hunter": {
  "input": "joystick",
  "video": {
   "id": "q09_wQO5o5I",
   "title": "Amiga Longplay [095] Hunter"
  },
  "history": {
   "text": "Paul Holmes' open-world sandbox, years ahead of its time – a filled-polygon archipelago you can cross on foot, by jeep, boat, tank, helicopter or windsurfer, with missions taken in any order."
  }
 },
 "am_hybris": {
  "input": "joystick",
  "video": {
   "id": "AU26EKUHEHc",
   "title": "Hybris Longplay (Amiga) [4K]"
  },
  "history": {
   "text": "Cope-Com's first Amiga shooter and the machine's early showcase for smooth vertical scrolling – the game that led directly to Battle Squadron."
  }
 },
 "am_ikplus": {
  "input": "joystick",
  "video": {
   "id": "OE56KsRz5mo",
   "title": "International Karate Plus (IK+) [Amiga Longplay] (1988) Archer Maclean"
  },
  "history": {
   "text": "Archer Maclean's three-way karate tournament – you, a rival and the computer all fighting at once on the same screen, with the referee's scoreboard the only thing keeping order."
  }
 },
 "am_jetstrike": {
  "input": "joystick",
  "video": {
   "id": "RrVojI20KQQ",
   "title": "Jetstrike AGA Amiga 1200 - Shadow Software / Rasputin Software 1994"
  },
  "history": {
   "text": "A side-on flight game with a huge hangar of real aircraft, a level editor, and missions that range from bombing runs to towing banners."
  }
 },
 "am_katakis": {
  "input": "joystick",
  "video": {
   "id": "jtXDAG98LJs",
   "title": "Amiga 500 Longplay [353] Katakis"
  },
  "history": {
   "text": "Factor 5's debut – an R-Type homage so close that Activision had it withdrawn, after which Factor 5 were hired to write the official R-Type conversion instead."
  }
 },
 "am_kick_off2": {
  "input": "joystick",
  "video": {
   "id": "w-xRYId9_NI",
   "title": "Amiga 500 Longplay [325] Kick Off 2"
  },
  "history": {
   "text": "Dino Dini's sequel, and for years the argument-settler of Amiga football – the ball is never glued to your feet, and everything follows from that."
  }
 },
 "am_lotus_esprit": {
  "manual": {
   "item": "am_lotus_esprit",
   "pages": 25,
   "source": "Lotus Esprit Turbo Challenge (Gremlin, 1990) - the multi-format instruction booklet, Amiga included. Scan via archive.org (Lotus_Esprit_Turbo_Challenge_1990_Gremlin_Graphics_9873_Instructions)"
  },
  "input": "joystick",
  "video": {
   "id": "s-aL07TxxxU",
   "title": "Lotus Esprit Turbo Challenge [Amiga Longplay] (1990) Gremlin"
  },
  "history": {
   "text": "Magnetic Fields' split-screen racer, built around the Esprit Turbo SE – two players on one machine, thirty-two stages, and a fuel gauge that turns every race into a route plan. The vault already carries its sequel."
  }
 },
 "am_magic_pockets": {
  "input": "joystick",
  "video": {
   "id": "yMEAwTUZprk",
   "title": "Magic Pockets Amiga Longplay (Real Amiga 500)"
  },
  "history": {
   "text": "The Bitmap Brothers at their most cheerful – a boy whose trouser pockets hold everything he needs, four themed worlds, and a Betty Boo title track."
  }
 },
 "am_menace": {
  "input": "joystick",
  "video": {
   "id": "NN9OzVhkqng",
   "title": "Menace [Amiga A500 - DMA Design, Psyclapse] (1988) Full Play"
  },
  "history": {
   "text": "DMA Design's first game, written while Dave Jones was still at college – six horizontally scrolling planets and the shop system that Blood Money would build on."
  }
 },
 "am_nebulus": {
  "input": "joystick",
  "video": {
   "id": "l0SIuucCC4Y",
   "title": "Simply Longplay - Nebulus [Amiga]"
  },
  "history": {
   "text": "John Phillips' rotating-tower climber – the tower turns as you walk, which is both the trick and the whole difficulty. Eight towers, a time limit, and a submarine ride between them."
  }
 },
 "am_new_zealand_story": {
  "input": "joystick",
  "video": {
   "id": "QCgEzhhV6SE",
   "title": "The New Zealand Story (1989) Amiga 500 Longplay"
  },
  "history": {
   "text": "Tiki the kiwi rescuing his friends from a leopard seal, across twenty rounds of arrow-shooting platform mazes – Ocean's conversion of Taito's arcade original."
  }
 },
 "am_nitro": {
  "input": "joystick",
  "video": {
   "id": "Y8BADR4_iIg",
   "title": "Nitro Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "A top-down three-car race with a fuel meter that never stops draining – finish, or coast to a halt and watch the other two disappear."
  }
 },
 "am_north_and_south": {
  "input": "joystick",
  "video": {
   "id": "U80-09s6Pu8",
   "title": "North & South Longplay (Amiga) [QHD]"
  },
  "history": {
   "text": "The American Civil War played as a board game with arcade battles inside it, drawn in the style of the Belgian comic Les Tuniques Bleues. Five languages on the disk."
  }
 },
 "am_pang": {
  "input": "joystick",
  "video": {
   "id": "ZVL2b8j1wAU",
   "title": "Amiga 500 Longplay [015] Pang"
  },
  "history": {
   "text": "Burst the bouncing balloons, and every one you hit splits into two smaller and faster ones. Fifty stages around the world, and a two-player mode that is the whole point."
  }
 },
 "am_parasol_stars": {
  "input": "joystick",
  "video": {
   "id": "6c7VbmFF9Vo",
   "title": "Amiga Longplay 179: Parasol Stars - Not commented"
  },
  "history": {
   "text": "The third Bubble Bobble game – Bub and Bob back on two feet, now with umbrellas they use to scoop up enemies and hurl them along the platforms."
  }
 },
 "am_populous": {
  "input": "mouse",
  "video": {
   "id": "7hAsa_uvIaU",
   "title": "Amiga longplay - Populous"
  },
  "history": {
   "text": "Peter Molyneux's god game, the one that named the genre – raise and lower land, grow your followers, and eventually drop a volcano on the other deity. This release includes The Promised Lands data disk."
  }
 },
 "am_rick_dangerous": {
  "manual": {
   "item": "am_rick_dangerous",
   "pages": 2,
   "source": "Rick Dangerous (Firebird, 1989) - the multi-format instructions sheet for Amiga, Atari ST, C64 and PC, in English, German and Italian. Scan via archive.org (rick-dangerous-en-de-it)"
  },
  "input": "joystick",
  "video": {
   "id": "17Bs9QJ8aYY",
   "title": "Amiga 500 Longplay [285] Rick Dangerous"
  },
  "history": {
   "text": "Core Design's trap-memorising platformer – an Indiana Jones pastiche in which almost everything kills you the first time and the fun is knowing what comes next."
  }
 },
 "am_rick_dangerous2": {
  "manual": {
   "item": "am_rick_dangerous2",
   "pages": 7,
   "source": "Rick Dangerous 2 (MicroStyle, 1990) - the multi-format instructions, Amiga included. Scan via archive.org (Rick_Dangerous_2_1990_MicroStyle_7572_Instructions)"
  },
  "input": "joystick",
  "video": {
   "id": "FVQDELvgv4k",
   "title": "Amiga 500 Longplay [286] Rick Dangerous II"
  },
  "history": {
   "text": "The sequel swaps temples for an alien invasion of Hyde Park – same lethal trap logic, brighter graphics, and five wildly different worlds."
  }
 },
 "am_robocod": {
  "input": "joystick",
  "video": {
   "id": "zx0KxbL0S2I",
   "title": "James Pond 2: Codename RoboCod Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "A fish in a stretchy robot suit, loose in Santa's toy factory – the suit's extending body is the whole mechanic, and the game is one of the best-loved platformers on the machine."
  }
 },
 "am_rodland": {
  "manual": {
   "item": "am_rodland",
   "pages": 19,
   "source": "Rod-Land (Storm, 1991) - the multi-format manual for Amiga, Atari ST, C64, CPC and Spectrum, in English, French, German and Italian. Scan via archive.org (rodland-computer)"
  },
  "input": "joystick",
  "video": {
   "id": "4W2IxoL_GHA",
   "title": "Rod-Land Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "Two fairies with magic rods clearing single-screen ladder mazes – grab an enemy, slam it into the ground, repeat. Jaleco's arcade game, converted by The Sales Curve."
  }
 },
 "am_rtype": {
  "input": "joystick",
  "video": {
   "id": "hCrN8N-mrP0",
   "title": "Amiga 500 Longplay [155] R-Type"
  },
  "history": {
   "text": "Irem's horizontal shooter, and the Force pod that made it famous – an indestructible orb you attach to the front or back of your ship, or send out on its own."
  }
 },
 "am_skweek": {
  "input": "joystick",
  "video": {
   "id": "S-S0f2TM-ik",
   "title": "Amiga 500 Longplay [340] Skweek"
  },
  "history": {
   "text": "Paint every blue tile pink before the clock runs out, across ninety-nine increasingly awkward boards. A French puzzle-action favourite that spawned two sequels."
  }
 },
 "am_speedball2": {
  "input": "joystick",
  "video": {
   "id": "ry_qLPOgIR8",
   "title": "Speedball 2: Brutal Deluxe Longplay (Amiga) [QHD]"
  },
  "history": {
   "text": "The Bitmap Brothers' future contact sport – a steel ball, no fouls worth the name, and a league to climb by buying better players with the money you win."
  }
 },
 "am_swiv": {
  "manual": {
   "item": "am_swiv",
   "pages": 5,
   "source": "SWIV (Storm, 1991) - filed on archive.org as the C64 manual, but the instructions cover the Amiga and Atari ST versions too, in English and German. Scan via archive.org (SWIV_1991_Storm)"
  },
  "input": "joystick",
  "video": {
   "id": "grRWWGKcV2I",
   "title": "SWIV Longplay (Amiga) [50 FPS]"
  },
  "history": {
   "text": "The unofficial Silkworm sequel – a helicopter and a jeep on one continuously scrolling battlefield, playable alone or two at once with no pause between levels."
  }
 },
 "am_turrican2": {
  "manual": {
   "item": "am_turrican2",
   "pages": 30,
   "source": "Turrican II: The Final Fight (Rainbow Arts, 1991) - the multi-format manual covering the Amiga, Atari ST, C64, CPC and Spectrum versions, in several languages. Scan via archive.org (turrican-ii)"
  },
  "input": "joystick",
  "video": {
   "id": "h7PVf8rY3YE",
   "title": "Amiga 500 Longplay [592] Turrican II: The Final Fight"
  },
  "history": {
   "text": "Manfred Trenz's sequel, and the high-water mark of the series – enormous open levels, a horizontal shooter stage dropped in the middle, and a Chris Huelsbeck soundtrack people still buy on vinyl. The vault already carries the first game."
  }
 },
 "am_wings_of_fury": {
  "manual": {
   "item": "am_wings_of_fury",
   "pages": 12,
   "source": "Wings of Fury (Broderbund) - the French manual ('Manuel d'utilisation') for the Amiga, CPC and PC versions; no English Amiga manual is online. Scan via archive.org (wings-of-fury-francais)"
  },
  "input": "joystick",
  "video": {
   "id": "ZZSwdqg6VE4",
   "title": "Amiga Longplay Wings of Fury"
  },
  "history": {
   "text": "Fly a Hellcat off a Pacific carrier, pick rockets, bombs or a torpedo for each sortie, and land again to rearm. A side-on arcade game with a real campaign behind it."
  }
 },
 "am_xenon2": {
  "input": "joystick",
  "video": {
   "id": "Bf0QTKsrNYY",
   "title": "Amiga 500 Longplay [371] Xenon 2: Megablast"
  },
  "history": {
   "text": "The Bitmap Brothers' vertical shooter, as famous for Bomb the Bass's Megablast soundtrack as for its shop, its organic levels and its ability to scroll backwards."
  }
 },
 "am_xout": {
  "manual": {
   "item": "am_xout",
   "pages": 6,
   "source": "X-Out (Rainbow Arts, 1990) - the German C64 release from the Top Shots compilation, as no Amiga manual scan is online; the story and gameplay match, but loading and controls are for the C64. Scan via archive.org (X-Out_1990_Rainbow_Arts)"
  },
  "input": "joystick",
  "video": {
   "id": "ayxAuoQDmY0",
   "title": "Amiga 500 Longplay [380] X-Out"
  },
  "history": {
   "text": "An underwater horizontal shooter with a shop screen that is half the game – you buy your submarines and drones before launching, and a bad purchase can sink the run."
  }
 },
 "am_zout": {
  "input": "joystick",
  "video": {
   "id": "vPGHuxe2PuI",
   "title": "Z-Out [Amiga Longplay] (1990) Rainbow Arts"
  },
  "history": {
   "text": "Rainbow Arts' follow-up to X-Out, this time above water and openly in debt to R-Type – six long levels, heavy parallax, and a drone system of its own."
  }
 },
 "am_tiny_pixel_adventure": {
  "input": "joystick",
  "video": {
   "id": "EtLn0JJQ6zo",
   "title": "Commodore Amiga -=Tiny Pixel Adventure=- full version update 06.10.2026"
  },
  "history": {
   "text": "A modern OCS platformer by HooGames2017, first released in 2024 and still being updated – the build here is the 6 October 2026 update. Stomp what can be stomped, shoot the rest with a limited quiver of arrows, and run errands for a key to the next area."
  }
 },
 "am_tenebra2": {
  "input": "joystick",
  "history": {
   "text": "Haplo's sequel to Tenebra, released on the Amiga in 2023 after the 8-bit versions – 35 levels of guiding a man who will not step into the dark, now with a portal gun. The disk asks first: press Y for the classic non-interlaced look (recommended on an A500), N for the enhanced interlaced one."
  }
 },
 "am_ooze": {
  "input": "joystick",
  "video": {
   "id": "-oLd2ipXqa0",
   "title": "Longplay OOZE: The Escape - AMIGA - 720"
  },
  "history": {
   "text": "Code by Haplo, concept and graphics by Andy Johns – a ZX Spectrum game that went to the C64 and then to the Amiga in 2023, with a map almost twice the size. Ooze flips gravity to get past the robot guards. Press S to switch between music and sound effects."
  }
 },
 "am_yoomp": {
  "input": "joystick",
  "kickstart": "aros",
  "model": "ENGINE_DEFAULT",
  "video": {
   "id": "ERRZsqJN1y0",
   "title": "Amiga Yoomp!"
  },
  "history": {
   "text": "zr-games' Amiga version of the C64 and Atari 8-bit Yoomp!: a ball bouncing through textured 3D tubes, 27 levels, two soundtracks by MCH. PAL only – it refuses the NTSC A500 profile this shelf uses for Kickstart 1.3, so it boots on AROS with the engine's default machine instead."
  }
 },
 "am_shift": {
  "input": "joystick",
  "video": {
   "id": "GT0xH4ZsOQw",
   "title": "Commodore Amiga -=Shift=-"
  },
  "history": {
   "text": "Haplo's 2024 conversion of Antony Lavelle's Armor Games puzzle-platformer, made with Andy Johns and MarukPa: black and white trade places at the push of a button. 45 levels on the Amiga, one of them secret. R restarts a level, M toggles music."
  }
 },
 "am_yeet": {
  "input": "joystick",
  "video": {
   "id": "TwIkLO8WODY",
   "title": "Commodore Amiga -=YEET=-"
  },
  "history": {
   "text": "A 2025 rune puzzle by zooperdan, music by mA2E: push runes off the edge of the board until exactly one is left. 50 puzzles, written to run on a stock A500 with 512K and Kickstart 1.3."
  }
 }
};
