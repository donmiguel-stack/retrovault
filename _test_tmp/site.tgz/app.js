(function () {
  // The version shown next to the GitHub icon in the topbar - this is the
  // local build/catalogue version, not a cache-buster like COVER_V/CLIP_V
  // below (those force a re-fetch of assets; this is just a human-readable
  // label for "which copy of the Vault is this"). Bump it by hand whenever
  // a release-worthy batch of changes lands - there's no automatic tie to
  // the individual COVER_V/CLIP_V/script cache-bust numbers, which change
  // far more often than this should.
  var VAULT_VERSION = "1.0.0";
  // Bump when you add or replace anything in covers/ (see renderCard).
  var COVER_V = 45;
  // Bump when you add or re-record anything in clips/ (featured gameplay clips).
  var CLIP_V = 7;

  // Attract-screen palette, same letters as the SELECT GAME splash. Declared
  // up here because render() runs before the code further down this file.
  var ATTRACT_COLORS = ["#4ade80", "#ff6fc9", "#b39bff", "#3bffe9", "#ffffff",
                        "#ffd23b", "#ff4d4d", "#ff9d3b", "#a6e13c", "#5c8dff"];

  var COVER_COLORS = [
    "#5b8def", "#3ba97a", "#c07de0", "#e0865a",
    "#d65a7e", "#8a8f98", "#e0c05a", "#4fb3bf"
  ];

  // Category groups: raw catalogue "category" values collapse into these
  // for filtering/badging, per platform (G7000/G7400+) already handled separately.
  var CATEGORY_GROUPS = [
    { key: "eu",       label: "Videopac (EU)",  color: "#5b8def", match: ["Official Videopac (EU)"] },
    { key: "french",   label: "French dump",    color: "#4fb3bf", match: ["Official Videopac (French)"] },
    { key: "us",       label: "Odyssey2 (US)",  color: "#3ba97a", match: ["Official Odyssey2 (US)"] },
    { key: "imagic",   label: "Imagic",         color: "#e0c05a", match: ["Imagic"] },
    { key: "parker",   label: "Parker Brothers",color: "#d65a7e", match: ["Parker Brothers"] },
    { key: "jopac",    label: "Jopac",          color: "#8a6fe0", match: ["Jopac (French)"] },
    { key: "brazil",   label: "Philips Brazil", color: "#2fb47c", match: ["Philips Brazil"] },
    { key: "pal",      label: "PAL",            color: "#5ac48a", match: ["PAL dumps"] },
    { key: "modified", label: "Modified",       color: "#e0865a", match: ["Modified / fixed"] },
    { key: "rare",     label: "Rare",           color: "#c07de0", match: ["Rare / unreleased", "Utility / unknown"] },
    { key: "homebrew", label: "Homebrew",       color: "#e05a7e", match: ["Homebrew (this project)", "Homebrew (community)"] },
    { key: "c64",      label: "Commodore 64",   color: "#b98a5f", match: ["Commodore 64"] },
    { key: "amiga",    label: "Amiga",          color: "#ff8a3d", match: ["Amiga"] },
    { key: "demoscene",label: "Demoscene",      color: "#9b6bd6", match: ["Demoscene"] },
    { key: "pc",       label: "MS-DOS",         color: "#4a7fd6", match: ["MS-DOS"] }
  ];

  var CATEGORY_LOOKUP = {};
  CATEGORY_GROUPS.forEach(function (grp) {
    grp.match.forEach(function (rawCat) { CATEGORY_LOOKUP[rawCat] = grp; });
  });

  function platformBadge(p) {
    return p === "G7400+" ? "badge-g7400" : p === "C64" ? "badge-c64" : p === "PC" ? "badge-pc" : p === "Amiga" ? "badge-amiga" : "badge-g7000";
  }

  function groupFor(g) {
    return CATEGORY_LOOKUP[g.category] || { key: "other", label: g.category, color: "#8a8f98" };
  }

  // Chip and badge wording comes from i18n.js so it follows the language
  // picker; the English label in CATEGORY_GROUPS is the fallback.
  function catLabel(grp) {
    var k = "cat_" + grp.key, v = window.t(k);
    return (v && v !== k) ? v : grp.label;
  }

  // Several carts appear more than once with the SAME title, platform and
  // category, because more than one dump of them survives - e.g. Neutron Star
  // has a plain 8K image, a full 12K bank-switched image, and a corrected
  // version of that 12K image. The rows were indistinguishable in the grid,
  // so surface the dump type from the tags.
  var VARIANT_LABELS = { "adult": "var_adult", "banked-rom": "var_banked", "alt-dump": "var_alt" };
  function variantFor(g) {
    for (var i = 0; i < g.tags.length; i++) {
      if (VARIANT_LABELS[g.tags[i]]) return window.t(VARIANT_LABELS[g.tags[i]]);
    }
    return null;
  }

  // What a game actually is, from genres.js - filters that combine with the
  // origin filters above, so "G7400 + shooter + two players" is one query.
  var GENRE_ORDER = ["action","platformer","shooter","fighting","maze","sports",
                     "racing","strategy","puzzle","adventure","education","gambling","utility","demo"];
  var PLAYER_ORDER = ["p1","p12","p2"];
  function genreOf(g) { return ((window.GENRE_DATA || {})[g.id] || {}).genre || null; }
  function playersOf(g) { return ((window.GENRE_DATA || {})[g.id] || {}).players || null; }

  function buildFacetChips(el, order, values, labelKey, stateKey, allLabel) {
    var counts = {};
    platformGames().forEach(function (g) {
      var v = values(g); if (v) counts[v] = (counts[v] || 0) + 1;
    });
    var entries = [];
    order.forEach(function (k) {
      if (counts[k]) entries.push({ key: k, label: window.t(labelKey + k), count: counts[k] });
    });
    fillSelect(el, allLabel, entries, state[stateKey]);
  }

  // Shelf order. The catalogue is a numbered series - Videopac 1 through 60 -
  // so that is the order a collector expects, not the alphabet. Entries with
  // no Videopac number (US, Brazilian, Jopac, prototypes, homebrew) follow
  // afterwards, grouped by where they came from.
  var CATEGORY_RANK = {
    eu: 0, french: 1, pal: 2, us: 3, brazil: 4, jopac: 5,
    imagic: 6, parker: 7, modified: 8, rare: 9, homebrew: 10, c64: 11, pc: 12, amiga: 13
  };
  function shelfKey(g) {
    var n = parseInt(g.vpNumber, 10);
    var rank = CATEGORY_RANK[groupFor(g).key];
    return [isNaN(n) ? 1 : 0, isNaN(n) ? 0 : n, rank === undefined ? 12 : rank, g.title.toLowerCase()];
  }
  function bySort(a, b) {
    // C64 and PC titles have no vpNumber, so number-sorting is meaningless
    // there - those shelves always sort A-Z (the dropdown is hidden too,
    // see syncShelfChips).
    var az = state.sort === "az" || state.platform === "C64" || state.platform === "PC" || state.platform === "Amiga";
    if (az) return a.title.toLowerCase() < b.title.toLowerCase() ? -1 : 1;
    var ka = shelfKey(a), kb = shelfKey(b);
    for (var i = 0; i < ka.length; i++) {
      if (ka[i] < kb[i]) return -1;
      if (ka[i] > kb[i]) return 1;
    }
    return 0;
  }

  function hashColor(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return COVER_COLORS[h % COVER_COLORS.length];
  }

  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  function initials(title) {
    var words = title.replace(/[^a-zA-Z0-9 ]/g, "").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return "?";
    if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
    return (words[0][0] + words[1][0]).toUpperCase();
  }

  // ---- Favorites -------------------------------------------------------
  // Stored in localStorage, which lives in the browser profile on disk, so it
  // survives closing the tab, quitting the browser and rebooting. It is per
  // browser and per origin though: favorites saved on http://localhost:8000
  // won't show up in a different browser, and clearing "site data" wipes them.
  // Export/Import below writes them to a small JSON file you can keep or move.
  // NOTE: the app is branded "Retro Vault" now, but every localStorage key
  // keeps its original VideopacVault_ prefix on purpose - renaming the keys
  // would silently orphan saved favorites and settings in every install.
  var FAV_KEY = "VideopacVault_favorites";
  var favorites = {};
  try {
    favorites = JSON.parse(localStorage.getItem(FAV_KEY) || "{}") || {};
  } catch (e) {
    favorites = {};
  }
  function isFav(id) { return !!favorites[id]; }
  function favCount() { return Object.keys(favorites).length; }
  function saveFavs() {
    try {
      localStorage.setItem(FAV_KEY, JSON.stringify(favorites));
    } catch (e) {
      alert("Could not save favorites - your browser is blocking local storage for this page.");
    }
  }
  function toggleFav(id) {
    if (favorites[id]) delete favorites[id];
    else favorites[id] = 1;
    saveFavs();
    updateListChips();
  }

  // ---- Recently played (2026-09-24) -----------------------------------
  // game-page.js writes the id to the front of this list every time START is
  // pressed (newest first, capped at 30). Same localStorage caveats as the
  // favorites above. The chip only appears once something on the current
  // shelf has been played, and that view sorts by when, not by number.
  var RECENT_KEY = "VideopacVault_recent";
  var recentIdx = Object.create(null);
  function loadRecent() {
    recentIdx = Object.create(null);
    var a = [];
    try { a = JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); } catch (e) { a = []; }
    if (!Array.isArray(a)) a = [];
    a.forEach(function (id, i) { if (!(id in recentIdx)) recentIdx[id] = i; });
  }
  loadRecent();
  function isRecent(id) { return id in recentIdx; }
  function byRecent(a, b) { return recentIdx[a.id] - recentIdx[b.id]; }

  function hasPackaging(id) {
    return !!(window.PACKAGING_DATA && window.PACKAGING_DATA[id]);
  }

  var SORT_KEY = "VideopacVault_sort";
  var SHELF_KEY = "VideopacVault_shelf";
  var savedShelf = localStorage.getItem(SHELF_KEY);
  // G7000/G7400+ used to be their own standalone shelves; they're now a
  // console filter living under Category, on the Videopac shelf. Anyone whose
  // browser still has one of those old values saved lands on Videopac with
  // that console pre-selected in the Category dropdown, instead of losing
  // the setting outright.
  var savedConsole = null;
  if (savedShelf === "G7000" || savedShelf === "G7400+") {
    savedConsole = savedShelf;
    savedShelf = "videopac";
  }
  if (["videopac", "C64", "PC", "Amiga"].indexOf(savedShelf) === -1) savedShelf = "videopac";
  // ?shelf=videopac|c64|pc deep-links a shelf, so retrovault.world can point
  // straight at the shelf a screenshot shows instead of always landing on
  // whichever one the visitor last had open (2026-09-08). Case-insensitive
  // and aliased, since the value that reads naturally in a URL ("c64") is not
  // the value the state uses ("C64"); anything unrecognised is ignored and
  // the saved shelf wins, so a stray parameter can never blank the page.
  try {
    var SHELF_ALIAS = { videopac: "videopac", vp: "videopac", odyssey: "videopac",
                        c64: "C64", commodore: "C64", pc: "PC", dos: "PC", msdos: "PC",
                        amiga: "Amiga" };
    var wanted = (new URLSearchParams(window.location.search).get("shelf") || "").toLowerCase();
    if (SHELF_ALIAS[wanted]) savedShelf = SHELF_ALIAS[wanted];
  } catch (e) {}
  localStorage.setItem(SHELF_KEY, savedShelf);
  var state = {
    games: [], platform: savedShelf, category: savedConsole || "all", query: "", list: "all",
    sort: localStorage.getItem(SORT_KEY) || "number",
    genre: "all", players: "all"
  };

  var grid = document.getElementById("grid");
  var emptyState = document.getElementById("emptyState");
  var resultCount = document.getElementById("resultCount");
  var categorySel = document.getElementById("categorySel");
  var genreSel = document.getElementById("genreSel");
  var playerSel = document.getElementById("playerSel");
  var sortSel = document.getElementById("sortSel");
  var clearBtn = document.getElementById("clearFilters");
  var searchInput = document.getElementById("search");

  if (window.GAMES_DATA && window.GAMES_DATA.games) {
    state.games = window.GAMES_DATA.games;
    buildCategoryChips(platformGames());
    buildFacets();
    updateListChips();
    applyLang();
    buildShowcase();
    syncShelfChips();
    render();
  } else {
    grid.innerHTML = '<p style="padding:24px;color:#e0865a;">games.js did not load - make sure games.js sits next to index.html and is included before app.js.</p>';
  }

  // The games on the active shelf. Counts, placeholders and filter options
  // are all computed from this rather than the whole catalogue, so the
  // Videopac shelf says 213 games and the C64/PC shelves say their own number -
  // the shelves never mix.
  function platformGames() {
    return state.games.filter(function (g) {
      if (state.platform === "all") return true;
      if (state.platform === "videopac") return g.platform !== "C64" && g.platform !== "PC" && g.platform !== "Amiga";
      return g.platform === state.platform;
    });
  }

  function syncShelfChips() {
    document.querySelectorAll("#platformChips .chip").forEach(function (c) {
      c.classList.toggle("active", c.dataset.platform === state.platform);
    });
    // The featured panels are shelf-specific and always built, just shown or
    // hidden per active shelf: the Videopac one on every shelf except C64/PC,
    // the C64 one only on the C64 shelf, the PC one only on the PC shelf.
    var sc = document.getElementById("showcase");
    if (sc) sc.hidden = state.platform === "C64" || state.platform === "PC" || state.platform === "Amiga";
    var c64sc = document.getElementById("c64showcase");
    if (c64sc) c64sc.hidden = state.platform !== "C64";
    var pcsc = document.getElementById("pcshowcase");
    if (pcsc) pcsc.hidden = state.platform !== "PC";
    var amsc = document.getElementById("amshowcase");
    if (amsc) amsc.hidden = state.platform !== "Amiga";
    // Sorting by number and the packaging filter only mean something on the
    // Videopac shelf - vpNumbers and boxed boards/overlays/workbooks don't
    // exist for C64 or PC titles - so both controls disappear there. The
    // stored sort choice is left alone (bySort falls back to A-Z on these
    // shelves, see below) so it comes back when you return to Videopac.
    var nonVp = state.platform === "C64" || state.platform === "PC" || state.platform === "Amiga";
    if (sortSel) sortSel.hidden = nonVp;
    var packBtn = document.getElementById("packChip");
    if (packBtn) {
      packBtn.hidden = nonVp;
      if (nonVp && state.list === "pack") {
        state.list = "all";
        updateListChips();
      }
    }

    // and the news tape follows whichever showcase is now visible
    mountNewsTape();
  }

  function fillSelect(sel, allLabel, entries, current) {
    var html = '<option value="all">' + allLabel + '</option>';
    entries.forEach(function (e) {
      html += '<option value="' + e.key + '">' + e.label + ' (' + e.count + ')</option>';
    });
    sel.innerHTML = html;
    sel.value = current;
    sel.classList.toggle("on", current !== "all");
  }

  // G7000 and G7400+ aren't their own shelf any more - they're a console
  // filter that only makes sense on the Videopac shelf, so they show up as
  // two extra entries at the top of the Category dropdown instead of as
  // standalone chips. Reuses state.category (their keys, "G7000"/"G7400+",
  // never collide with a CATEGORY_GROUPS key), so matches() below treats them
  // as just another category value.
  function buildCategoryChips(games) {
    // Counts mirror what selecting each category actually shows: shelf
    // primaries always, plus the folded alternates that selecting that
    // category reveals (their own category differs from their primary's -
    // see the reveal rule in matches()). Same-category alternates (EU
    // alt/hack dumps) count nowhere, so the numbers never promise doubles.
    function findGame(id) {
      var all = (window.GAMES_DATA && window.GAMES_DATA.games) || [];
      for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i];
      return null;
    }
    var counts = {}, visibleTotal = 0;
    games.forEach(function (g) {
      var key = groupFor(g).key;
      if (window.VAULT_ALT && window.VAULT_ALT.isAlternate(g.id)) {
        var pg = findGame(window.VAULT_ALT.primaryOf(g.id));
        if (!pg || groupFor(pg).key !== key) counts[key] = (counts[key] || 0) + 1;
      } else {
        counts[key] = (counts[key] || 0) + 1;
        visibleTotal++;
      }
    });
    var entries = [];
    if (state.platform === "videopac") {
      var consoleCounts = { "G7000": 0, "G7400+": 0 };
      games.forEach(function (g) {
        if (consoleCounts[g.platform] === undefined) return;
        if (window.VAULT_ALT && window.VAULT_ALT.isAlternate(g.id)) return;
        consoleCounts[g.platform]++;
      });
      ["G7000", "G7400+"].forEach(function (p) {
        if (consoleCounts[p]) entries.push({ key: p, label: p, count: consoleCounts[p] });
      });
    }
    CATEGORY_GROUPS.forEach(function (grp) {
      if (counts[grp.key]) entries.push({ key: grp.key, label: catLabel(grp), count: counts[grp.key] });
    });
    // "Banked ROM" is a tag, not a catalogue category, so it doesn't come from
    // CATEGORY_GROUPS - it cuts across EU/US origins to surface bank-switched
    // dumps specifically. Counts every tagged game, including ones normally
    // folded away as an alternate (e.g. Neutron Star's banked dump under its
    // plain one) - selecting this filter reveals them, see matches() below.
    var bankedCount = 0;
    games.forEach(function (g) {
      if (g.tags && g.tags.indexOf("banked-rom") !== -1) bankedCount++;
    });
    if (bankedCount) entries.push({ key: "banked-rom", label: window.t("cat_banked"), count: bankedCount });
    // "Adult (18+)" - same idea as Banked ROM: a tag cutting across shelves,
    // for games built around nudity (Samantha Fox Strip Poker). START on
    // those asks for an 18+ confirmation first, see game-page.js.
    var adultCount = 0;
    games.forEach(function (g) {
      if (g.tags && g.tags.indexOf("adult") !== -1) adultCount++;
    });
    if (adultCount) entries.push({ key: "adult", label: window.t("cat_adult"), count: adultCount });
    fillSelect(categorySel, window.t("allCats") + " (" + visibleTotal + ")", entries, state.category);
  }

  function matches(g) {
    if (state.list === "fav" && !isFav(g.id)) return false;
    if (state.list === "recent" && !isRecent(g.id)) return false;
    if (state.list === "pack" && !hasPackaging(g.id)) return false;
    // One card per game: alternate dumps (French, mods, alt/hack revisions,
    // the non-chosen G7000/G7400+ variant) are listed on their primary's
    // game page instead of the shelf - see alternates.js. Favorites still
    // surface an alternate you starred before this change.
    if (window.VAULT_ALT && window.VAULT_ALT.isAlternate(g.id) && state.list !== "fav" && state.list !== "recent") {
      // Picking a category in the dropdown means "show me those dumps", so an
      // alternate comes back when its own category is the one selected AND
      // differs from its primary's (French dumps, PAL conversions, mods,
      // Brazil twins). Same-category alternates (EU alt/hack dumps, homebrew
      // demo builds) stay folded so the category view shows no doubles.
      //
      // Two more escapes: the "Banked ROM" filter reveals any tagged
      // alternate regardless of category (Neutron Star's banked dump shares
      // its plain dump's EU category, so the rule above alone would never
      // reveal it). And an active search reveals a matching alternate by
      // name even with no filter set - Red Baron is a real, differently
      // named prototype folded onto Air Battle's page; it should still turn
      // up if someone searches "red baron", even though it stays off the
      // shelf grid by default. It still has to pass the query match below,
      // so an unrelated search doesn't un-fold it.
      var revealed = !!state.query ||
        (state.category === "banked-rom" && g.tags && g.tags.indexOf("banked-rom") !== -1);
      if (!revealed && state.category !== "all" && state.category !== "G7000" && state.category !== "G7400+" &&
          state.category !== "banked-rom" && state.category !== "adult") {
        if (groupFor(g).key === state.category) {
          var altPrimary = null, altPid = window.VAULT_ALT.primaryOf(g.id);
          var allGames = (window.GAMES_DATA && window.GAMES_DATA.games) || [];
          for (var api = 0; api < allGames.length; api++) {
            if (allGames[api].id === altPid) { altPrimary = allGames[api]; break; }
          }
          if (!altPrimary || groupFor(altPrimary).key !== state.category) revealed = true;
        }
      }
      if (!revealed) return false;
    }
    if (state.platform === "videopac") { if (g.platform === "C64" || g.platform === "PC" || g.platform === "Amiga") return false; }
    else if (state.platform !== "all" && g.platform !== state.platform) return false;
    if (state.genre !== "all" && genreOf(g) !== state.genre) return false;
    if (state.players !== "all" && playersOf(g) !== state.players) return false;
    if (state.category !== "all") {
      if (state.category === "G7000" || state.category === "G7400+") {
        if (g.platform !== state.category) return false;
      } else if (state.category === "banked-rom") {
        if (!g.tags || g.tags.indexOf("banked-rom") === -1) return false;
      } else if (state.category === "adult") {
        if (!g.tags || g.tags.indexOf("adult") === -1) return false;
      } else if (groupFor(g).key !== state.category) return false;
    }
    if (state.query) {
      var q = state.query.toLowerCase();
      // search the regional names too, so "Thunderball" finds Flipper and
      // "Bacara" finds Blackjack
      var hay = g.title + " " + g.filename;
      var br = (window.BRAZIL_DATA || {})[g.id], us = (window.USA_DATA || {})[g.id];
      if (br) hay += " " + br.title + " " + br.num;
      if (us) hay += " " + us.title + " " + us.num;
      if (hay.toLowerCase().indexOf(q) === -1) return false;
    }
    return true;
  }

  // The community panel sits partway down the library rather than at the top -
  // it reads as a signpost you come across, not a banner you scroll past.
  // An empty advert slot doesn't need artwork - it gets the console's own
  // attract-screen treatment instead: rainbow letters bouncing off the edges,
  // the way the Videopac idled when nobody was playing.
  function attractBanner(text) {
    var wrap = document.createElement("span");
    wrap.className = "attract";
    var word = document.createElement("span");
    word.className = "attract-word";
    var n = 0;
    text.split("").forEach(function (ch) {
      if (ch === " ") {
        word.appendChild(Object.assign(document.createElement("span"),
          { className: "attract-space" }));
      } else {
        var el = document.createElement("span");
        el.className = "attract-letter";
        el.textContent = ch;
        el.style.color = ATTRACT_COLORS[n % ATTRACT_COLORS.length];
        word.appendChild(el);
        n++;
      }
    });
    wrap.appendChild(word);

    // DVD-logo drift. Starts once the element has a measurable size.
    var x = 0, y = 0, dx = 0.7, dy = 0.45, shift = 0, raf = null;
    function step() {
      var bw = wrap.clientWidth, bh = wrap.clientHeight;
      var ww = word.offsetWidth, wh = word.offsetHeight;
      if (bw && ww) {
        x += dx; y += dy;
        var maxX = bw - ww, maxY = bh - wh;
        if (x <= 0 || x >= maxX) { dx = -dx; x = Math.max(0, Math.min(x, maxX)); recolour(); }
        if (y <= 0 || y >= maxY) { dy = -dy; y = Math.max(0, Math.min(y, maxY)); recolour(); }
        word.style.transform = "translate(" + x + "px," + y + "px)";
      }
      raf = requestAnimationFrame(step);
    }
    function recolour() {
      shift++;
      word.querySelectorAll(".attract-letter").forEach(function (el, i) {
        el.style.color = ATTRACT_COLORS[(i + shift) % ATTRACT_COLORS.length];
      });
    }
    raf = requestAnimationFrame(step);
    // ...and pause it when scrolled out of view, so it isn't burning a core
    // in the background. Started above rather than here: the observer's first
    // callback doesn't arrive until the element is in the document.
    if (window.IntersectionObserver) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting && !raf) raf = requestAnimationFrame(step);
          else if (!e.isIntersecting && raf) { cancelAnimationFrame(raf); raf = null; }
        });
      }).observe(wrap);
    }
    return wrap;
  }

  // The C64-style advert banner lives in c64ad.js (shared with game.html):
  // window.buildC64Ad(sponsor) returns the animated banner element.
  function c64AdBlock() {
    var sp = ((window.FEATURED_DATA || {}).sponsors || [])[0] || null;
    var strip = document.createElement("div"); strip.className = "sponsor-strip c64-ad-strip";
    var a = document.createElement("a"); a.className = "c64ad-link";
    a.href = (sp && sp.url) || "#"; a.target = "_blank"; a.rel = "noopener sponsored";
    a.appendChild(window.buildC64Ad(sp));
    var tag = document.createElement("span"); tag.className = "sponsor-tag"; tag.textContent = window.t("sponsored");
    a.appendChild(tag);
    strip.appendChild(a);
    return strip;
  }

  // The PC-style advert banner lives in pcad.js (shared with game.html):
  // window.buildPcAd(sponsor) returns the animated banner element.
  function pcAdBlock() {
    var sp = ((window.FEATURED_DATA || {}).sponsors || [])[0] || null;
    var strip = document.createElement("div"); strip.className = "sponsor-strip pc-ad-strip";
    var a = document.createElement("a"); a.className = "pcad-link";
    a.href = (sp && sp.url) || "#"; a.target = "_blank"; a.rel = "noopener sponsored";
    a.appendChild(window.buildPcAd(sp));
    var tag = document.createElement("span"); tag.className = "sponsor-tag"; tag.textContent = window.t("sponsored");
    a.appendChild(tag);
    strip.appendChild(a);
    return strip;
  }

  // The Amiga-style advert banner lives in amigaad.js:
  // window.buildAmigaAd(sponsor) returns the animated banner element. Same
  // shape as the two above; the sponsor object is shared across all shelves,
  // so one entry in FEATURED_DATA.sponsors feeds every banner.
  function amAdBlock() {
    var sp = ((window.FEATURED_DATA || {}).sponsors || [])[0] || null;
    if (!window.buildAmigaAd) return null;
    var strip = document.createElement("div"); strip.className = "sponsor-strip amiga-ad-strip";
    var a = document.createElement("a"); a.className = "amigaad-link";
    a.href = (sp && sp.url) || "#"; a.target = "_blank"; a.rel = "noopener sponsored";
    a.appendChild(window.buildAmigaAd(sp));
    var tag = document.createElement("span"); tag.className = "sponsor-tag"; tag.textContent = window.t("sponsored");
    a.appendChild(tag);
    strip.appendChild(a);
    return strip;
  }

  function sponsorBlock() {
    var list = (window.FEATURED_DATA || {}).sponsors || [];
    var tpl = document.getElementById("sponsorTpl");
    if (!list.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    list.forEach(function (sp) {
      var a = document.createElement("a");
      a.className = "sponsor" + (sp.image ? "" : " sponsor-empty");
      a.href = sp.url;
      a.target = "_blank";
      a.rel = "noopener sponsored";
      if (sp.image) {
        var img = document.createElement("img");
        img.src = "assets/" + sp.image;
        img.alt = "";
        a.appendChild(img);
      } else {
        a.appendChild(attractBanner(window.tx(sp.attract) || "ADVERTISE HERE"));
      }
      var tag = document.createElement("span");
      tag.className = "sponsor-tag";
      tag.textContent = window.t("sponsored");
      a.appendChild(tag);
      var sr = document.createElement("span");
      sr.className = "sponsor-sr";
      sr.textContent = sp.name + " — " + window.tx(sp.text);
      a.appendChild(sr);
      node.appendChild(a);
    });
    return node;
  }

  // ---- The featured layout, used twice ---------------------------------
  // Once at the top of the page, once for the homebrew panel inside the grid.
  // Cover on the left, blurb in the middle, a screenshot on the right, and a
  // column of thumbnails that also rotate on their own.
  function gameById(id) {
    return state.games.filter(function (g) { return g.id === id; })[0];
  }

  // "shot" takes a filename or a list of them; two are shown side by side.
  //
  // They live in covers/ under a shot_ prefix rather than in a folder of their
  // own, and that is deliberate. The update endpoint only writes to a fixed
  // whitelist of folders, and that whitelist lives in serve.py - which the
  // updater deliberately never overwrites, since a remote list should not be
  // able to widen its own permissions. So anything in a new folder can never
  // reach an existing install. Put new files where the updater is already
  // allowed to write.
  function shotMarkup(shot) {
    if (!shot) return "";
    var list = Array.isArray(shot) ? shot : [shot];
    var imgs = list.map(function (s) {
      return '<img class="feature-shot" src="covers/shot_' + s + '" alt="">';
    }).join("");
    return list.length > 1 ? '<div class="feature-shots">' + imgs + '</div>' : imgs;
  }

  // The right-hand slot prefers a locally-recorded gameplay clip over the
  // static shot_ screenshot, same three-layer idea as the C64 panels below
  // (clip -> YouTube -> still image) - but Videopac's still image is a
  // curated shot_ screenshot (already good, deliberately picked per game),
  // not generic cover art, so that's what the final fallback restores rather
  // than a cover. Both callers of featureRotator() (the top-of-page panel
  // and the Videopac homebrew panel) already use an <a class="feature-main">
  // wrapper, so - unlike the C64 split - one shared implementation covers
  // both without any nested-anchor problem.
  function videopacClipFallback(box, shotVal) {
    var vid = box.getAttribute("data-vid");
    if (vid) {
      box.innerHTML = '<iframe src="' + ytEmbed(vid) + '" title="" loading="lazy" ' +
        'frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" ' +
        'allowfullscreen></iframe>';
    } else {
      box.outerHTML = shotMarkup(shotVal);
    }
  }

  // Returns a function that stops the rotation - the homebrew panel is thrown
  // away and rebuilt on every resize, and its old timer has to go with it.
  function featureRotator(main, list, picks) {
    var at = 0, timer = null;

    function videoSlot(g, pick) {
      var gp = (window.GAMEPAGES_DATA || {})[g.id] || {};
      var vid = gp.video && gp.video.id ? gp.video.id : "";
      // clipId lets a featured pick play a different game's recorded clip
      // than the one it links to - see the comment on "clipId" in
      // featured.js. The YouTube fallback (data-vid) still comes from this
      // pick's own game id, so a clip load failure recovers to the correct
      // embed rather than the substitute game's.
      var clipId = (pick && pick.clipId) || g.id;
      return '<div class="feature-video" data-gid="' + g.id + '" data-vid="' + vid + '">' +
        '<video class="feature-clip" src="clips/clip_' + clipId + '.mp4?v=' + CLIP_V + '" ' +
        'autoplay muted loop playsinline preload="auto"></video></div>';
    }

    function wireClip(shotVal) {
      var box = main.querySelector(".feature-video");
      if (!box) return;
      var v = box.querySelector("video");
      if (!v) return;
      v.addEventListener("error", function () { videopacClipFallback(box, shotVal); }, { once: true });
      var p = v.play && v.play();
      if (p && p.catch) p.catch(function () {});
    }

    function show(n) {
      at = (n + picks.length) % picks.length;
      var pick = picks[at], g = gameById(pick.id);
      var gen = (window.GENRE_DATA || {})[g.id] || {};
      main.href = "game.html?id=" + encodeURIComponent(g.id);
      var homebrew = groupFor(g).key === "homebrew";
      main.innerHTML =
        '<span class="feature-cover-wrap">' +
        '<img class="feature-cover" src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
        'onerror="this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">' +
        (homebrew ? '<span class="cover-ribbon">' + window.t("cat_homebrew") + '</span>' : '') +
        '</span>' +
        '<div class="feature-copy">' +
        '<h3>' + g.title + '</h3>' +
        '<p class="feature-blurb">' + window.tx(pick.blurb) + '</p>' +
        '<div class="feature-meta">' +
        '<span class="badge ' + platformBadge(g.platform) + '">' + g.platform + '</span>' +
        (gen.genre ? '<span class="badge badge-cat">' + window.t("g_" + gen.genre) + '</span>' : '') +
        (gen.players ? '<span class="badge badge-cat">' + window.t("p_" + gen.players) + '</span>' : '') +
        '</div></div>' + videoSlot(g, pick);
      wireClip(pick.shot);
      list.querySelectorAll(".feature-thumb").forEach(function (b, n2) {
        b.classList.toggle("on", n2 === at);
      });
    }

    list.innerHTML = picks.map(function (p, n) {
      var g = gameById(p.id);
      // same .png-then-.jpg fallback as the big cover, or a jpg-only cover
      // (Terrahawks, for one) shows as a broken thumbnail
      return '<button class="feature-thumb" data-i="' + n + '">' +
             '<img src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
             'onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">' +
             '<span>' + g.title + '</span></button>';
    }).join("");
    list.querySelectorAll(".feature-thumb").forEach(function (b) {
      b.addEventListener("click", function () {
        show(parseInt(this.dataset.i, 10));
        clearInterval(timer);            // stop rotating once someone chooses
        timer = null;
      });
    });

    show(0);
    timer = setInterval(function () { show(at + 1); }, 7000);
    return function () { if (timer) clearInterval(timer); timer = null; };
  }

  // The C64 featured panel is the same idea, but the right-hand slot plays the
  // game's own gameplay clip instead of a still - muted, looping - so the
  // screenshot actually moves. It rotates more slowly than the Videopac panel
  // (14s) so a clip has time to actually play before the next one loads.
  //
  // Three layers, best first, each falling back to the next automatically:
  //   1. a locally-recorded clip at clips/clip_<id>.mp4  (instant, offline,
  //      no YouTube chrome) - preferred whenever the file is present;
  //   2. the game's YouTube gameplay embed (gamepages.js video id) if there
  //      is no local clip but the machine is online;
  //   3. the cover, if there's neither.
  // The <video> element's own error event does the 1->2/3 hop, so dropping a
  // new clip into clips/ upgrades that game with no code or config change.
  function ytEmbed(vid) {
    // youtube-nocookie + muted is what makes autoplay/loop allowed.
    return "https://www.youtube-nocookie.com/embed/" + vid +
      "?autoplay=1&mute=1&loop=1&playlist=" + vid +
      "&controls=0&modestbranding=1&playsinline=1&rel=0&disablekb=1";
  }

  // When a local clip is missing, its <video> fires "error"; swap the slot for
  // the YouTube embed, or the cover if the game has no video id either.
  function c64ClipFallback(box) {
    var vid = box.getAttribute("data-vid");
    var gid = box.getAttribute("data-gid");
    var href = box.getAttribute("data-href");
    if (vid) {
      box.innerHTML = '<iframe src="' + ytEmbed(vid) + '" title="" loading="lazy" ' +
        'frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" ' +
        'allowfullscreen></iframe>';
    } else {
      box.classList.add("feature-video-fallback");
      box.innerHTML = '<a href="' + href + '"><img src="covers/' + gid + '.png?v=' + COVER_V +
        '" alt="" onerror="this.onerror=null;this.src=\'covers/' + gid + '.jpg?v=' + COVER_V + '\'"></a>';
    }
  }

  function c64FeatureRotator(main, list, picks) {
    var at = 0, timer = null;

    function videoSlot(g, href) {
      var gp = (window.GAMEPAGES_DATA || {})[g.id] || {};
      var vid = gp.video && gp.video.id ? gp.video.id : "";
      // Always reach for the local clip first; data-* carries what the error
      // handler needs to fall back to.
      return '<div class="feature-video" data-gid="' + g.id + '" data-vid="' + vid +
        '" data-href="' + href.replace(/"/g, "&quot;") + '">' +
        '<video class="feature-clip" src="clips/clip_' + g.id + '.mp4?v=' + CLIP_V + '" ' +
        'autoplay muted loop playsinline preload="auto"></video></div>';
    }

    // Wire the freshly-rendered clip: kick playback (autoplay policies) and
    // arm the missing-file fallback.
    function wireClip() {
      var box = main.querySelector(".feature-video");
      if (!box) return;
      var v = box.querySelector("video");
      if (!v) return;
      v.addEventListener("error", function () { c64ClipFallback(box); }, { once: true });
      var p = v.play && v.play();
      if (p && p.catch) p.catch(function () {});
    }

    function show(n) {
      at = (n + picks.length) % picks.length;
      var pick = picks[at], g = gameById(pick.id);
      var gen = (window.GENRE_DATA || {})[g.id] || {};
      var href = "game.html?id=" + encodeURIComponent(g.id);
      main.innerHTML =
        '<a class="feature-cover-wrap" href="' + href + '">' +
        '<img class="feature-cover" src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
        'onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'"></a>' +
        '<div class="feature-copy">' +
        '<h3><a href="' + href + '">' + g.title + '</a></h3>' +
        '<p class="feature-blurb">' + window.tx(pick.blurb) + '</p>' +
        '<div class="feature-meta">' +
        '<span class="badge ' + platformBadge(g.platform) + '">' + g.platform + '</span>' +
        (gen.genre ? '<span class="badge badge-cat">' + window.t("g_" + gen.genre) + '</span>' : '') +
        (gen.players ? '<span class="badge badge-cat">' + window.t("p_" + gen.players) + '</span>' : '') +
        '</div></div>' + videoSlot(g, href);
      wireClip();
      list.querySelectorAll(".feature-thumb").forEach(function (b, n2) {
        b.classList.toggle("on", n2 === at);
      });
    }

    list.innerHTML = picks.map(function (p, n) {
      var g = gameById(p.id);
      return '<button class="feature-thumb" data-i="' + n + '">' +
             '<img src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
             'onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">' +
             '<span>' + g.title + '</span></button>';
    }).join("");
    list.querySelectorAll(".feature-thumb").forEach(function (b) {
      b.addEventListener("click", function () {
        show(parseInt(this.dataset.i, 10));
        clearInterval(timer);            // stop rotating once someone chooses
        timer = null;
      });
    });

    show(0);
    timer = setInterval(function () { show(at + 1); }, 10000);
    return function () { if (timer) clearInterval(timer); timer = null; };
  }

  // ---- News tape ---------------------------------------------------------
  // A one-line ticker running along the top of the homebrew panel, announcing
  // new releases. Deliberately not a popup: window.open() is eaten by every
  // blocker made this century, and a modal over a game shelf is exactly what
  // Google counts as an intrusive interstitial on mobile. This sits in the
  // page flow and costs about thirty pixels.
  //
  // Content lives in news.js. Dismissal is remembered per visitor in
  // localStorage, keyed on WHICH items are showing, so dismissing today's
  // news does not hide the next release's.
  // A function, not a var: the first render runs while this file is still
  // being evaluated, so a top-level var declared this far down is still
  // undefined when the homebrew panel is built the first time.
  function newsSeenKey() { return "VideopacVault_newsSeen"; }

  function ntEsc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ---- Videopac character set ------------------------------------------
  // The news tape is drawn the way cart A, Keyboard Creations / Newscaster,
  // draws its message line: the Intel 8244's own built-in characters, white
  // on Videopac blue, upper case only, widely spaced, stepping along a
  // Videopac pixel at a time. The bitmaps are the 8244's character ROM (the
  // same table O2EM draws from), codes 00-2F; the ROM order is the console
  // keyboard's, not ASCII. Functions rather than top-level vars - see
  // newsSeenKey() below for why.
  function vpCset() {
    if (vpCset.d) return vpCset.d;
    var hex = "7CC6C6C6C6C67C001838181818183C003C660C1830607E007CC6063C06C67C00CCCCCCFE0C0C0C00FEC0C07C06C67C007CC6C0FCC6C67C00FE060C183060C0007CC6C67CC6C67C007CC6C67E06C67C000018180018180000187E587E1A7E180000000000000000003C660C1818001800C0C0C0C0C0C0FE00FCC6C6FCC0C0C0000018187E18180000C6C6C6D6FEEEC600FEC0C0F8C0C0FE00FCC6C6FCD8CCC6007E18181818181800C6C6C6C6C6C67C003C18181818183C007CC6C6C6C6C67C007CC6C6C6DECC76007CC6C07C06C67C00FCC6C6C6C6C6FC00FEC0C0F8C0C0C0007CC6C0C0CEC67E00C6C6C6FEC6C6C6000606060606C67C00C6CCD8F0D8CCC600386CC6C6FEC6C6007E060C1830607E00C6C66C386CC6C6007CC6C0C0C0C67C00C6C6C6C6C66C3800FCC6C6FCC6C6FC00C6EEFED6C6C6C60000000000003838000000007E0000000000663C183C6600000018007E0018000000007C007C0000006666663C18181800C6E6F6FEDECEC60003060C183060C000FFFFFFFFFFFFFF00", order = "0123456789:$ ?LP+WERTUIOQSDFGHJKAZXCVBM.-×÷=YN/█";
    var d = { rows: {}, ok: {} };
    for (var i = 0; i < order.length; i++) {
      var r = [];
      for (var y = 0; y < 7; y++) r.push(parseInt(hex.substr(i * 16 + y * 2, 2), 16));
      d.rows[order.charAt(i)] = r;
    }
    return (vpCset.d = d);
  }

  // Fold text onto what the 8244 can show: no lower case, no accents, and a
  // handful of punctuation marks swapped for the nearest thing it has.
  // Returns null when something can't be folded (kana), so the caller can
  // fall back to an ordinary font for that item.
  function vpFold(s) {
    var rows = vpCset().rows;
    s = String(s).normalize ? String(s).normalize("NFD").replace(/[̀-ͯ]/g, "") : String(s);
    s = s.replace(/ß/g, "ss").toUpperCase()
         .replace(/[–—‒]/g, "-").replace(/[,!]/g, ".").replace(/;/g, ":")
         .replace(/&/g, "+").replace(/[…]/g, "...")
         .replace(/['’‘"“”()\[\]]/g, " ")
         .replace(/\s+/g, " ").trim();
    for (var i = 0; i < s.length; i++) if (!rows[s.charAt(i)]) return null;
    return s;
  }

  // Draw folded text as a crisp 1-bit mask, one 8244 dot = VP_DOT css px,
  // rendered at the device's pixel ratio so it stays sharp on a Retina
  // screen. The mask is painted with background-color, so CSS keeps control
  // of the colour (hover, the red label) - no canvas redraws for a hover.
  function vpMask(s, pitch) {
    var VP_DOT = 2, rows = vpCset().rows;
    pitch = pitch || 10;                       // dots per character: 8 + gap
    var dpr = Math.min(3, Math.max(1, Math.ceil(window.devicePixelRatio || 1)));
    var wDots = Math.max(1, s.length * pitch - (pitch - 8)), hDots = 7;
    var c = document.createElement("canvas");
    var k = VP_DOT * dpr;
    c.width = wDots * k; c.height = hDots * k;
    var g = c.getContext("2d");
    g.fillStyle = "#000";
    for (var i = 0; i < s.length; i++) {
      var r = rows[s.charAt(i)];
      for (var y = 0; y < 7; y++)
        for (var x = 0; x < 8; x++)
          if ((r[y] >> (7 - x)) & 1) g.fillRect((i * pitch + x) * k, y * k, k, k);
    }
    return { url: c.toDataURL("image/png"), w: wDots * VP_DOT, h: hDots * VP_DOT };
  }

  // Markup for one bit of tape text: the 8244 rendering when the text folds,
  // with the real text alongside for screen readers and search engines;
  // the pixel-font stack otherwise.
  function vpText(s, cls, pitch) {
    var f = vpFold(s);
    if (f === null || !document.createElement("canvas").getContext)
      return '<span class="' + cls + ' nt-txt">' + ntEsc(s) + '</span>';
    var m = vpMask(f, pitch);
    var mask = "url(" + m.url + ")";
    return '<span class="' + cls + ' nt-vp" aria-hidden="true" style="width:' + m.w +
      'px;height:' + m.h + 'px;-webkit-mask-image:' + mask + ';mask-image:' + mask +
      '"></span><span class="nt-sr">' + ntEsc(s) + '</span>';
  }

  // Items still young enough to be news. An item with no date, or an
  // unparseable one, never ages out - a deliberate escape hatch for a
  // standing notice.
  function newsItems() {
    var d = window.NEWS_DATA || {};
    var items = (d.items || []).filter(function (it) { return it && it.text; });
    var maxAge = typeof d.maxAgeDays === "number" ? d.maxAgeDays : 60;
    if (maxAge > 0) {
      var cutoff = Date.now() - maxAge * 86400000;
      items = items.filter(function (it) {
        var t = it.date ? Date.parse(it.date) : NaN;
        return isNaN(t) || t >= cutoff;
      });
    }
    return items;
  }

  // What a dismissal is remembered against: the version string plus the ids
  // on the tape. Add an item and the signature changes, so the tape comes
  // back for everyone - which is the whole point of the mechanism.
  function newsSignature(items) {
    return ((window.NEWS_DATA || {}).version || "1") + ":" +
      items.map(function (it) { return it.id || it.date || ""; }).join("|");
  }

  function newsTape() {
    var items = newsItems();
    if (!items.length) return null;
    var sig = newsSignature(items);
    try { if (localStorage.getItem(newsSeenKey()) === sig) return null; } catch (e) {}

    var reduce = window.matchMedia &&
                 window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Each run ends with its own separator, so two runs back to back read as
    // one continuous tape and the loop point is invisible.
    var runHtml = items.map(function (it) {
      var txt = vpText(window.tx(it.text), "nt-ink");
      var body = it.href
        ? '<a class="nt-item" href="' + ntEsc(it.href) + '">' + txt + '</a>'
        : '<span class="nt-item">' + txt + '</span>';
      // the separator is the 8244's solid block - Newscaster's cursor
      return body + '<span class="nt-sep" aria-hidden="true">' + vpText("\u2588", "nt-ink") + '</span>';
    }).join("");

    var wrap = document.createElement("div");
    wrap.className = "news-tape" + (reduce ? " nt-still" : "");
    wrap.innerHTML =
      '<span class="nt-label">' + vpText(window.t("newsLabel"), "nt-ink", 9) + '</span>' +
      '<div class="nt-window"><div class="nt-track">' +
        '<div class="nt-run">' + runHtml + '</div>' +
      '</div></div>' +
      '<button class="nt-close" type="button" aria-label="' +
        ntEsc(window.t("newsDismiss")) + '" title="' +
        ntEsc(window.t("newsDismiss")) + '">' + vpText("\u00d7", "nt-ink") + '</button>';

    var track = wrap.querySelector(".nt-track");
    var run = wrap.querySelector(".nt-run");

    // Measured, not guessed: the run is cloned until the strip is at least
    // twice the window's width (so a single short item still fills it), the
    // scroll distance is exactly one run, and the duration follows from
    // news.js's pixels-per-second so long and short tapes read at one speed.
    var tries = 0;
    function size() {
      if (reduce) return;
      var runW = run.scrollWidth, winW = wrap.clientWidth;
      if (!runW || !winW) {                       // not laid out yet
        if (++tries < 12) requestAnimationFrame(size);
        return;
      }
      while (track.children.length > 1) track.removeChild(track.lastChild);
      var copies = Math.max(2, Math.ceil((winW * 2) / runW));
      for (var i = 1; i < copies; i++) {
        var dup = run.cloneNode(true);
        dup.setAttribute("aria-hidden", "true");
        track.appendChild(dup);
      }
      var speed = (window.NEWS_DATA || {}).speed || 45;
      track.style.setProperty("--nt-shift", runW + "px");
      track.style.animationDuration = Math.max(8, Math.round(runW / speed)) + "s";
      // move in whole Videopac dots (2 css px), never in between - the
      // slightly jerky crawl of a scroll the CPU does one step at a time
      track.style.animationTimingFunction = "steps(" + Math.max(1, Math.round(runW / 4)) + ")";
      wrap.classList.add("nt-running");
    }
    wrap.ntSize = size;              // so mountNewsTape() can re-fit after a move
    requestAnimationFrame(size);
    setTimeout(size, 400);                        // again once webfonts settle

    wrap.querySelector(".nt-close").addEventListener("click", function () {
      try { localStorage.setItem(newsSeenKey(), sig); } catch (e) {}
      wrap.classList.add("nt-gone");
      setTimeout(function () {
        if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
      }, 300);
    });

    return wrap;
  }

  // The tape runs full width directly under whichever "Featured and
  // recommended" panel is on screen - one node, moved between the four
  // showcases as the shelf changes rather than one tape per shelf. No cached
  // reference on purpose: the first render runs while this file is still
  // being evaluated, so any top-level var up here would still be undefined
  // (and its initialiser would later wipe what was stored in it). The DOM is
  // the state. Once dismissed, newsTape() returns null and nothing remounts.
  function mountNewsTape() {
    var sc = document.querySelector("section.showcase:not([hidden])");
    var tape = document.querySelector(".news-tape");
    if (!sc) { if (tape) tape.hidden = true; return; }
    tape = tape || newsTape();
    if (!tape) return;
    tape.hidden = false;
    if (tape.previousElementSibling !== sc) {
      sc.parentNode.insertBefore(tape, sc.nextSibling);
      if (tape.ntSize) requestAnimationFrame(tape.ntSize);   // re-fit to the new spot
    }
  }

  // Homebrew gets its own panel partway down the library. The games at the
  // top of the page are the ones Philips sold; these are the ones people
  // wrote afterwards, and they'd disappear among 213 covers otherwise.
  var hbStop = null;
  function homebrewBlock() {
    var picks = ((window.FEATURED_DATA || {}).homebrew || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var tpl = document.getElementById("homebrewTpl");
    if (!picks.length || !tpl) return null;
    if (hbStop) hbStop();
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=homebrewHead]").textContent = window.t("homebrewHead");
    node.querySelector(".hb-word").textContent = window.t("cat_homebrew");
    node.querySelector(".hb-intro").textContent = window.t("homebrewIntro");
    hbStop = featureRotator(node.querySelector(".feature-main"),
                            node.querySelector(".feature-list"), picks);
    return node;
  }

  // The C64 shelf's own homebrew panel - same idea as the Videopac one above,
  // separate data (c64homebrew in featured.js) and template so a C64 pick
  // never leaks onto the Videopac page and vice versa. Unlike the Videopac
  // panel, the right-hand slot here plays each pick's own gameplay clip
  // instead of a static shot_ screenshot - same three-layer fallback as the
  // top-of-page C64 panel (local clips/clip_<id>.mp4 -> YouTube embed ->
  // cover art). Not a reuse of c64FeatureRotator because that one's main
  // element is a plain <div> and builds its own inner <a> around the cover;
  // this panel's main element is itself the <a> (see c64homebrewTpl), so
  // nesting another link inside it would be invalid markup. Kept as its own
  // function rather than patched into featureRotator so the Videopac
  // homebrew panel (which has no clips) is untouched.
  function c64HomebrewClipFallback(box) {
    var vid = box.getAttribute("data-vid");
    var gid = box.getAttribute("data-gid");
    if (vid) {
      box.innerHTML = '<iframe src="' + ytEmbed(vid) + '" title="" loading="lazy" ' +
        'frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" ' +
        'allowfullscreen></iframe>';
    } else {
      box.classList.add("feature-video-fallback");
      box.innerHTML = '<img src="covers/' + gid + '.png?v=' + COVER_V +
        '" alt="" onerror="this.onerror=null;this.src=\'covers/' + gid + '.jpg?v=' + COVER_V + '\'">';
    }
  }

  function c64HomebrewFeatureRotator(main, list, picks) {
    var at = 0, timer = null;

    function videoSlot(g) {
      var gp = (window.GAMEPAGES_DATA || {})[g.id] || {};
      var vid = gp.video && gp.video.id ? gp.video.id : "";
      return '<div class="feature-video" data-gid="' + g.id + '" data-vid="' + vid + '">' +
        '<video class="feature-clip" src="clips/clip_' + g.id + '.mp4?v=' + CLIP_V + '" ' +
        'autoplay muted loop playsinline preload="auto"></video></div>';
    }

    function wireClip() {
      var box = main.querySelector(".feature-video");
      if (!box) return;
      var v = box.querySelector("video");
      if (!v) return;
      v.addEventListener("error", function () { c64HomebrewClipFallback(box); }, { once: true });
      var p = v.play && v.play();
      if (p && p.catch) p.catch(function () {});
    }

    function show(n) {
      at = (n + picks.length) % picks.length;
      var pick = picks[at], g = gameById(pick.id);
      var gen = (window.GENRE_DATA || {})[g.id] || {};
      main.href = "game.html?id=" + encodeURIComponent(g.id);
      main.innerHTML =
        '<span class="feature-cover-wrap">' +
        '<img class="feature-cover" src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
        'onerror="this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">' +
        '<span class="cover-ribbon">' + window.t("cat_homebrew") + '</span>' +
        '</span>' +
        '<div class="feature-copy">' +
        '<h3>' + g.title + '</h3>' +
        '<p class="feature-blurb">' + window.tx(pick.blurb) + '</p>' +
        '<div class="feature-meta">' +
        '<span class="badge ' + platformBadge(g.platform) + '">' + g.platform + '</span>' +
        (gen.genre ? '<span class="badge badge-cat">' + window.t("g_" + gen.genre) + '</span>' : '') +
        (gen.players ? '<span class="badge badge-cat">' + window.t("p_" + gen.players) + '</span>' : '') +
        '</div></div>' + videoSlot(g);
      wireClip();
      list.querySelectorAll(".feature-thumb").forEach(function (b, n2) {
        b.classList.toggle("on", n2 === at);
      });
    }

    list.innerHTML = picks.map(function (p, n) {
      var g = gameById(p.id);
      return '<button class="feature-thumb" data-i="' + n + '">' +
             '<img src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
             'onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">' +
             '<span>' + g.title + '</span></button>';
    }).join("");
    list.querySelectorAll(".feature-thumb").forEach(function (b) {
      b.addEventListener("click", function () {
        show(parseInt(this.dataset.i, 10));
        clearInterval(timer);
        timer = null;
      });
    });

    show(0);
    timer = setInterval(function () { show(at + 1); }, 7000);
    return function () { if (timer) clearInterval(timer); timer = null; };
  }

  // The Master Strategy Series banner - three games, always all three shown
  // at once (there are only three, and rotating one out of three defeats the
  // point of a banner that exists specifically to give them room). Bigger
  // and richer than the "featured" panel above it: box contents, a fact line,
  // and two media slots per card instead of one.
  //
  // The gameplay slot reuses the same three-layer fallback as the C64
  // homebrew panel - clips/clip_<id>.mp4 first (drop one in and it plays,
  // no code change needed), then the game's own gamepages.js YouTube video,
  // then the cover - so this works today and upgrades itself the moment a
  // clip is added. The board slot is a static photo of the physical board,
  // stored as covers/board_<id>.jpg (see the comment in featured.js for why
  // it lives in covers/ rather than a new folder).
  function msVideoFallback(box) {
    var vid = box.getAttribute("data-vid");
    var gid = box.getAttribute("data-gid");
    if (vid) {
      box.innerHTML = '<iframe src="' + ytEmbed(vid) + '" title="" loading="lazy" ' +
        'frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" ' +
        'allowfullscreen></iframe>';
    } else {
      box.innerHTML = '<img src="covers/' + gid + '.png?v=' + COVER_V +
        '" alt="" onerror="this.onerror=null;this.src=\'covers/' + gid + '.jpg?v=' + COVER_V + '\'">';
    }
  }

  function wireMsClips(host) {
    host.querySelectorAll(".ms-video").forEach(function (box) {
      var v = box.querySelector("video");
      if (!v) return;
      v.addEventListener("error", function () { msVideoFallback(box); }, { once: true });
      var p = v.play && v.play();
      if (p && p.catch) p.catch(function () {});
    });
  }

  function msCard(pick) {
    var g = gameById(pick.id);
    if (!g) return "";
    var href = "game.html?id=" + encodeURIComponent(g.id);
    var gp = (window.GAMEPAGES_DATA || {})[g.id] || {};
    var vid = gp.video && gp.video.id ? gp.video.id : "";
    var contents = (pick.contents || []).map(function (c) { return "<li>" + window.tx(c) + "</li>"; }).join("");
    // Regional/standalone releases of this same game that carry no
    // vpNumber of their own (e.g. br_9434 for vp_46) - filtered against
    // state.games the same way `picks` itself is, so a variant id typo'd
    // or not yet in the catalogue just silently drops instead of 404ing.
    var variants = (pick.variants || []).filter(function (v) {
      return state.games.some(function (g2) { return g2.id === v.id; });
    });
    var variantsHtml = variants.length
      ? '<p class="ms-variants">' + variants.map(function (v) {
          return 'Also released as <a href="game.html?id=' + encodeURIComponent(v.id) + '">' + v.label + '</a>';
        }).join(" &middot; ") + '</p>'
      : "";
    return (
      '<div class="ms-card">' +
        '<div class="ms-card-top">' +
          '<a href="' + href + '"><img class="ms-card-cover" src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" ' +
          'onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'"></a>' +
          '<div class="ms-card-head">' +
            '<h3><a href="' + href + '">' + g.title + '</a></h3>' +
            '<span class="ms-year">' + pick.year + '</span>' +
            (pick.fact ? '<span class="ms-fact">' + window.tx(pick.fact) + '</span>' : '') +
          '</div>' +
        '</div>' +
        '<p class="ms-blurb">' + window.tx(pick.blurb) + '</p>' +
        (contents ? '<ul class="ms-contents">' + contents + '</ul>' : '') +
        variantsHtml +
        '<div class="ms-media">' +
          '<div class="ms-media-box">' +
            '<div class="ms-media-frame ms-video" data-gid="' + g.id + '" data-vid="' + vid + '">' +
              '<video class="ms-clip" src="clips/clip_' + g.id + '.mp4?v=' + CLIP_V + '" ' +
              'autoplay muted loop playsinline preload="auto"></video>' +
            '</div>' +
            '<span class="ms-media-cap">' + window.t("gameplay") + '</span>' +
          '</div>' +
          '<div class="ms-media-box">' +
            '<div class="ms-media-frame ms-board-frame">' +
              '<img src="covers/board_' + g.id + '.jpg" alt="">' +
            '</div>' +
            '<span class="ms-media-cap">' + window.t("msBoardLabel") + '</span>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  // Built the same way as homebrewBlock()/communityBlock() - a <template>
  // clone dropped mid-grid by placeBlocks(), not a fixed section pinned to
  // the top of the page. Sits on its own between the sponsor strip and the
  // homebrew panel rather than immediately next to either one (see the
  // spacing comment in placeBlocks()), so it reads as a banner you scroll
  // to, not one stacked directly on top of another.
  function masterStrategyBlock() {
    var picks = ((window.FEATURED_DATA || {}).masterStrategy || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var tpl = document.getElementById("msTpl");
    if (!picks.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector(".ms-grid").innerHTML = picks.map(msCard).join("");
    wireMsClips(node);
    return node;
  }

  // The Amiga shelf's demoscene banner (2026-10-11) - six landmark demos in
  // date order, data in FEATURED_DATA.amdemoscene. Each card shows the
  // demo's own cover frame as a still; clicking it swaps in the game page's
  // YouTube capture WITH sound and controls (unlike ytEmbed(), which is the
  // muted, chrome-less autoplay loop the other banners use) - the music is
  // half of what a demo is, and the click is a user gesture so the browser
  // allows audio. Only one plays at a time: starting another puts the
  // previous card back to its still. Same <template> + placeBlocks() route
  // as the other mid-grid panels.
  function amDemoEmbed(vid) {
    return "https://www.youtube-nocookie.com/embed/" + vid +
      "?autoplay=1&controls=1&modestbranding=1&playsinline=1&rel=0";
  }

  function amDemoStill(g, pick) {
    return '<img src="covers/' + g.id + '.png?v=' + COVER_V + '" alt="" loading="lazy"' +
      (pick.pos ? ' style="object-position:' + pick.pos + '"' : '') +
      ' onerror="this.onerror=null;this.src=\'covers/' + g.id + '.jpg?v=' + COVER_V + '\'">';
  }

  function amDemoCard(pick, labels) {
    var g = gameById(pick.id);
    if (!g) return "";
    var href = "game.html?id=" + encodeURIComponent(g.id);
    var gp = (window.GAMEPAGES_DATA || {})[g.id] || {};
    var vid = gp.video && gp.video.id ? gp.video.id : "";
    var name = g.title.replace(/\s*\([^)]*\)\s*$/, "");   // "Arte (Sanity)" -> "Arte"; the group has its own line
    return (
      '<div class="demo-card">' +
        '<div class="demo-screen" data-vid="' + vid + '" data-gid="' + g.id + '">' +
          amDemoStill(g, pick) +
          '<span class="demo-year">' + (g.year || "") + '</span>' +
          (vid ? '<button type="button" class="demo-play"><span class="demo-play-tri"></span>' +
                 window.tx(labels.watch) + '</button>' : '') +
        '</div>' +
        '<div class="demo-body">' +
          '<h4><a href="' + href + '">' + name + '</a></h4>' +
          '<span class="demo-group">' + (g.publisher || "") + '</span>' +
          (pick.fact ? '<span class="demo-fact">' + window.tx(pick.fact) + '</span>' : '') +
          '<p class="demo-blurb">' + window.tx(pick.blurb) + '</p>' +
          '<a class="demo-run" href="' + href + '">' + window.tx(labels.run) + ' &rsaquo;</a>' +
        '</div>' +
      '</div>'
    );
  }

  function amDemosceneBlock() {
    var data = (window.FEATURED_DATA || {}).amdemoscene;
    var tpl = document.getElementById("amdemoTpl");
    if (!data || !tpl) return null;
    var picks = (data.picks || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    if (!picks.length) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector(".demo-kicker").textContent = window.tx(data.kicker);
    node.querySelector(".demo-head h3").textContent = window.tx(data.head);
    node.querySelector(".demo-intro").textContent = window.tx(data.intro);
    node.querySelector(".demo-facts").innerHTML = (data.facts || []).map(function (f) {
      return '<div class="demo-factbox"><b>' + window.tx(f.big) + '</b><span>' + window.tx(f.text) + '</span></div>';
    }).join("");
    node.querySelector(".demo-grid").innerHTML = picks.map(function (p) { return amDemoCard(p, data); }).join("");
    node.addEventListener("click", function (e) {
      var btn = e.target.closest(".demo-play");
      var screen = btn ? btn.closest(".demo-screen") : (e.target.closest(".demo-screen:not(.playing)"));
      if (!screen || !screen.getAttribute("data-vid")) return;
      node.querySelectorAll(".demo-screen.playing").forEach(function (other) {
        var pk = picks.filter(function (p) { return p.id === other.getAttribute("data-gid"); })[0];
        var og = gameById(other.getAttribute("data-gid"));
        other.classList.remove("playing");
        other.innerHTML = amDemoStill(og, pk || {}) + '<span class="demo-year">' + (og.year || "") + '</span>' +
          '<button type="button" class="demo-play"><span class="demo-play-tri"></span>' + window.tx(data.watch) + '</button>';
      });
      screen.classList.add("playing");
      screen.innerHTML = '<iframe src="' + amDemoEmbed(screen.getAttribute("data-vid")) + '" title="" ' +
        'frameborder="0" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
    });
    return node;
  }

  var c64HbStop = null;
  function c64HomebrewBlock() {
    var picks = ((window.FEATURED_DATA || {}).c64homebrew || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var tpl = document.getElementById("c64homebrewTpl");
    if (!picks.length || !tpl) return null;
    if (c64HbStop) c64HbStop();
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=homebrewHead]").textContent = window.t("homebrewHead");
    node.querySelector(".hb-word").textContent = window.t("cat_homebrew");
    node.querySelector(".hb-intro").textContent = window.t("homebrewIntro");
    c64HbStop = c64HomebrewFeatureRotator(node.querySelector(".feature-main"),
                                          node.querySelector(".feature-list"), picks);
    return node;
  }

  // The PC shelf's own homebrew panel - same idea as the two above, separate
  // data (pchomebrew in featured.js) and template (pchomebrewTpl) so a PC
  // pick never leaks onto the Videopac or C64 pages. Reuses
  // c64HomebrewFeatureRotator() directly rather than a third copy of that
  // function - pchomebrewTpl's main element is the <a> itself, same shape as
  // c64homebrewTpl (unlike c64FeatureRotator's plain-div main, which is what
  // the top-of-page pcfeatured panel reuses instead - see the comment there).
  // The three-layer fallback still applies even though none of these six
  // picks has a gameplay clip yet: an empty clips/clip_<id>.mp4 404s
  // immediately, and since these homebrew games have no gamepages.js video
  // id either, it falls straight through to the cover - so the panel looks
  // right today and just starts playing clips the moment Mike drops them in,
  // no code change needed.
  var pcHbStop = null;
  function pcHomebrewBlock() {
    var picks = ((window.FEATURED_DATA || {}).pchomebrew || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var tpl = document.getElementById("pchomebrewTpl");
    if (!picks.length || !tpl) return null;
    if (pcHbStop) pcHbStop();
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=homebrewHead]").textContent = window.t("homebrewHead");
    node.querySelector(".hb-word").textContent = window.t("cat_homebrew");
    node.querySelector(".hb-intro").textContent = window.t("homebrewIntro");
    pcHbStop = c64HomebrewFeatureRotator(node.querySelector(".feature-main"),
                                         node.querySelector(".feature-list"), picks);
    return node;
  }

  // The Amiga shelf's own homebrew panel - same idea as the three above,
  // separate data (amhomebrew in featured.js) and template (amhomebrewTpl).
  // Reuses c64HomebrewFeatureRotator() like the PC one: clip -> YouTube ->
  // cover. Its own intro line (amHomebrewIntro) because the shared one
  // talks about "the console" and 1998, which is the Videopac's story.
  var amHbStop = null;
  function amHomebrewBlock() {
    var picks = ((window.FEATURED_DATA || {}).amhomebrew || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var tpl = document.getElementById("amhomebrewTpl");
    if (!picks.length || !tpl) return null;
    if (amHbStop) amHbStop();
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=homebrewHead]").textContent = window.t("homebrewHead");
    node.querySelector(".hb-word").textContent = window.t("cat_homebrew");
    node.querySelector(".hb-intro").textContent = window.t("amHomebrewIntro");
    amHbStop = c64HomebrewFeatureRotator(node.querySelector(".feature-main"),
                                         node.querySelector(".feature-list"), picks);
    return node;
  }

  // Loops the community carousel: Next past the last card wraps back to the
  // first, Previous from the first wraps to the last. Shared by both the
  // Videopac and C64 "keeping this console alive" panels so the behaviour
  // stays identical on both shelves.
  function wireCommunityCarousel(node, track) {
    node.querySelectorAll(".car-btn").forEach(function (b) {
      b.addEventListener("click", function () {
        var dir = parseInt(this.dataset.dir, 10);
        var max = track.scrollWidth - track.clientWidth;
        var atEnd = track.scrollLeft >= max - 4;
        var atStart = track.scrollLeft <= 4;
        if (dir > 0 && atEnd) {
          track.scrollTo({ left: 0, behavior: "smooth" });
        } else if (dir < 0 && atStart) {
          track.scrollTo({ left: max, behavior: "smooth" });
        } else {
          track.scrollBy({ left: track.clientWidth * 0.8 * dir, behavior: "smooth" });
        }
      });
    });
  }

  // The community panel is a carousel: on a 14-inch screen six cards wrapped
  // onto a second line and webretro ended up orphaned down there on its own.

  // Each card's "what" description can be a plain string (old data, or a
  // future hand-edit) or an { en, nl, de, fr, pt } object keyed the same
  // way as window.I18N (2026-08-12). Pick the current site language out of
  // it, falling back to English so a card missing one language's text still
  // shows something rather than nothing. This is what makes the community
  // cards actually re-translate when the language flag is switched - before
  // this, only the panel's own heading/intro line went through window.t();
  // the cards themselves were always plain English regardless of language.
  // Kept as a named wrapper for readability at the three call sites; the
  // actual { en, nl, de, fr, pt }-or-string resolution is window.tx() in
  // i18n.js, shared with the featured blurbs, the Master Strategy panel and
  // the sponsor banners (2026-09-08).
  function communityWhat(c) {
    return window.tx(c.what);
  }

  function communityBlock() {
    var list = (window.FEATURED_DATA || {}).community || [];
    var tpl = document.getElementById("communityTpl");
    if (!list.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=communityHead]").textContent = window.t("communityHead");
    node.querySelector(".community-intro").textContent = window.t("communityIntro");
    var track = node.querySelector(".community-track");
    track.innerHTML = list.map(function (c) {
      return '<a class="community-item" href="' + c.url + '" target="_blank" rel="noopener" ' +
        'style="--tint:' + (c.tint || "#8a8f98") + '">' +
        '<span class="cname">' + c.name +
        (c.lang ? '<span class="clang">' + c.lang + '</span>' : '') + '</span>' +
        '<p class="cwhat">' + communityWhat(c) + '</p></a>';
    }).join("");
    wireCommunityCarousel(node, track);
    return node;
  }

  // The C64 shelf's own "keeping this console alive" panel - same carousel
  // as the Videopac one above, separate data (c64community in featured.js)
  // and template so a C64 site never shows on the Videopac page or vice versa.
  function c64CommunityBlock() {
    var list = (window.FEATURED_DATA || {}).c64community || [];
    var tpl = document.getElementById("c64communityTpl");
    if (!list.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=communityHead]").textContent = window.t("communityHead");
    node.querySelector(".community-intro").textContent = window.t("communityIntro");
    var track = node.querySelector(".community-track");
    track.innerHTML = list.map(function (c) {
      return '<a class="community-item" href="' + c.url + '" target="_blank" rel="noopener" ' +
        'style="--tint:' + (c.tint || "#8a8f98") + '">' +
        '<span class="cname">' + c.name +
        (c.lang ? '<span class="clang">' + c.lang + '</span>' : '') + '</span>' +
        '<p class="cwhat">' + communityWhat(c) + '</p></a>';
    }).join("");
    wireCommunityCarousel(node, track);
    return node;
  }

  // The PC shelf's own "keeping this console alive" panel - same carousel
  // as the Videopac/C64 ones above, separate data (pccommunity in
  // featured.js) and template so a DOS site never shows on the Videopac or
  // C64 pages or vice versa.
  function pcCommunityBlock() {
    var list = (window.FEATURED_DATA || {}).pccommunity || [];
    var tpl = document.getElementById("pccommunityTpl");
    if (!list.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=communityHead]").textContent = window.t("communityHead");
    node.querySelector(".community-intro").textContent = window.t("communityIntro");
    var track = node.querySelector(".community-track");
    track.innerHTML = list.map(function (c) {
      return '<a class="community-item" href="' + c.url + '" target="_blank" rel="noopener" ' +
        'style="--tint:' + (c.tint || "#8a8f98") + '">' +
        '<span class="cname">' + c.name +
        (c.lang ? '<span class="clang">' + c.lang + '</span>' : '') + '</span>' +
        '<p class="cwhat">' + communityWhat(c) + '</p></a>';
    }).join("");
    wireCommunityCarousel(node, track);
    return node;
  }

  // The Amiga shelf's own "keeping this console alive" panel - same carousel
  // as the three above, separate data (amcommunity in featured.js) and
  // template so an Amiga site never shows on another shelf or vice versa.
  function amCommunityBlock() {
    var list = (window.FEATURED_DATA || {}).amcommunity || [];
    var tpl = document.getElementById("amcommunityTpl");
    if (!list.length || !tpl) return null;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector("[data-i18n=communityHead]").textContent = window.t("communityHead");
    node.querySelector(".community-intro").textContent = window.t("communityIntro");
    var track = node.querySelector(".community-track");
    track.innerHTML = list.map(function (c) {
      return '<a class="community-item" href="' + c.url + '" target="_blank" rel="noopener" ' +
        'style="--tint:' + (c.tint || "#8a8f98") + '">' +
        '<span class="cname">' + c.name +
        (c.lang ? '<span class="clang">' + c.lang + '</span>' : '') + '</span>' +
        '<p class="cwhat">' + communityWhat(c) + '</p></a>';
    }).join("");
    wireCommunityCarousel(node, track);
    return node;
  }

  // The advert and community panels span the full grid width, so dropping one
  // mid-row leaves the rest of that row empty. Work out how many columns the
  // grid actually has and land them on a row boundary instead. The count
  // changes with the window, hence the re-run on resize.
  function gridColumns() {
    var t = getComputedStyle(grid).gridTemplateColumns;
    return t && t !== "none" ? t.split(" ").filter(Boolean).length : 1;
  }

  function placeBlocks(total) {
    grid.querySelectorAll(".sponsor-strip, .homebrew-strip, .ms-strip, .community, .c64-ad-strip, .pc-ad-strip, .amiga-ad-strip, .demo-strip")
        .forEach(function (n) { n.remove(); });
    var cols = gridColumns();
    var cards = grid.querySelectorAll(".card");

    function insertAt(node, wanted) {
      if (!node) return;
      var row = Math.max(1, Math.round(wanted / cols));   // nearest whole row
      var idx = row * cols;
      if (idx >= cards.length) return;
      grid.insertBefore(node, cards[idx]);
    }
    // The C64 shelf gets its own C64-style advert and none of the Videopac
    // homebrew/community panels (those are Videopac content).
    if (state.platform === "C64") {
      if (total >= 6) insertAt(c64AdBlock(), Math.min(12, Math.floor(total / 2)));
      if (total >= 40) insertAt(c64HomebrewBlock(), Math.min(80, Math.floor(total * 2 / 3)));
      if (total >= 20) insertAt(c64CommunityBlock(), Math.min(50, Math.floor(total * 5 / 6)));
      return;
    }
    // The PC shelf gets its own DOS-style advert, its own homebrew panel and
    // its own "keeping this console alive" panel, and none of the Videopac
    // homebrew/community panels (those are Videopac content) - same
    // reasoning as the C64 branch above.
    if (state.platform === "PC") {
      if (total >= 6) insertAt(pcAdBlock(), Math.min(12, Math.floor(total / 2)));
      if (total >= 30) insertAt(pcHomebrewBlock(), Math.min(60, Math.floor(total * 2 / 3)));
      if (total >= 20) insertAt(pcCommunityBlock(), Math.min(50, Math.floor(total * 5 / 6)));
      return;
    }
    // The Amiga shelf gets its own Amiga-style advert, its own "still being
    // written" homebrew panel and its own "keeping this console alive" panel,
    // and none of the Videopac ones - same reasoning as the two branches
    // above. The homebrew panel is modern releases only (2023 on): the
    // 1990s PD disks are already the bulk of the grid, so a panel of those
    // would just repeat it.
    if (state.platform === "Amiga") {
      if (total >= 6) insertAt(amAdBlock(), Math.min(12, Math.floor(total / 2)));
      // The demoscene banner sits between the advert and the community
      // panel, with a couple of rows of ordinary cards either side of it.
      if (total >= 30) insertAt(amDemosceneBlock(), Math.min(30, Math.floor(total / 2)));
      if (total >= 20) insertAt(amCommunityBlock(), Math.min(50, Math.floor(total * 5 / 6)));
      // Homebrew comes last, past the community panel, so the four banners
      // land roughly 20 cards apart (12 / 30 / 50 / 72 on today's shelf).
      if (total >= 40) insertAt(amHomebrewBlock(), Math.min(72, Math.floor(total * 2 / 3)));
      return;
    }
    if (total < 60) return;                       // too short to bother
    insertAt(sponsorBlock(), Math.min(36, Math.floor(total / 3)));
    insertAt(homebrewBlock(), Math.min(96, Math.floor(total * 2 / 3)));
    // Sits between homebrew and community rather than at a literal total/2 -
    // the middle of the list by fraction alone lands right on homebrew's own
    // heels (2/3 of the way is only a handful of cards past 1/2), which would
    // read as two banners stacked back to back. This keeps roughly a row or
    // two of ordinary game cards on both sides of it instead.
    insertAt(masterStrategyBlock(), Math.min(130, Math.floor(total * 3 / 5)));
    insertAt(communityBlock(), Math.min(160, Math.floor(total * 6 / 7)));
  }

  var replaceTimer = null;
  window.addEventListener("resize", function () {
    clearTimeout(replaceTimer);
    replaceTimer = setTimeout(function () {
      placeBlocks(grid.querySelectorAll(".card").length);
    }, 150);
  });

  function render() {
    var filtered = state.games.filter(matches).sort(state.list === "recent" ? byRecent : bySort);
    if (typeof updateListChips === "function" && clearBtn) {
      var anyOn = state.category !== "all" || state.genre !== "all" || state.players !== "all" ||
                  state.platform !== "videopac" || state.list !== "all" || !!state.query;
      clearBtn.hidden = !anyOn;
    }
    var shelfTotal = platformGames().length;
    resultCount.textContent = window.t("results", { shown: filtered.length, total: shelfTotal });
    searchInput.placeholder = window.t("search", { n: shelfTotal });
    emptyState.hidden = filtered.length !== 0;
    grid.innerHTML = "";
    var frag = document.createDocumentFragment();
    // drop the community panel in around a third of the way down, but only on
    // a decent-sized list - it would dominate a five-result search
    filtered.forEach(function (g) { frag.appendChild(renderCard(g)); });
    grid.appendChild(frag);
    placeBlocks(filtered.length);
  }

  function renderCard(g) {
    var card = document.createElement("div");
    card.className = "card";
    card.title = g.title + " - manual, history & play";

    var cover = document.createElement("div");
    cover.className = "cover";
    cover.style.background = hashColor(g.category + g.title);
    cover.textContent = initials(g.title);

    // Cover art - opt-in, for every category (official releases,
    // homebrew, mods, rare dumps, all of it). No cover images ship
    // with this app; drop your own scans, or images you've sourced
    // yourself, into covers/<id>.jpg. See covers/README.txt. Falls
    // back to the initials tile above if no matching image exists or
    // it fails to load.
    // COVER_V is bumped whenever a cover is added or swapped. Without it the
    // browser keeps serving its cached *miss* for a cover that didn't exist
    // when the page was first opened, so a newly added scan stays invisible
    // even after a hard refresh.
    var img = new Image();
    img.className = "cover-art";
    img.alt = g.title + " box art";
    img.loading = "lazy";
    img.onerror = function () {
      if (this.dataset.stage === "png") {
        this.dataset.stage = "jpg";
        this.src = "covers/" + coverId(g) + ".jpg?v=" + COVER_V;
      } else {
        this.remove();
      }
    };
    img.dataset.stage = "png";
    img.src = "covers/" + coverId(g) + ".png?v=" + COVER_V;
    cover.appendChild(img);

    // Homebrew games are easy to mistake for official releases in the grid,
    // and four of them borrow an official box for want of art of their own.
    if (groupFor(g).key === "homebrew") {
      var rib = document.createElement("span");
      rib.className = "cover-ribbon";
      rib.textContent = window.t("cat_homebrew");
      cover.appendChild(rib);
    }

    var body = document.createElement("div");
    body.className = "card-body";

    var t = document.createElement("p");
    t.className = "card-title";
    t.textContent = g.title;

    var meta = document.createElement("div");
    meta.className = "card-meta";

    var pbadge = document.createElement("span");
    pbadge.className = "badge " + platformBadge(g.platform);
    pbadge.textContent = g.platform;
    meta.appendChild(pbadge);

    var grp = groupFor(g);
    var cbadge = document.createElement("span");
    cbadge.className = "badge badge-cat-dyn";
    cbadge.style.setProperty("--badge-color", grp.color);
    cbadge.textContent = catLabel(grp);
    meta.appendChild(cbadge);

    var variant = variantFor(g);
    if (variant) {
      var vbadge = document.createElement("span");
      vbadge.className = "badge badge-variant" + (g.tags && g.tags.indexOf("adult") !== -1 ? " badge-adult" : "");
      vbadge.textContent = variant;
      meta.appendChild(vbadge);
    }

    var pack = window.PACKAGING_DATA && window.PACKAGING_DATA[g.id];
    if (pack) {
      var pbadge2 = document.createElement("span");
      pbadge2.className = "badge badge-pack";
      pbadge2.textContent = pack.kind;
      pbadge2.title = pack.detail;
      meta.appendChild(pbadge2);
    }

    // star sits on the cover so it doesn't push the card layout around
    var star = document.createElement("button");
    star.className = "fav-btn" + (isFav(g.id) ? " on" : "");
    star.type = "button";
    star.innerHTML = "&#9733;";
    star.title = isFav(g.id) ? "Remove from favorites" : "Add to favorites";
    star.setAttribute("aria-label", star.title);
    star.addEventListener("click", function (e) {
      e.stopPropagation();               // don't open the game page
      toggleFav(g.id);
      this.classList.toggle("on", isFav(g.id));
      this.title = isFav(g.id) ? "Remove from favorites" : "Add to favorites";
      if (state.list === "fav") render(); // drop it out of the list immediately
    });
    cover.appendChild(star);

    body.appendChild(t);
    body.appendChild(meta);
    card.appendChild(cover);
    card.appendChild(body);

    card.addEventListener("click", function () {
      window.location.href = "game.html?id=" + encodeURIComponent(g.id);
    });

    return card;
  }

  document.getElementById("platformChips").addEventListener("click", function (e) {
    var btn = e.target.closest(".chip");
    if (!btn) return;
    document.querySelectorAll("#platformChips .chip").forEach(function (c) { c.classList.remove("active"); });
    btn.classList.add("active");
    state.platform = btn.dataset.platform;
    state.category = "all"; state.genre = "all"; state.players = "all";
    categorySel.classList.remove("on"); genreSel.classList.remove("on"); playerSel.classList.remove("on");
    buildCategoryChips(platformGames());
    buildFacets();
    updateListChips();
    localStorage.setItem(SHELF_KEY, state.platform);
    syncShelfChips();
    render();
  });

  function updateListChips() {
    document.getElementById("favCount").textContent = favCount();
    document.getElementById("packCount").textContent =
      state.games.filter(function (g) { return hasPackaging(g.id); }).length;
    var recentChip = document.getElementById("recentChip");
    if (recentChip) {
      var rc = platformGames().filter(function (g) { return isRecent(g.id); }).length;
      document.getElementById("recentCount").textContent = rc;
      recentChip.title = window.t("recent");
      // nothing played on this shelf yet: no chip (and drop out of the view)
      if (!rc && state.list === "recent") state.list = "all";
      recentChip.hidden = !rc;
    }
    var recentIo = document.getElementById("recentIo");
    if (recentIo) recentIo.hidden = state.list !== "recent";
    document.querySelectorAll("#favChip, #packChip, #recentChip").forEach(function (b) {
      b.classList.toggle("active", b.dataset.list === state.list);
    });
    // export/import belong next to the star, not buried in Setup - but only
    // once you are actually looking at your favourites
    var favIo = document.getElementById("favIo");
    if (favIo) favIo.hidden = state.list !== "fav";
    // only offer the reset when something is actually filtered
    var on = state.category !== "all" || state.genre !== "all" || state.players !== "all" ||
             state.platform !== "videopac" || state.list !== "all" || !!state.query;
    clearBtn.hidden = !on;
  }

  var clearRecentBtn = document.getElementById("clearRecent");
  if (clearRecentBtn) clearRecentBtn.addEventListener("click", function () {
    try { localStorage.removeItem(RECENT_KEY); } catch (e) {}
    loadRecent();
    state.list = "all";
    updateListChips();
    render();
  });
  // coming back from a game page (browser Back can restore this page from
  // the back/forward cache without re-running anything) - pick up the play
  window.addEventListener("pageshow", function (e) {
    if (!e.persisted) return;
    loadRecent();
    updateListChips();
    if (state.list === "recent") render();
  });

  document.querySelectorAll("#favChip, #packChip, #recentChip").forEach(function (btn) {
    btn.addEventListener("click", function () {
      // clicking the active one turns it back off
      state.list = (state.list === this.dataset.list) ? "all" : this.dataset.list;
      updateListChips();
      render();
    });
  });

  function buildFacets() {
    buildFacetChips(genreSel, GENRE_ORDER, genreOf, "g_", "genre", window.t("allGenres"));
    buildFacetChips(playerSel, PLAYER_ORDER, playersOf, "p_", "players", window.t("allPlayers"));
    sortSel.innerHTML = '<option value="number">' + window.t("sortNumber") + '</option>' +
                        '<option value="az">' + window.t("sortAZ") + '</option>';
    sortSel.value = state.sort;
  }

  function onFacetChange(sel, stateKey) {
    sel.addEventListener("change", function () {
      state[stateKey] = this.value;
      this.classList.toggle("on", this.value !== "all");
      render();
    });
  }
  onFacetChange(categorySel, "category");
  onFacetChange(genreSel, "genre");
  onFacetChange(playerSel, "players");

  sortSel.addEventListener("change", function () {
    state.sort = this.value;
    localStorage.setItem(SORT_KEY, state.sort);
    render();
  });

  clearBtn.addEventListener("click", function () {
    state.category = state.genre = state.players = "all";
    state.platform = "videopac";
    state.list = "all"; state.query = ""; searchInput.value = "";
    localStorage.setItem(SHELF_KEY, "videopac");
    syncShelfChips();
    buildCategoryChips(platformGames());
    buildFacets();
    updateListChips();
    render();
  });

  searchInput.addEventListener("input", function () {
    state.query = searchInput.value.trim();
    render();
  });

  // ---- Favorites export / import ---------------------------------------
  // localStorage belongs to the browser, not to this folder, so favorites do
  // not travel when the Vault is copied or shared. These two buttons move them
  // as a small JSON file.
  var favIoNote = document.getElementById("favIoNote");
  function note(msg) {
    favIoNote.textContent = msg;
    favIoNote.classList.add("ok");
    setTimeout(function () { favIoNote.classList.remove("ok"); }, 4000);
  }

  document.getElementById("exportFavs").addEventListener("click", function () {
    var ids = Object.keys(favorites);
    if (!ids.length) { note("Nothing to export yet - star a few games first."); return; }
    var payload = {
      app: "Retro Vault",
      kind: "favorites",
      exported: new Date().toISOString().slice(0, 10),
      ids: ids
    };
    var blob = new Blob([JSON.stringify(payload, null, 1)], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "retro-vault-favorites.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    note("Exported " + ids.length + " favorite" + (ids.length === 1 ? "" : "s") + ".");
  });

  var importInput = document.getElementById("importFavsFile");
  document.getElementById("importFavs").addEventListener("click", function () { importInput.click(); });
  importInput.addEventListener("change", function () {
    var file = this.files && this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var ids;
      try {
        var parsed = JSON.parse(reader.result);
        // accept both our own file and a bare array of ids
        ids = Array.isArray(parsed) ? parsed : parsed.ids;
        if (!Array.isArray(ids)) throw new Error("no id list");
      } catch (e) {
        note("That doesn't look like a favorites file.");
        return;
      }
      var known = {};
      state.games.forEach(function (g) { known[g.id] = 1; });
      var added = 0, skipped = 0;
      ids.forEach(function (id) {
        if (!known[id]) { skipped++; return; }   // game not in this catalogue
        if (favorites[id]) return;                // already starred
        favorites[id] = 1;
        added++;
      });
      saveFavs();
      updateListChips();
      render();
      note("Added " + added + " favorite" + (added === 1 ? "" : "s") +
           (skipped ? " (" + skipped + " not in this library)" : "") + ".");
    };
    reader.readAsText(file);
    this.value = "";   // let the same file be picked again
  });

  // ---- language ---------------------------------------------------------
  // Only the interface is translated. Game titles stay exactly as printed on
  // the cartridge, which is the whole point of a catalogue.
  // Language as a row of flags - five clicks' worth of choice does not need
  // a dropdown, and the flags read faster than the language names.
  var langFlags = document.getElementById("langFlags");
  if (langFlags && window.I18N) {
    Object.keys(window.I18N).forEach(function (code) {
      var b = document.createElement("button");
      b.className = "flag-btn";
      b.dataset.lang = code;
      b.innerHTML = window.I18N[code]._flag;   // small inline SVG, not emoji
      b.title = window.I18N[code]._name;
      b.setAttribute("aria-label", window.I18N[code]._name);
      langFlags.appendChild(b);
    });
    function markLang() {
      langFlags.querySelectorAll(".flag-btn").forEach(function (b) {
        b.classList.toggle("active", b.dataset.lang === window.currentLang());
      });
    }
    markLang();
    langFlags.addEventListener("click", function (e) {
      var b = e.target.closest(".flag-btn");
      if (!b) return;
      localStorage.setItem(window.I18N_KEY, b.dataset.lang);
      markLang();
      applyLang();
      buildCategoryChips(platformGames());
      buildFacets();
      updateListChips();
      buildShowcase();
      render();
    });
  }

  // ---- Showcase --------------------------------------------------------
  // Featured games, sponsor banners and the community links, all driven by
  // featured.js. Any panel with an empty list simply doesn't appear.
  var featStop = null;
  var c64FeatStop = null;
  var pcFeatStop = null;
  var amFeatStop = null;

  function buildShowcase() {
    var data = window.FEATURED_DATA || {};
    var host = document.getElementById("showcase");
    if (!host) return;

    // Re-runnable: the language switcher calls this again so the featured
    // blurbs re-render in the new language (they come from featured.js, not
    // from window.t, so applyLang() alone can't touch them). Kill the old
    // rotation timers first or every switch would leave another one running
    // and the panels would start flicking through picks faster and faster.
    if (featStop) { featStop(); featStop = null; }
    if (c64FeatStop) { c64FeatStop(); c64FeatStop = null; }
    if (pcFeatStop) { pcFeatStop(); pcFeatStop = null; }
    if (amFeatStop) { amFeatStop(); amFeatStop = null; }

    var picks = (data.featured || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var sponsors = data.sponsors || [];
    var community = data.community || [];
    if (!picks.length && !sponsors.length && !community.length) return;

    host.hidden = state.platform === "C64" || state.platform === "PC" || state.platform === "Amiga";

    // --- featured
    if (picks.length) {
      featStop = featureRotator(document.getElementById("featureMain"),
                                document.getElementById("featureList"), picks);
    }

    // --- the C64 featured panel, its own section, shown only on that shelf
    var c64picks = (data.c64featured || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var c64host = document.getElementById("c64showcase");
    if (c64host && c64picks.length) {
      c64host.hidden = state.platform !== "C64";
      c64FeatStop = c64FeatureRotator(document.getElementById("c64FeatureMain"),
                                      document.getElementById("c64FeatureList"), c64picks);
    }

    // --- the PC featured panel, its own section, shown only on that shelf.
    // Reuses c64FeatureRotator() as-is rather than a third copy of the same
    // ~80 lines: #pcFeatureMain is a plain <div> that builds its own inner
    // cover link, exactly like #c64FeatureMain (unlike the homebrew panels,
    // whose "main" element IS the link, which is why those got their own
    // function - see the comment above c64HomebrewFeatureRotator). Nothing
    // inside c64FeatureRotator/c64ClipFallback is actually C64-specific -
    // platform, id and clip path all come from the pick's own game data.
    var pcpicks = (data.pcfeatured || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var pchost = document.getElementById("pcshowcase");
    if (pchost && pcpicks.length) {
      pchost.hidden = state.platform !== "PC";
      pcFeatStop = c64FeatureRotator(document.getElementById("pcFeatureMain"),
                                     document.getElementById("pcFeatureList"), pcpicks);
    }

    // --- the Amiga featured panel, its own section, shown only on that
    // shelf. Same reuse of c64FeatureRotator as the PC panel above - nothing
    // in it is platform-specific, it just reads platform/id/clip off the pick.
    var ampicks = (data.amfeatured || []).filter(function (f) {
      return state.games.some(function (g) { return g.id === f.id; });
    });
    var amhost = document.getElementById("amshowcase");
    if (amhost && ampicks.length) {
      amhost.hidden = state.platform !== "Amiga";
      amFeatStop = c64FeatureRotator(document.getElementById("amFeatureMain"),
                                     document.getElementById("amFeatureList"), ampicks);
    }
  }

  // ---- Updates ---------------------------------------------------------
  // Catalogue data only, and strictly opt-in: check tells you what changed,
  // and nothing is written until you press the second button.
  var checkBtn = document.getElementById("checkUpdates");
  var applyBtn = document.getElementById("applyUpdates");
  var updNote = document.getElementById("updateNote");
  var pendingFiles = [];

  function say(msg, ok) {
    if (!updNote) return;
    updNote.textContent = msg;
    updNote.classList.toggle("ok", !!ok);
  }

  // Everything under emulator/ sits outside the update manifest by design (see
  // tools/make_manifest.py), so a copy that predates a shelf's emulator can
  // update its whole catalogue and still not start those games - the Amiga
  // shelf landed that way in September 2026. Rather than compare versions,
  // ask the engine's own entry point whether it is there, and only speak up on
  // a definite miss: a fresh download and the live site both have it and never
  // see this, and it stops by itself once the release zip is unpacked. A failed
  // request stays quiet - better silent than crying wolf while offline.
  var engineNote = document.getElementById("engineNote");
  var engineChecked = false;
  function checkAmigaEngine() {
    if (!engineNote || engineChecked) return;
    engineChecked = true;
    fetch("emulator/amiga/index.html", { method: "HEAD", cache: "no-store" })
      .then(function (r) {
        if (r.ok) return;
        engineNote.innerHTML = window.t("updEngineMissing");
        engineNote.hidden = false;
      })
      .catch(function () { /* offline or blocked: say nothing */ });
  }

  // Same check from the top bar: open Setup at that section and run it, so the
  // result and the Download button appear in one place rather than two.
  var updateModal = document.getElementById("updateModal");
  var updateBtn = document.getElementById("updateBtn");
  if (updateBtn && updateModal) {
    updateBtn.addEventListener("click", function () {
      updateModal.hidden = false;
      checkAmigaEngine();
      // check straight away - the panel exists to answer one question
      var c = document.getElementById("checkUpdates");
      if (c) c.click();
    });
    document.getElementById("closeUpdate").addEventListener("click", function () { updateModal.hidden = true; });
    updateModal.addEventListener("click", function (e) { if (e.target === updateModal) updateModal.hidden = true; });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !updateModal.hidden) updateModal.hidden = true;
    });
  }

  if (checkBtn) {
    checkBtn.addEventListener("click", function () {
      say(window.t("updChecking"));
      applyBtn.hidden = true;
      fetch("/_update/check").then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) {
          say(window.t(d.reason === "authoring" ? "updAuthoring"
                     : d.reason === "no-source" ? "updNoSource" : "updFail"));
          return;
        }
        pendingFiles = d.added.concat(d.changed);
        rememberUpdates(pendingFiles.length);
        if (!pendingFiles.length) { say(window.t("updNone"), true); return; }
        say(window.t("updFound", { n: pendingFiles.length, mb: (d.bytes / 1048576).toFixed(1) }));
        applyBtn.hidden = false;
      }).catch(function () { say(window.t("updFail")); });
    });
  }

  // The button watches by itself: on load, every five minutes while the page
  // is open, and whenever you come back to the tab. Five minutes rather than
  // one because GitHub serves the manifest with max-age=300 - ask more often
  // than that and the CDN hands back the same cached copy, so a faster poll
  // cannot give a fresher answer. The check itself is cheap: the server hashes
  // the local files, which is around 0.2 seconds for the whole catalogue.
  var UPD_SEEN = "VideopacVault_updSeen";
  var UPD_EVERY = 5 * 60 * 1000;
  var lastCheck = 0, updTimer = null;

  function markUpdates(n) {
    if (!updateBtn) return;
    updateBtn.classList.toggle("has-updates", n > 0);
    if (n > 0) updateBtn.title = window.t("updWaiting", { n: n });
    else updateBtn.removeAttribute("title");
  }

  function rememberUpdates(n) {
    markUpdates(n);
    lastCheck = Date.now();
    try {
      localStorage.setItem(UPD_SEEN, JSON.stringify({ at: lastCheck, n: n }));
    } catch (e) { /* private mode: the badge just won't survive a reload */ }
  }

  function stopWatching() {
    if (updTimer) { clearInterval(updTimer); updTimer = null; }
  }

  function quietCheck(force) {
    if (!updateBtn) return;
    if (!force && Date.now() - lastCheck < UPD_EVERY) return;
    lastCheck = Date.now();                  // claim the slot before the fetch
    fetch("/_update/check").then(function (r) { return r.json(); }).then(function (d) {
      // On the machine where the Vault is written there is nothing to watch
      // for, and no source configured means nowhere to look.
      if (!d.ok && (d.reason === "authoring" || d.reason === "no-source")) {
        stopWatching(); markUpdates(0); return;
      }
      rememberUpdates(d.ok ? d.added.length + d.changed.length : 0);
    }).catch(function () { /* offline: leave the button as it was */ });
  }

  // Show the last known answer straight away, then go and get a fresh one.
  try {
    var saved = JSON.parse(localStorage.getItem(UPD_SEEN) || "{}");
    if (saved.n != null) markUpdates(saved.n);
  } catch (e) { /* first run, or someone edited it by hand */ }
  quietCheck(true);
  updTimer = setInterval(quietCheck, UPD_EVERY);
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) quietCheck();     // back in the tab: is it still true?
  });

  if (applyBtn) {
    applyBtn.addEventListener("click", function () {
      say(window.t("updChecking"));
      fetch("/_update/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ files: pendingFiles })
      }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) { say(window.t("updFail")); return; }
        rememberUpdates(0);                      // nothing waiting any more
        var msg = window.t("updDone", { n: d.written.length });
        if (d.skipped && d.skipped.length) {
          msg += " " + window.t("updSkipped", { n: d.skipped.length });
        }
        say(msg, true);
        applyBtn.hidden = true;
      }).catch(function () { say(window.t("updFail")); });
    });
  }

  // A cover can have a per-language version (games.js "coverByLang", e.g.
  // { nl: "new_teletext_nl" } for the Dutch "Teletekst" box). Falls back to
  // the game's own id. A function, not a top-level var - see newsSeenKey().
  function coverId(g) {
    var m = g && g.coverByLang;
    var L = window.currentLang ? window.currentLang() : "en";
    return (m && m[L]) || g.id;
  }

  function applyLang() {
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      el.textContent = window.t(el.dataset.i18n);
    });
    // the long-form Setup text lives in setup-i18n.js and is HTML, not plain
    var pack = (window.SETUP_I18N || {})[window.currentLang()] || (window.SETUP_I18N || {}).en;
    if (pack) {
      document.querySelectorAll("[data-s]").forEach(function (el) {
        if (pack[el.dataset.s]) el.innerHTML = pack[el.dataset.s];
      });
      var exp = document.getElementById("exportFavs"), imp = document.getElementById("importFavs");
      if (exp) exp.textContent = window.t("exportFav");
      if (imp) imp.textContent = window.t("importFav");
    }
    searchInput.placeholder = window.t("search", { n: platformGames().length });
    document.getElementById("setupBtn").textContent = window.t("setup");
    document.documentElement.lang = window.currentLang();
  }

  var versionEl = document.getElementById("vaultVersion");
  if (versionEl) versionEl.textContent = "v" + VAULT_VERSION;

  var setupModal = document.getElementById("setupModal");
  document.getElementById("setupBtn").addEventListener("click", function () { setupModal.hidden = false; });
  document.getElementById("closeSetup").addEventListener("click", function () { setupModal.hidden = true; });
  setupModal.addEventListener("click", function (e) { if (e.target === setupModal) setupModal.hidden = true; });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !setupModal.hidden) setupModal.hidden = true; });
})();
