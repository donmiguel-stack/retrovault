window.GAMES_DATA = {
  "generated": "picopac catalogue",
  "count": 360,
  "games": [
  {
    "id": "new_amok_alt",
    "filename": "new_amok_alt.bin",
    "title": "Amok! (alternate build)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "alt-dump"
    ],
    "romFile": "Amok! (alternate build) (Alt).bin"
  },
  {
    "id": "new_amok",
    "filename": "new_amok.bin",
    "title": "Amok! (John Dondzila) — first famous O2 homebrew",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Amok! (John Dondzila) — first famous O2 homebrew.bin"
  },
  {
    "id": "new_bird-hunt",
    "filename": "new_bird-hunt.bin",
    "title": "Bird Hunt (Ahnl66)",
    "platform": "G7400+",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Bird Hunt (Ahnl66).bin"
  },
  {
    "id": "new_le-sprint",
    "filename": "new_le-sprint.bin",
    "title": "Le Sprint (kuoris-dev)",
    "platform": "G7400+",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Le Sprint (kuoris-dev).bin"
  },
  {
    "id": "new_calculator",
    "filename": "new_calculator.bin",
    "title": "Calculator (René van den Enden)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Calculator (René van den Enden).bin"
  },
  {
    "id": "new_helicopter_buzzword",
    "filename": "new_helicopter_buzzword.bin",
    "title": "Helicopter / Buzzword experiment",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Helicopter - Buzzword experiment.bin"
  },
  {
    "id": "new_jg-munchkin",
    "filename": "new_jg-munchkin.bin",
    "title": "JG Munchkin (homebrew Munchkin variant)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "JG Munchkin (homebrew Munchkin variant).bin"
  },
  {
    "id": "new_kc-pacvid",
    "filename": "new_kc-pacvid.bin",
    "title": "K.C. Pac / video variant",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "K.C. Pac - video variant.bin"
  },
  {
    "id": "new_kc-pacman",
    "filename": "new_kc-pacman.bin",
    "title": "K.C. Pac-Man style homebrew",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "K.C. Pac-Man style homebrew.bin"
  },
  {
    "id": "new_ktaa",
    "filename": "new_ktaa.bin",
    "title": "Kill the Attacking Aliens (Soeren Gust) — full",
    "platform": "G7400+",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Kill the Attacking Aliens (Soeren Gust) — full.bin"
  },
  {
    "id": "new_ktaa-demo1",
    "filename": "new_ktaa-demo1.bin",
    "title": "Kill the Attacking Aliens — demo 1",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Kill the Attacking Aliens — demo 1.bin"
  },
  {
    "id": "new_ktaa-demo2",
    "filename": "new_ktaa-demo2.bin",
    "title": "Kill the Attacking Aliens — demo 2",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Kill the Attacking Aliens — demo 2.bin"
  },
  {
    "id": "new_mrroboto",
    "filename": "new_mrroboto.bin",
    "title": "Mr Roboto (Ted Foolery)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Mr Roboto (Ted Foolery).bin"
  },
  {
    "id": "new_planet-lander",
    "filename": "new_planet-lander.bin",
    "title": "Planet Lander!",
    "platform": "G7400+",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Planet Lander! (G7400+).bin"
  },
  {
    "id": "new_pong_all",
    "filename": "new_pong_all.bin",
    "title": "Pong (all-in-one / extended)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Pong (all-in-one - extended).bin"
  },
  {
    "id": "new_pong",
    "filename": "new_pong.bin",
    "title": "Pong (René van den Enden)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Pong (René van den Enden).bin"
  },
  {
    "id": "new_puzzle-piece-panic",
    "filename": "new_puzzle-piece-panic.bin",
    "title": "Puzzle Piece Panic",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Puzzle Piece Panic.bin"
  },
  {
    "id": "new_ppp-o2em",
    "filename": "new_ppp-o2em.bin",
    "title": "Puzzle Piece Panic (o2em build)",
    "platform": "G7000",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Puzzle Piece Panic (o2em build).bin"
  },
  {
    "id": "new_route66",
    "filename": "new_route66.bin",
    "title": "Route 66 (Rafael Cardoso)",
    "platform": "G7400+",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Route 66 (Rafael Cardoso).bin"
  },
  {
    "id": "new_teletext",
    "filename": "new_teletext.html",
    "title": "Teletext",
    "platform": "G7400+",
    "category": "Homebrew (this project)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "teletext-vault.bin",
    "coverByLang": {
      "nl": "new_teletext_nl"
    }
  },
  {
    "id": "im_atlantis",
    "filename": "im_atlantis.bin",
    "title": "Atlantis",
    "platform": "G7000",
    "category": "Imagic",
    "vpNumber": null,
    "tags": [],
    "romFile": "Atlantis.bin"
  },
  {
    "id": "im_demon-attack",
    "filename": "im_demon-attack.bin",
    "title": "Demon Attack",
    "platform": "G7000",
    "category": "Imagic",
    "vpNumber": null,
    "tags": [],
    "romFile": "Demon Attack.bin"
  },
  {
    "id": "jo_basket-bowling_pl",
    "filename": "jo_basket-bowling_pl.bin",
    "title": "Basket / Bowling (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Basket - Bowling (Plus) (G7400+).bin"
  },
  {
    "id": "jo_billard_pl",
    "filename": "jo_billard_pl.bin",
    "title": "Billard (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Billard (Plus) (G7400+).bin"
  },
  {
    "id": "jo_chez-maxime",
    "filename": "jo_chez-maxime.bin",
    "title": "Chez Maxime",
    "platform": "G7000",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Chez Maxime.bin"
  },
  {
    "id": "jo_demon-attack_pl",
    "filename": "jo_demon-attack_pl.bin",
    "title": "Demon Attack+ (Jopac, Plus-enhanced French)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics",
      "french"
    ],
    "romFile": "Demon Attack (Plus-enhanced French) (G7400+, FR).bin"
  },
  {
    "id": "jo_exojet_pl",
    "filename": "jo_exojet_pl.bin",
    "title": "Exojet+ (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Exojet+ (Plus) (G7400+).bin"
  },
  {
    "id": "jo_flipper_pl",
    "filename": "jo_flipper_pl.bin",
    "title": "Flipper / Pinball (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Flipper - Pinball (Plus) (G7400+).bin"
  },
  {
    "id": "jo_le-tresor-englouti_pl",
    "filename": "jo_le-tresor-englouti_pl.bin",
    "title": "Le Trésor Englouti (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Le Trésor Englouti (Plus) (G7400+).bin"
  },
  {
    "id": "jo_moto-crash_pl",
    "filename": "jo_moto-crash_pl.bin",
    "title": "Moto-Crash+ (Plus)",
    "platform": "G7400+",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Moto-Crash+ (Plus) (G7400+).bin"
  },
  {
    "id": "jo_syracuse",
    "filename": "jo_syracuse.bin",
    "title": "Syracuse",
    "platform": "G7000",
    "category": "Jopac (French)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Syracuse.bin"
  },
  {
    "id": "mod_br21_fix",
    "filename": "mod_br21_fix.bin",
    "title": "Secret of the Pharaohs; Brazilian mod",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": null,
    "tags": [
      "community-modified"
    ],
    "romFile": "Brazilian #21 related fix - Comando-style pack fix (Alt, Mod).bin"
  },
  {
    "id": "mod_vp9_examples",
    "filename": "mod_vp9_examples.bin",
    "title": "Computer Programmer (VP9) examples / teaching cart",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "9",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP9 - Computer Programmer (VP9) examples - teaching cart (G7400+, Mod).bin"
  },
  {
    "id": "mod_demon-attack_pl",
    "filename": "mod_demon-attack_pl.bin",
    "title": "Demon Attack (modified / Plus)",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": null,
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "Demon Attack (modified - Plus) (G7400+, Mod).bin"
  },
  {
    "id": "mod_01pl",
    "filename": "mod_01pl.bin",
    "title": "Mod of VP#01: Race / Spin-Out / Cryptogram",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "01",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP01 - Mod of VP#01 Race - Spin-Out - Cryptogram (G7400+, Mod).bin"
  },
  {
    "id": "mod_05_g7400",
    "filename": "mod_05_g7400.bin",
    "title": "Mod of VP#05: Blackjack",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "05",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP05 - Mod of VP#05 Blackjack (Mod).bin"
  },
  {
    "id": "mod_06pl",
    "filename": "mod_06pl.bin",
    "title": "Mod of VP#06: Tenpin Bowling / Basketball",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "06",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP06 - Mod of VP#06 Tenpin Bowling - Basketball (G7400+, Mod).bin"
  },
  {
    "id": "mod_11pl",
    "filename": "mod_11pl.bin",
    "title": "Mod of VP#11: Cosmic Conflict",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "11",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP11 - Mod of VP#11 Cosmic Conflict (G7400+, Mod).bin"
  },
  {
    "id": "mod_14fix",
    "filename": "mod_14fix.bin",
    "title": "Mod of VP#14: Gunfighter",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "14",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP14 - Mod of VP#14 Gunfighter (Alt, Mod).bin"
  },
  {
    "id": "mod_19_g7400",
    "filename": "mod_19_g7400.bin",
    "title": "Mod of VP#19: Catch the Ball / Noughts and Crosses",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "19",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP19 - Mod of VP#19 Catch the Ball - Noughts and Crosses (Mod).bin"
  },
  {
    "id": "mod_20pl",
    "filename": "mod_20pl.bin",
    "title": "Mod of VP#20: Stone Sling",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "20",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP20 - Mod of VP#20 Stone Sling (G7400+, Mod).bin"
  },
  {
    "id": "mod_24pl",
    "filename": "mod_24pl.bin",
    "title": "Mod of VP#24: Flipper (Pinball)",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "24",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP24 - Mod of VP#24 Flipper (Pinball) (G7400+, Mod).bin"
  },
  {
    "id": "mod_28fix",
    "filename": "mod_28fix.bin",
    "title": "Mod of VP#28: Electronic Volleyball",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "28",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP28 - Mod of VP#28 Electronic Volleyball (Alt, Mod).bin"
  },
  {
    "id": "mod_30fix",
    "filename": "mod_30fix.bin",
    "title": "Mod of VP#30: Battlefield",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "30",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP30 - Mod of VP#30 Battlefield (Alt, Mod).bin"
  },
  {
    "id": "mod_31_g7400",
    "filename": "mod_31_g7400.bin",
    "title": "Mod of VP#31: Musician",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "31",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP31 - Mod of VP#31 Musician (Mod).bin"
  },
  {
    "id": "mod_35pl_fix",
    "filename": "mod_35pl_fix.bin",
    "title": "Mod of VP#35: Electronic Billiards",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "35",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP35 - Mod of VP#35 Electronic Billiards (G7400+, Alt, Mod).bin"
  },
  {
    "id": "mod_36fix",
    "filename": "mod_36fix.bin",
    "title": "Mod of VP#36: Electronic Soccer / Ice Hockey",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "36",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP36 - Mod of VP#36 Electronic Soccer - Ice Hockey (Alt, Mod).bin"
  },
  {
    "id": "mod_40_g7400",
    "filename": "mod_40_g7400.bin",
    "title": "Mod of VP#40: 4 in 1 Row",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": "40",
    "tags": [
      "community-modified"
    ],
    "romFile": "VP40 - Mod of VP#40 4 in 1 Row (Mod).bin"
  },
  {
    "id": "mod_43pl",
    "filename": "mod_43pl.bin",
    "title": "Mod of VP#43: Pickaxe Pete",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "43",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP43 - Mod of VP#43 Pickaxe Pete (G7400+, Mod).bin"
  },
  {
    "id": "mod_55pl",
    "filename": "mod_55pl.bin",
    "title": "Mod of VP#55: Neutron Star",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "55",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP55 - Mod of VP#55 Neutron Star (G7400+, Mod).bin"
  },
  {
    "id": "mod_moto-crash_g7000",
    "filename": "mod_moto-crash_g7000.bin",
    "title": "Moto-Crash (modified for G7000)",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": null,
    "tags": [
      "community-modified"
    ],
    "romFile": "Moto-Crash (modified for G7000) (Mod).bin"
  },
  {
    "id": "mod_vp31_examples",
    "filename": "mod_vp31_examples.bin",
    "title": "Musician (VP31) code examples / teaching cart",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": "31",
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "VP31 - Musician (VP31) code examples - teaching cart (G7400+, Mod).bin"
  },
  {
    "id": "mod_playtag_fix",
    "filename": "mod_playtag_fix.bin",
    "title": "Playtag (fixed)",
    "platform": "G7400+",
    "category": "Modified / fixed",
    "vpNumber": null,
    "tags": [
      "plus-graphics",
      "community-modified"
    ],
    "romFile": "Playtag (fixed) (G7400+, Alt, Mod).bin"
  },
  {
    "id": "mod_tutankham_fix",
    "filename": "mod_tutankham_fix.bin",
    "title": "Tutankham (fixed)",
    "platform": "G7000",
    "category": "Modified / fixed",
    "vpNumber": null,
    "tags": [
      "community-modified"
    ],
    "romFile": "Tutankham (fixed) (Alt, Mod).bin"
  },
  {
    "id": "o2_40",
    "filename": "o2_40.bin",
    "title": "Type & Tell! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Type & Tell! (US).bin"
  },
  {
    "id": "o2_48",
    "filename": "o2_48.bin",
    "title": "Power Lords (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Power Lords (US).bin"
  },
  {
    "id": "o2_48alt",
    "filename": "o2_48alt.bin",
    "title": "Power Lords (US, 8K dump)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [
      "alt-dump"
    ],
    "romFile": "Backgammon - related (alt = alternate dump) (Alt).bin"
  },
  {
    "id": "o2_30",
    "filename": "o2_30.bin",
    "title": "UFO! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "UFO! (US).bin"
  },
  {
    "id": "o2_06",
    "filename": "o2_06.bin",
    "title": "Computer Intro! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Computer Intro! (US).bin"
  },
  {
    "id": "o2_19",
    "filename": "o2_19.bin",
    "title": "Out of this World! / Helicopter Rescue! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Out of this World! - Helicopter Rescue! (US).bin"
  },
  {
    "id": "o2_10",
    "filename": "o2_10.bin",
    "title": "Computer Golf! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Computer Golf! (US).bin"
  },
  {
    "id": "o2_41",
    "filename": "o2_41.bin",
    "title": "Smithereens! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Smithereens! (US).bin"
  },
  {
    "id": "o2_11",
    "filename": "o2_11.bin",
    "title": "Cosmic Conflict! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Cosmic Conflict! (US).bin"
  },
  {
    "id": "o2_16",
    "filename": "o2_16.bin",
    "title": "Showdown in 2100 A.D. (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Showdown in 2100 A.D. (US).bin"
  },
  {
    "id": "o2_39",
    "filename": "o2_39.bin",
    "title": "Nimble Numbers Ned! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Nimble Numbers Ned! (US).bin"
  },
  {
    "id": "o2_38",
    "filename": "o2_38.bin",
    "title": "Sid the Spellbinder! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Sid the Spellbinder! (US).bin"
  },
  {
    "id": "o2_07",
    "filename": "o2_07.bin",
    "title": "Matchmaker! / Buzzword! / Logix! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Matchmaker! - Buzzword! - Logix! (US).bin"
  },
  {
    "id": "o2_45",
    "filename": "o2_45.bin",
    "title": "Attack of the Timelord! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Attack of the Timelord! (US).bin"
  },
  {
    "id": "o2_33",
    "filename": "o2_33.bin",
    "title": "Keyboard Creations! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Keyboard Creations! (US).bin"
  },
  {
    "id": "o2_43",
    "filename": "o2_43.bin",
    "title": "P.T. Barnum's Acrobats! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "P.T. Barnum's Acrobats! (US).bin"
  },
  {
    "id": "o2_35",
    "filename": "o2_35.bin",
    "title": "K.C. Munchkin! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "K.C. Munchkin! (US).bin"
  },
  {
    "id": "o2_21",
    "filename": "o2_21.bin",
    "title": "Dynasty! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Dynasty! (US).bin"
  },
  {
    "id": "o2_14",
    "filename": "o2_14.bin",
    "title": "Invaders from Hyperspace! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Invaders from Hyperspace! (US).bin"
  },
  {
    "id": "o2_46",
    "filename": "o2_46.bin",
    "title": "Turtles! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Turtles! (US).bin"
  },
  {
    "id": "o2_47",
    "filename": "o2_47.bin",
    "title": "Killer Bees! (US)",
    "platform": "G7000",
    "category": "Official Odyssey2 (US)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Killer Bees! (US).bin"
  },
  {
    "id": "vp_49",
    "filename": "vp_49.bin",
    "title": "Turtles (EU)",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "49",
    "tags": [],
    "romFile": "Turtles (EU).bin"
  },
  {
    "id": "vp_40",
    "filename": "vp_40.bin",
    "title": "4 in 1 Row",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "40",
    "tags": [],
    "romFile": "VP40 - 4 in 1 Row.bin"
  },
  {
    "id": "vp_58_12",
    "filename": "vp_58_12.bin",
    "title": "Air Battle",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "58",
    "tags": [
      "banked-rom"
    ],
    "romFile": "VP58 - Air Battle (16K).bin"
  },
  {
    "id": "vp_04",
    "filename": "vp_04.bin",
    "title": "Air-Sea War / Battle",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "04",
    "tags": [],
    "romFile": "VP04 - Air-Sea War - Battle.bin"
  },
  {
    "id": "vp_03",
    "filename": "vp_03.bin",
    "title": "American Football",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "03",
    "tags": [],
    "romFile": "VP03 - American Football.bin"
  },
  {
    "id": "vp_48",
    "filename": "vp_48.bin",
    "title": "Backgammon",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "48",
    "tags": [],
    "romFile": "VP48 - Backgammon.bin"
  },
  {
    "id": "vp_08",
    "filename": "vp_08.bin",
    "title": "Baseball",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "08",
    "tags": [],
    "romFile": "VP08 - Baseball.bin"
  },
  {
    "id": "vp_26",
    "filename": "vp_26.bin",
    "title": "Basket Game",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "26",
    "tags": [],
    "romFile": "VP26 - Basket Game.bin"
  },
  {
    "id": "vp_30",
    "filename": "vp_30.bin",
    "title": "Battlefield",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "30",
    "tags": [],
    "romFile": "VP30 - Battlefield.bin"
  },
  {
    "id": "vp_05",
    "filename": "vp_05.bin",
    "title": "Blackjack",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "05",
    "tags": [],
    "romFile": "VP05 - Blackjack.bin"
  },
  {
    "id": "vp_57",
    "filename": "vp_57.bin",
    "title": "Blobbers",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "57",
    "tags": [],
    "romFile": "VP57 - Blobbers.bin"
  },
  {
    "id": "vp_19",
    "filename": "vp_19.bin",
    "title": "Catch the Ball / Noughts and Crosses",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "19",
    "tags": [],
    "romFile": "VP19 - Catch the Ball - Noughts and Crosses.bin"
  },
  {
    "id": "vp_17",
    "filename": "vp_17.bin",
    "title": "Chinese Logic",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "17",
    "tags": [],
    "romFile": "VP17 - Chinese Logic.bin"
  },
  {
    "id": "vp_09",
    "filename": "vp_09.bin",
    "title": "Computer Programmer",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "09",
    "tags": [],
    "romFile": "VP09 - Computer Programmer.bin"
  },
  {
    "id": "vp_41",
    "filename": "vp_41.bin",
    "title": "Conquest of the World",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "41",
    "tags": [],
    "romFile": "VP41 - Conquest of the World.bin"
  },
  {
    "id": "vp_11",
    "filename": "vp_11.bin",
    "title": "Cosmic Conflict",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "11",
    "tags": [],
    "romFile": "VP11 - Cosmic Conflict.bin"
  },
  {
    "id": "vp_11alt",
    "filename": "vp_11alt.bin",
    "title": "Cosmic Conflict",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "11",
    "tags": [
      "alt-dump"
    ],
    "romFile": "VP11 - Cosmic Conflict (Alt).bin"
  },
  {
    "id": "vp_11pl",
    "filename": "vp_11pl.bin",
    "title": "Cosmic Conflict",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "11",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP11 - Cosmic Conflict (G7400+).bin"
  },
  {
    "id": "vp_44",
    "filename": "vp_44.bin",
    "title": "Crazy Chase",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "44",
    "tags": [],
    "romFile": "VP44 - Crazy Chase.bin"
  },
  {
    "id": "vp_29",
    "filename": "vp_29.bin",
    "title": "Dam Buster",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "29",
    "tags": [],
    "romFile": "VP29 - Dam Buster.bin"
  },
  {
    "id": "vp_16",
    "filename": "vp_16.bin",
    "title": "Depth Charge / Marksman",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "16",
    "tags": [],
    "romFile": "VP16 - Depth Charge - Marksman (Banked).bin"
  },
  {
    "id": "vp_35",
    "filename": "vp_35.bin",
    "title": "Electronic Billiards",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "35",
    "tags": [],
    "romFile": "VP35 - Electronic Billiards.bin"
  },
  {
    "id": "vp_35pl",
    "filename": "vp_35pl.bin",
    "title": "Electronic Billiards",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "35",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP35 - Electronic Billiards (G7400+).bin"
  },
  {
    "id": "vp_36",
    "filename": "vp_36.bin",
    "title": "Electronic Soccer / Ice Hockey",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "36",
    "tags": [],
    "romFile": "VP36 - Electronic Soccer - Ice Hockey.bin"
  },
  {
    "id": "vp_27",
    "filename": "vp_27.bin",
    "title": "Electronic Table Football",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "27",
    "tags": [],
    "romFile": "VP27 - Electronic Table Football.bin"
  },
  {
    "id": "vp_28",
    "filename": "vp_28.bin",
    "title": "Electronic Volleyball",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "28",
    "tags": [],
    "romFile": "VP28 - Electronic Volleyball.bin"
  },
  {
    "id": "vp_24",
    "filename": "vp_24.bin",
    "title": "Flipper (Pinball)",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "24",
    "tags": [],
    "romFile": "VP24 - Flipper (Pinball).bin"
  },
  {
    "id": "vp_24pl",
    "filename": "vp_24pl.bin",
    "title": "Flipper (Pinball)",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "24",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP24 - Flipper (Pinball) (G7400+).bin"
  },
  {
    "id": "vp_39",
    "filename": "vp_39.bin",
    "title": "Freedom Fighters",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "39",
    "tags": [],
    "romFile": "VP39 - Freedom Fighters.bin"
  },
  {
    "id": "vp_39pl",
    "filename": "vp_39pl.bin",
    "title": "Freedom Fighters",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "39",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP39 - Freedom Fighters (G7400+).bin"
  },
  {
    "id": "vp_10",
    "filename": "vp_10.bin",
    "title": "Golf",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "10",
    "tags": [],
    "romFile": "VP10 - Golf.bin"
  },
  {
    "id": "vp_14",
    "filename": "vp_14.bin",
    "title": "Gunfighter",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "14",
    "tags": [],
    "romFile": "VP14 - Gunfighter.bin"
  },
  {
    "id": "vp_59_16",
    "filename": "vp_59_16.bin",
    "title": "Helicopter Rescue",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "59",
    "tags": [
      "banked-rom"
    ],
    "romFile": "VP59 - Helicopter Rescue (Banked).bin"
  },
  {
    "id": "vp_13",
    "filename": "vp_13.bin",
    "title": "I've Got Your Number / Playschool Maths",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "13",
    "tags": [],
    "romFile": "VP13 - I've Got Your Number - Playschool Maths.bin"
  },
  {
    "id": "vp_33",
    "filename": "vp_33.bin",
    "title": "Jumping Acrobats",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "33",
    "tags": [],
    "romFile": "VP33 - Jumping Acrobats.bin"
  },
  {
    "id": "vp_33alt",
    "filename": "vp_33alt.bin",
    "title": "Jumping Acrobats",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "33",
    "tags": [
      "alt-dump"
    ],
    "romFile": "VP33 - Jumping Acrobats (Alt).bin"
  },
  {
    "id": "vp_a",
    "filename": "vp_a.bin",
    "title": "Keyboard Creations! / Newscaster (cart A)",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Keyboard Creations! - Newscaster (cart A).bin"
  },
  {
    "id": "vp_52pl",
    "filename": "vp_52pl.bin",
    "title": "Killer Bees",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "52",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP52 - Killer Bees (G7400+).bin"
  },
  {
    "id": "vp_32",
    "filename": "vp_32.bin",
    "title": "Labyrinth / Supermind",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "32",
    "tags": [],
    "romFile": "VP32 - Labyrinth - Supermind.bin"
  },
  {
    "id": "vp_23",
    "filename": "vp_23.bin",
    "title": "Las Vegas Gambling",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "23",
    "tags": [],
    "romFile": "VP23 - Las Vegas Gambling.bin"
  },
  {
    "id": "vp_18",
    "filename": "vp_18.bin",
    "title": "Laser War",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "18",
    "tags": [],
    "romFile": "VP18 - Laser War.bin"
  },
  {
    "id": "vp_54",
    "filename": "vp_54.bin",
    "title": "Loony Balloon",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "54",
    "tags": [],
    "romFile": "VP54 - Loony Balloon.bin"
  },
  {
    "id": "vp_54pl",
    "filename": "vp_54pl.bin",
    "title": "Loony Balloon",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "54",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP54 - Loony Balloon (G7400+).bin"
  },
  {
    "id": "vp_07",
    "filename": "vp_07.bin",
    "title": "Mathematician / Echo",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "07",
    "tags": [],
    "romFile": "VP07 - Mathematician - Echo.bin"
  },
  {
    "id": "vp_37",
    "filename": "vp_37.bin",
    "title": "Monkeyshines",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "37",
    "tags": [],
    "romFile": "VP37 - Monkeyshines.bin"
  },
  {
    "id": "vp_45",
    "filename": "vp_45.bin",
    "title": "Morse",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "45",
    "tags": [],
    "romFile": "VP45 - Morse.bin"
  },
  {
    "id": "vp_38",
    "filename": "vp_38.bin",
    "title": "Munchkin",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "38",
    "tags": [],
    "romFile": "VP38 - Munchkin.bin"
  },
  {
    "id": "vp_31",
    "filename": "vp_31.bin",
    "title": "Musician",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "31",
    "tags": [],
    "romFile": "VP31 - Musician.bin"
  },
  {
    "id": "vp_55",
    "filename": "vp_55.bin",
    "title": "Neutron Star",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "55",
    "tags": [],
    "romFile": "VP55 - Neutron Star.bin"
  },
  {
    "id": "vp_55_12",
    "filename": "vp_55_12.bin",
    "title": "Neutron Star",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "55",
    "tags": [
      "banked-rom"
    ],
    "romFile": "VP55 - Neutron Star (16K).bin"
  },
  {
    "id": "vp_55_12fix",
    "filename": "vp_55_12fix.bin",
    "title": "Neutron Star",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "55",
    "tags": [
      "alt-dump"
    ],
    "romFile": "VP55 - Neutron Star (Alt 16K).bin"
  },
  {
    "id": "vp_53",
    "filename": "vp_53.bin",
    "title": "Nightmare",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "53",
    "tags": [],
    "romFile": "VP53 - Nightmare.bin"
  },
  {
    "id": "vp_53pl",
    "filename": "vp_53pl.bin",
    "title": "Nightmare",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "53",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP53 - Nightmare (G7400+).bin"
  },
  {
    "id": "vp_56pl",
    "filename": "vp_56pl.bin",
    "title": "Norseman",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "56",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP56 - Norseman (G7400+).bin"
  },
  {
    "id": "vp_02",
    "filename": "vp_02.bin",
    "title": "Pairs / Space Rendezvous / Logic",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "02",
    "tags": [],
    "romFile": "VP02 - Pairs - Space Rendezvous - Logic.bin"
  },
  {
    "id": "vp_43",
    "filename": "vp_43.bin",
    "title": "Pickaxe Pete",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "43",
    "tags": [],
    "romFile": "VP43 - Pickaxe Pete.bin"
  },
  {
    "id": "vp_43pl",
    "filename": "vp_43pl.bin",
    "title": "Pickaxe Pete",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "43",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP43 - Pickaxe Pete (G7400+).bin"
  },
  {
    "id": "vp_42",
    "filename": "vp_42.bin",
    "title": "Quest for the Rings",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "42",
    "tags": [],
    "romFile": "VP42 - Quest for the Rings.bin"
  },
  {
    "id": "vp_01",
    "filename": "vp_01.bin",
    "title": "Race / Spin-Out / Cryptogram",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "01",
    "tags": [],
    "romFile": "VP01 - Race - Spin-Out - Cryptogram.bin"
  },
  {
    "id": "vp_01hack",
    "filename": "vp_01hack.bin",
    "title": "Race / Spin-Out / Cryptogram",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "01",
    "tags": [
      "alt-dump"
    ],
    "romFile": "VP01 - Race - Spin-Out - Cryptogram (Alt).bin"
  },
  {
    "id": "vp_01pl",
    "filename": "vp_01pl.bin",
    "title": "Race / Spin-Out / Cryptogram",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "01",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP01 - Race - Spin-Out - Cryptogram (G7400+).bin"
  },
  {
    "id": "vp_15",
    "filename": "vp_15.bin",
    "title": "Samurai",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "15",
    "tags": [],
    "romFile": "VP15 - Samurai.bin"
  },
  {
    "id": "vp_34",
    "filename": "vp_34.bin",
    "title": "Satellite Attack",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "34",
    "tags": [],
    "romFile": "VP34 - Satellite Attack.bin"
  },
  {
    "id": "vp_34pl",
    "filename": "vp_34pl.bin",
    "title": "Satellite Attack",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "34",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP34 - Satellite Attack (G7400+).bin"
  },
  {
    "id": "vp_21",
    "filename": "vp_21.bin",
    "title": "Secret of the Pharaohs",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "21",
    "tags": [],
    "romFile": "VP21 - Secret of the Pharaohs.bin"
  },
  {
    "id": "vp_25",
    "filename": "vp_25.bin",
    "title": "Skiing",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "25",
    "tags": [],
    "romFile": "VP25 - Skiing.bin"
  },
  {
    "id": "vp_22",
    "filename": "vp_22.bin",
    "title": "Space Monster / Alien Invaders",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "22",
    "tags": [],
    "romFile": "VP22 - Space Monster - Alien Invaders.bin"
  },
  {
    "id": "vp_22hack",
    "filename": "vp_22hack.bin",
    "title": "Space Monster / Alien Invaders",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "22",
    "tags": [
      "alt-dump"
    ],
    "romFile": "VP22 - Space Monster - Alien Invaders (Alt).bin"
  },
  {
    "id": "vp_20",
    "filename": "vp_20.bin",
    "title": "Stone Sling",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "20",
    "tags": [],
    "romFile": "VP20 - Stone Sling.bin"
  },
  {
    "id": "vp_20pl",
    "filename": "vp_20pl.bin",
    "title": "Stone Sling",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "20",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP20 - Stone Sling (G7400+).bin"
  },
  {
    "id": "vp_50",
    "filename": "vp_50.bin",
    "title": "Super Bee",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "50",
    "tags": [],
    "romFile": "VP50 - Super Bee.bin"
  },
  {
    "id": "vp_06",
    "filename": "vp_06.bin",
    "title": "Tenpin Bowling / Basketball",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "06",
    "tags": [],
    "romFile": "VP06 - Tenpin Bowling - Basketball.bin"
  },
  {
    "id": "vp_06pl",
    "filename": "vp_06pl.bin",
    "title": "Tenpin Bowling / Basketball",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "06",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP06 - Tenpin Bowling - Basketball (G7400+).bin"
  },
  {
    "id": "vp_51pl",
    "filename": "vp_51pl.bin",
    "title": "Terrahawks / Attack of the Timelord",
    "platform": "G7400+",
    "category": "Official Videopac (EU)",
    "vpNumber": "51",
    "tags": [
      "plus-graphics"
    ],
    "romFile": "VP51 - Terrahawks - Attack of the Timelord (G7400+).bin"
  },
  {
    "id": "vp_46",
    "filename": "vp_46.bin",
    "title": "The Great Wall Street Fortune Hunt",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "46",
    "tags": [],
    "romFile": "VP46 - The Great Wall Street Fortune Hunt.bin"
  },
  {
    "id": "vp_47",
    "filename": "vp_47.bin",
    "title": "The Mousing Cat",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "47",
    "tags": [],
    "romFile": "VP47 - The Mousing Cat.bin"
  },
  {
    "id": "vp_60_16",
    "filename": "vp_60_16.bin",
    "title": "Trans American Rally",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "60",
    "tags": [
      "banked-rom"
    ],
    "romFile": "VP60 - Trans American Rally (Banked).bin"
  },
  {
    "id": "vp_12",
    "filename": "vp_12.bin",
    "title": "Take the Money and Run (EU)",
    "platform": "G7000",
    "category": "Official Videopac (EU)",
    "vpNumber": "12",
    "tags": [],
    "romFile": "Take the Money and Run (EU).bin"
  },
  {
    "id": "Vp40_F",
    "filename": "Vp40_F.bin",
    "title": "4 in 1 Row",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "40",
    "tags": [
      "french"
    ],
    "romFile": "VP40 - 4 in 1 Row (FR).bin"
  },
  {
    "id": "Vp05_F",
    "filename": "Vp05_F.bin",
    "title": "Blackjack",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "05",
    "tags": [
      "french"
    ],
    "romFile": "VP05 - Blackjack (FR).bin"
  },
  {
    "id": "Vp11+_F",
    "filename": "Vp11+_F.bin",
    "title": "Cosmic Conflict",
    "platform": "G7400+",
    "category": "Official Videopac (French)",
    "vpNumber": "11",
    "tags": [
      "plus-graphics",
      "french"
    ],
    "romFile": "VP11 - Cosmic Conflict (G7400+, FR).bin"
  },
  {
    "id": "Vp11_F",
    "filename": "Vp11_F.bin",
    "title": "Cosmic Conflict",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "11",
    "tags": [
      "french"
    ],
    "romFile": "VP11 - Cosmic Conflict (FR).bin"
  },
  {
    "id": "Vp29_F",
    "filename": "Vp29_F.bin",
    "title": "Dam Buster",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "29",
    "tags": [
      "french"
    ],
    "romFile": "VP29 - Dam Buster (FR).bin"
  },
  {
    "id": "Vp35_F",
    "filename": "Vp35_F.bin",
    "title": "Electronic Billiards",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "35",
    "tags": [
      "french"
    ],
    "romFile": "VP35 - Electronic Billiards (FR).bin"
  },
  {
    "id": "Vp36_F",
    "filename": "Vp36_F.bin",
    "title": "Electronic Soccer / Ice Hockey",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "36",
    "tags": [
      "french"
    ],
    "romFile": "VP36 - Electronic Soccer - Ice Hockey (FR).bin"
  },
  {
    "id": "Vp28_F",
    "filename": "Vp28_F.bin",
    "title": "Electronic Volleyball",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "28",
    "tags": [
      "french"
    ],
    "romFile": "VP28 - Electronic Volleyball (FR).bin"
  },
  {
    "id": "Vp24_F",
    "filename": "Vp24_F.bin",
    "title": "Flipper (Pinball)",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "24",
    "tags": [
      "french"
    ],
    "romFile": "VP24 - Flipper (Pinball) (FR).bin"
  },
  {
    "id": "Vp52+_F",
    "filename": "Vp52+_F.bin",
    "title": "Killer Bees",
    "platform": "G7400+",
    "category": "Official Videopac (French)",
    "vpNumber": "52",
    "tags": [
      "plus-graphics",
      "french"
    ],
    "romFile": "VP52 - Killer Bees (G7400+, FR).bin"
  },
  {
    "id": "Vp23_F",
    "filename": "Vp23_F.bin",
    "title": "Las Vegas Gambling",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "23",
    "tags": [
      "french"
    ],
    "romFile": "VP23 - Las Vegas Gambling (FR).bin"
  },
  {
    "id": "Vp18_F",
    "filename": "Vp18_F.bin",
    "title": "Laser War",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "18",
    "tags": [
      "french"
    ],
    "romFile": "VP18 - Laser War (FR).bin"
  },
  {
    "id": "Vp07_F",
    "filename": "Vp07_F.bin",
    "title": "Mathematician / Echo",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "07",
    "tags": [
      "french"
    ],
    "romFile": "VP07 - Mathematician - Echo (FR).bin"
  },
  {
    "id": "Vp45_F",
    "filename": "Vp45_F.bin",
    "title": "Morse",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "45",
    "tags": [
      "french"
    ],
    "romFile": "VP45 - Morse (FR).bin"
  },
  {
    "id": "Vp42_F",
    "filename": "Vp42_F.bin",
    "title": "Quest for the Rings",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "42",
    "tags": [
      "french"
    ],
    "romFile": "VP42 - Quest for the Rings (FR).bin"
  },
  {
    "id": "vp01+_F",
    "filename": "vp01+_F.bin",
    "title": "Race / Spin-Out / Cryptogram",
    "platform": "G7400+",
    "category": "Official Videopac (French)",
    "vpNumber": "01",
    "tags": [
      "plus-graphics",
      "french"
    ],
    "romFile": "VP01 - Race - Spin-Out - Cryptogram (G7400+, FR).bin"
  },
  {
    "id": "Vp01_F",
    "filename": "Vp01_F.bin",
    "title": "Race / Spin-Out / Cryptogram",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "01",
    "tags": [
      "french"
    ],
    "romFile": "VP01 - Race - Spin-Out - Cryptogram (FR).bin"
  },
  {
    "id": "Vp25_F",
    "filename": "Vp25_F.bin",
    "title": "Skiing",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "25",
    "tags": [
      "french"
    ],
    "romFile": "VP25 - Skiing (FR).bin"
  },
  {
    "id": "Vp06_F",
    "filename": "Vp06_F.bin",
    "title": "Tenpin Bowling / Basketball",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "06",
    "tags": [
      "french"
    ],
    "romFile": "VP06 - Tenpin Bowling - Basketball (FR).bin"
  },
  {
    "id": "Vp47_F",
    "filename": "Vp47_F.bin",
    "title": "The Mousing Cat",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "47",
    "tags": [
      "french"
    ],
    "romFile": "VP47 - The Mousing Cat (FR).bin"
  },
  {
    "id": "Vp12_F",
    "filename": "Vp12_F.bin",
    "title": "Prendre l'Argent et Fuir / Take the Money and Run (France)",
    "platform": "G7000",
    "category": "Official Videopac (French)",
    "vpNumber": "12",
    "tags": [
      "french"
    ],
    "romFile": "Prendre l'Argent et Fuir - Take the Money and Run (France).bin"
  },
  {
    "id": "pal_flashpoint",
    "filename": "pal_flashpoint.bin",
    "title": "Flash Point (PAL conversion)",
    "platform": "G7000",
    "category": "PAL dumps",
    "vpNumber": null,
    "tags": [],
    "romFile": "Flash Point (PAL conversion).bin"
  },
  {
    "id": "pal_acrobats",
    "filename": "pal_acrobats.bin",
    "title": "Jumping Acrobats / P.T. Barnum's Acrobats",
    "platform": "G7000",
    "category": "PAL dumps",
    "vpNumber": null,
    "tags": [],
    "romFile": "Jumping Acrobats - P.T. Barnum's Acrobats.bin"
  },
  {
    "id": "pal_nimble-numbers-ned",
    "filename": "pal_nimble-numbers-ned.bin",
    "title": "Nimble Numbers Ned! (Voice-era educational)",
    "platform": "G7000",
    "category": "PAL dumps",
    "vpNumber": null,
    "tags": [],
    "romFile": "Nimble Numbers Ned! (Voice-era educational).bin"
  },
  {
    "id": "pal_type-and-tell",
    "filename": "pal_type-and-tell.bin",
    "title": "Type & Tell (keyboard/voice-era)",
    "platform": "G7000",
    "category": "PAL dumps",
    "vpNumber": null,
    "tags": [],
    "romFile": "Type & Tell (keyboard-voice-era).bin"
  },
  {
    "id": "pb_frogger",
    "filename": "pb_frogger.bin",
    "title": "Frogger",
    "platform": "G7000",
    "category": "Parker Brothers",
    "vpNumber": null,
    "tags": [],
    "romFile": "Frogger.bin"
  },
  {
    "id": "pb_popeye",
    "filename": "pb_popeye.bin",
    "title": "Popeye",
    "platform": "G7000",
    "category": "Parker Brothers",
    "vpNumber": null,
    "tags": [],
    "romFile": "Popeye.bin"
  },
  {
    "id": "pb_q-bert",
    "filename": "pb_q-bert.bin",
    "title": "Q*bert",
    "platform": "G7000",
    "category": "Parker Brothers",
    "vpNumber": null,
    "tags": [],
    "romFile": "Qbert.bin"
  },
  {
    "id": "pb_super-cobra",
    "filename": "pb_super-cobra.bin",
    "title": "Super Cobra",
    "platform": "G7000",
    "category": "Parker Brothers",
    "vpNumber": null,
    "tags": [],
    "romFile": "Super Cobra.bin"
  },
  {
    "id": "pr_clay-pigeon_pl",
    "filename": "pr_clay-pigeon_pl.bin",
    "title": "Clay Pigeon! (Plus)",
    "platform": "G7400+",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Clay Pigeon! (Plus) (G7400+).bin"
  },
  {
    "id": "pr_clay-pigeon_pl_alt",
    "filename": "pr_clay-pigeon_pl_alt.bin",
    "title": "Clay Pigeon! (Plus, alt)",
    "platform": "G7400+",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "plus-graphics",
      "alt-dump"
    ],
    "romFile": "Clay Pigeon! (Plus, alt) (G7400+, Alt).bin"
  },
  {
    "id": "pr_interpol",
    "filename": "pr_interpol.bin",
    "title": "Interpol (GST Video)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Interpol (GST Video).bin"
  },
  {
    "id": "pr_martian-threat_alt",
    "filename": "pr_martian-threat_alt.bin",
    "title": "Martian Threat (alt)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "alt-dump"
    ],
    "romFile": "Martian Threat (alt) (Alt).bin"
  },
  {
    "id": "pr_martian-threat",
    "filename": "pr_martian-threat.bin",
    "title": "Martian Threat (GST Video)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Martian Threat (GST Video).bin"
  },
  {
    "id": "pr_mission-impossible",
    "filename": "pr_mission-impossible.bin",
    "title": "Mission Impossible (homebrew-style)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Mission Impossible (homebrew-style).bin"
  },
  {
    "id": "pr_nightfighter",
    "filename": "pr_nightfighter.bin",
    "title": "Nightfighter (Retrogenesis)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Nightfighter (Retrogenesis).bin"
  },
  {
    "id": "pr_pinball",
    "filename": "pr_pinball.bin",
    "title": "Pinball",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Pinball.bin"
  },
  {
    "id": "pr_playtag",
    "filename": "pr_playtag.bin",
    "title": "Playtag (Bas Kornalijnslijper)",
    "platform": "G7400+",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "plus-graphics"
    ],
    "romFile": "Playtag (Bas Kornalijnslijper) (G7400+).bin"
  },
  {
    "id": "pr_red-baron",
    "filename": "pr_red-baron.bin",
    "title": "Red Baron",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Red Baron.bin"
  },
  {
    "id": "pr_red-baron_alt",
    "filename": "pr_red-baron_alt.bin",
    "title": "Red Baron (alt)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "alt-dump"
    ],
    "romFile": "Red Baron (alt) (Alt).bin"
  },
  {
    "id": "pr_robot-city",
    "filename": "pr_robot-city.bin",
    "title": "Robot City",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Robot City.bin"
  },
  {
    "id": "pr_shark-hunter",
    "filename": "pr_shark-hunter.bin",
    "title": "Shark Hunter",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Shark Hunter.bin"
  },
  {
    "id": "pr_spiderman_alt",
    "filename": "pr_spiderman_alt.bin",
    "title": "Spider-Man (alt)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [
      "alt-dump"
    ],
    "romFile": "Spider-Man (alt) (Alt).bin"
  },
  {
    "id": "pr_spiderman",
    "filename": "pr_spiderman.bin",
    "title": "Spider-Man (unofficial/rare dump on packs)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Spider-Man (unofficial-rare dump on packs).bin"
  },
  {
    "id": "pr_tutankham",
    "filename": "pr_tutankham.bin",
    "title": "Tutankham (unofficial/rare dump on packs)",
    "platform": "G7000",
    "category": "Rare / unreleased",
    "vpNumber": null,
    "tags": [],
    "romFile": "Tutankham (unofficial-rare dump on packs).bin"
  },
  {
    "id": "csv1",
    "filename": "csv1.bin",
    "title": "Verkehrsspiele 1 (Germany)",
    "platform": "G7000",
    "category": "Utility / unknown",
    "vpNumber": null,
    "tags": [],
    "romFile": "Verkehrsspiele 1 (Germany).bin"
  },
  {
    "id": "csv2",
    "filename": "csv2.bin",
    "title": "Verkehrsspiele 2 (Germany)",
    "platform": "G7000",
    "category": "Utility / unknown",
    "vpNumber": null,
    "tags": [],
    "romFile": "Verkehrsspiele 2 (Germany).bin"
  },
  {
    "id": "br_9434",
    "filename": "br_9434.bin",
    "title": "Wall Street",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9434 - Wall Street.bin"
  },
  {
    "id": "br_9461",
    "filename": "br_9461.bin",
    "title": "Bombardeio Submarino! / Tiro ao Alvo!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9461 - Bombardeio Submarino! - Tiro ao Alvo!.bin"
  },
  {
    "id": "br_9462",
    "filename": "br_9462.bin",
    "title": "Desafio Chinês!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9462 - Desafio Chinês!.bin"
  },
  {
    "id": "br_9463",
    "filename": "br_9463.bin",
    "title": "O Malabarista! / Jogo da Velha!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9463 - O Malabarista! - Jogo da Velha!.bin"
  },
  {
    "id": "br_9468",
    "filename": "br_9468.bin",
    "title": "Telegrafista!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9468 - Telegrafista!.bin"
  },
  {
    "id": "br_9469",
    "filename": "br_9469.bin",
    "title": "O Gato e o Rato!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9469 - O Gato e o Rato!.bin"
  },
  {
    "id": "br_9472",
    "filename": "br_9472.bin",
    "title": "Super Bee!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9472 - Super Bee!.bin"
  },
  {
    "id": "br_9473",
    "filename": "br_9473.bin",
    "title": "Buraco Negro!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9473 - Buraco Negro!.bin"
  },
  {
    "id": "br_9474",
    "filename": "br_9474.bin",
    "title": "Clay Pigeon!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9474 - Clay Pigeon!.bin"
  },
  {
    "id": "br_9475",
    "filename": "br_9475.bin",
    "title": "Comando Noturno!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9475 - Comando Noturno!.bin"
  },
  {
    "id": "br_9476",
    "filename": "br_9476.bin",
    "title": "Balão Travesso!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9476 - Balão Travesso!.bin"
  },
  {
    "id": "br_9477",
    "filename": "br_9477.bin",
    "title": "Barão Vermelho!",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9477 - Barão Vermelho!.bin"
  },
  {
    "id": "br_9483",
    "filename": "br_9483.bin",
    "title": "Frogger",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9483 - Frogger.bin"
  },
  {
    "id": "br_9484",
    "filename": "br_9484.bin",
    "title": "Popeye",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9484 - Popeye.bin"
  },
  {
    "id": "br_9485",
    "filename": "br_9485.bin",
    "title": "Q*bert",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9485 - Qbert.bin"
  },
  {
    "id": "br_9486",
    "filename": "br_9486.bin",
    "title": "Super Cobra",
    "platform": "G7000",
    "category": "Philips Brazil",
    "vpNumber": null,
    "tags": [
      "brazil"
    ],
    "romFile": "BR9486 - Super Cobra.bin"
  }
,
  {
    "id": "c64_boulder_dash",
    "filename": "c64_boulder_dash.d64",
    "title": "Boulder Dash",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Boulder Dash.d64",
    "year": 1984,
    "publisher": "First Star Software",
    "developer": "Peter Liepa, Chris Gray"
  },
  {
    "id": "c64_impossible_mission",
    "filename": "c64_impossible_mission.d64",
    "title": "Impossible Mission",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Impossible Mission.d64",
    "year": 1984,
    "publisher": "Epyx",
    "developer": "Dennis Caswell"
  },
  {
    "id": "c64_last_ninja",
    "filename": "c64_last_ninja.d64",
    "title": "The Last Ninja",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "The Last Ninja.d64",
    "year": 1987,
    "publisher": "System 3",
    "developer": "System 3"
  },
  {
    "id": "c64_wizball",
    "filename": "c64_wizball.d64",
    "title": "Wizball",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Wizball.d64",
    "year": 1987,
    "publisher": "Ocean",
    "developer": "Sensible Software"
  },
  {
    "id": "c64_uridium",
    "filename": "c64_uridium.d64",
    "title": "Uridium",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Uridium.d64",
    "year": 1986,
    "publisher": "Hewson",
    "developer": "Andrew Braybrook"
  },
  {
    "id": "c64_paradroid",
    "filename": "c64_paradroid.d64",
    "title": "Paradroid",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Paradroid.d64",
    "year": 1985,
    "publisher": "Hewson",
    "developer": "Andrew Braybrook"
  },
  {
    "id": "c64_turrican2",
    "filename": "c64_turrican2.d64",
    "title": "Turrican II: The Final Fight",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Turrican II.d64",
    "year": 1991,
    "publisher": "Rainbow Arts",
    "developer": "Manfred Trenz"
  },
  {
    "id": "c64_maniac_mansion",
    "filename": "c64_maniac_mansion.d64",
    "title": "Maniac Mansion",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Maniac Mansion.d64",
    "year": 1987,
    "publisher": "Lucasfilm Games",
    "developer": "Ron Gilbert, Gary Winnick"
  },
  {
    "id": "c64_zak_mckracken",
    "filename": "c64_zak_mckracken.d64",
    "title": "Zak McKracken and the Alien Mindbenders",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Zak McKracken.crt",
    "year": 1988,
    "publisher": "Lucasfilm Games",
    "developer": "David Fox"
  },
  {
    "id": "c64_elite",
    "filename": "c64_elite.d64",
    "title": "Elite",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Elite.d64",
    "year": 1985,
    "publisher": "Firebird",
    "developer": "David Braben, Ian Bell"
  },
  {
    "id": "c64_ik_plus",
    "filename": "c64_ik_plus.d64",
    "title": "IK+",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "IK+.d64",
    "year": 1987,
    "publisher": "System 3",
    "developer": "Archer Maclean"
  },
  {
    "id": "c64_bruce_lee",
    "filename": "c64_bruce_lee.d64",
    "title": "Bruce Lee",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Bruce Lee.d64",
    "year": 1984,
    "publisher": "Datasoft",
    "developer": "Ron J. Fortier"
  },
  {
    "id": "c64_commando",
    "filename": "c64_commando.d64",
    "title": "Commando",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Commando.d64",
    "year": 1985,
    "publisher": "Elite Systems",
    "developer": "Chris Butler"
  },
  {
    "id": "c64_bubble_bobble",
    "filename": "c64_bubble_bobble.d64",
    "title": "Bubble Bobble",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Bubble Bobble.d64",
    "year": 1987,
    "publisher": "Firebird",
    "developer": "Software Creations"
  },
  {
    "id": "c64_giana_sisters",
    "filename": "c64_giana_sisters.d64",
    "title": "The Great Giana Sisters",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "The Great Giana Sisters.d64",
    "year": 1987,
    "publisher": "Rainbow Arts",
    "developer": "Time Warp Productions"
  },
  {
    "id": "c64_katakis",
    "filename": "c64_katakis.d64",
    "title": "Katakis",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Katakis.d64",
    "year": 1988,
    "publisher": "Rainbow Arts",
    "developer": "Manfred Trenz"
  },
  {
    "id": "c64_creatures",
    "filename": "c64_creatures.d64",
    "title": "Creatures",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Creatures.d64",
    "year": 1990,
    "publisher": "Thalamus",
    "developer": "John & Steve Rowlands"
  },
  {
    "id": "c64_mayhem",
    "filename": "c64_mayhem.d64",
    "title": "Mayhem in Monsterland",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Mayhem in Monsterland.d64",
    "year": 1993,
    "publisher": "Apex Computer Productions",
    "developer": "John & Steve Rowlands"
  },
  {
    "id": "c64_archon",
    "filename": "c64_archon.d64",
    "title": "Archon: The Light and the Dark",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Archon.d64",
    "year": 1983,
    "publisher": "Electronic Arts",
    "developer": "Free Fall Associates"
  },
  {
    "id": "c64_mule",
    "filename": "c64_mule.d64",
    "title": "M.U.L.E.",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "MULE.d64",
    "year": 1983,
    "publisher": "Electronic Arts",
    "developer": "Ozark Softscape"
  },
  {
    "id": "c64_california_games",
    "filename": "c64_california_games.d64",
    "title": "California Games",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "California Games.d64",
    "year": 1987,
    "publisher": "Epyx",
    "developer": "Epyx"
  },
  {
    "id": "c64_winter_games",
    "filename": "c64_winter_games.d64",
    "title": "Winter Games",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Winter Games.d64",
    "year": 1985,
    "publisher": "Epyx",
    "developer": "Epyx"
  },
  {
    "id": "c64_pitstop2",
    "filename": "c64_pitstop2.d64",
    "title": "Pitstop II",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Pitstop II.d64",
    "year": 1984,
    "publisher": "Epyx",
    "developer": "Epyx"
  },
  {
    "id": "c64_defender_crown",
    "filename": "c64_defender_crown.d64",
    "title": "Defender of the Crown",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Defender of the Crown.d64",
    "year": 1987,
    "publisher": "Cinemaware",
    "developer": "Cinemaware"
  },
  {
    "id": "c64_barbarian",
    "filename": "c64_barbarian.d64",
    "title": "Barbarian: The Ultimate Warrior",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Barbarian.d64",
    "year": 1987,
    "publisher": "Palace Software",
    "developer": "Steve Brown"
  },
  {
    "id": "c64_microprose_soccer",
    "filename": "c64_microprose_soccer.d64",
    "title": "Microprose Soccer",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Microprose Soccer.d64",
    "year": 1988,
    "publisher": "MicroProse",
    "developer": "Sensible Software"
  }
,
  {
    "id": "c64_paperboy",
    "filename": "c64_paperboy.d64",
    "title": "Paperboy",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Paperboy.d64",
    "year": 1986,
    "publisher": "Elite Systems",
    "developer": "Elite Systems (arcade: Atari Games)"
  },
  {
    "id": "c64_test_drive",
    "filename": "c64_test_drive.d64",
    "title": "Test Drive",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Test Drive.crt",
    "year": 1987,
    "publisher": "Accolade",
    "developer": "Distinctive Software"
  },
  {
    "id": "c64_target_renegade",
    "filename": "c64_target_renegade.d64",
    "title": "Target: Renegade",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Target Renegade.d64",
    "year": 1988,
    "publisher": "Imagine Software",
    "developer": "Imagine Software"
  },
  {
    "id": "c64_sword_of_fargoal",
    "filename": "c64_sword_of_fargoal.d64",
    "title": "Sword of Fargoal",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Sword of Fargoal.d64",
    "year": 1983,
    "publisher": "Epyx",
    "developer": "Jeff McCord"
  },
  {
    "id": "c64_shadow_of_the_beast",
    "filename": "c64_shadow_of_the_beast.d64",
    "title": "Shadow of the Beast",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Shadow of the Beast.d64",
    "year": 1990,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "c64_operation_wolf",
    "filename": "c64_operation_wolf.d64",
    "title": "Operation Wolf",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Operation Wolf.d64",
    "year": 1988,
    "publisher": "Ocean Software",
    "developer": "Ocean Software (arcade: Taito)"
  },
  {
    "id": "c64_double_dragon",
    "filename": "c64_double_dragon.d64",
    "title": "Double Dragon",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Double Dragon.d64",
    "year": 1988,
    "publisher": "Melbourne House",
    "developer": "Binary Design"
  },
  {
    "id": "c64_spy_vs_spy",
    "filename": "c64_spy_vs_spy.d64",
    "title": "Spy vs Spy",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Spy vs Spy.d64",
    "year": 1984,
    "publisher": "First Star Software",
    "developer": "Michael Riedel"
  },
  {
    "id": "c64_ghostbusters",
    "filename": "c64_ghostbusters.d64",
    "title": "Ghostbusters",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Ghostbusters.d64",
    "year": 1984,
    "publisher": "Activision",
    "developer": "David Crane"
  },
  {
    "id": "c64_pool_of_radiance",
    "filename": "c64_pool_of_radiance.d64",
    "title": "Pool of Radiance",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Pool of Radiance (Disk 1).d64",
    "year": 1988,
    "publisher": "Strategic Simulations, Inc.",
    "developer": "Strategic Simulations, Inc."
  },
  {
    "id": "c64_turrican",
    "filename": "c64_turrican.d64",
    "title": "Turrican",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Turrican.d64",
    "year": 1990,
    "publisher": "Rainbow Arts",
    "developer": "Manfred Trenz / Factor 5"
  },
  {
    "id": "c64_wasteland",
    "filename": "c64_wasteland.d64",
    "title": "Wasteland",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Wasteland.d64",
    "year": 1988,
    "publisher": "Electronic Arts",
    "developer": "Interplay Productions"
  },
  {
    "id": "c64_dropzone",
    "filename": "c64_dropzone.d64",
    "title": "Dropzone",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Dropzone.d64",
    "year": 1984,
    "publisher": "U.S. Gold",
    "developer": "Archer Maclean"
  },
  {
    "id": "c64_laser_squad",
    "filename": "c64_laser_squad.d64",
    "title": "Laser Squad",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Laser Squad.d64",
    "year": 1988,
    "publisher": "Target Games",
    "developer": "Julian Gollop, Nick Gollop"
  },
  {
    "id": "c64_congo_bongo",
    "filename": "c64_congo_bongo.d64",
    "title": "Congo Bongo",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Congo Bongo.d64",
    "year": 1983,
    "publisher": "Sega",
    "developer": "Sega"
  },
  {
    "id": "c64_frogger",
    "filename": "c64_frogger.d64",
    "title": "Frogger",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Frogger.d64",
    "year": 1983,
    "publisher": "Sierra On-Line",
    "developer": "Chuck Benton (arcade: Konami/Sega)"
  },
  {
    "id": "c64_castle_wolfenstein",
    "filename": "c64_castle_wolfenstein.d64",
    "title": "Castle Wolfenstein",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Castle Wolfenstein.d64",
    "year": 1983,
    "publisher": "Muse Software",
    "developer": "Silas Warner"
  },
  {
    "id": "c64_blood_money",
    "filename": "c64_blood_money.d64",
    "title": "Blood Money",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "Blood Money.d64",
    "year": 1990,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "c64_outrun",
    "filename": "c64_outrun.d64",
    "title": "OutRun",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [],
    "romFile": "OutRun.d64",
    "year": 1988,
    "publisher": "Mindscape / US Gold",
    "developer": "Martin Webb, Dennis Webb, Chris Oberth, Lou Haehn (arcade: Sega)"
  },
  {
    "id": "c64_samantha_fox_strip_poker",
    "filename": "c64_samantha_fox_strip_poker.d64",
    "title": "Samantha Fox Strip Poker",
    "platform": "C64",
    "category": "Commodore 64",
    "vpNumber": null,
    "tags": [
      "adult"
    ],
    "romFile": "Samantha Fox Strip Poker.d64",
    "year": 1986,
    "publisher": "Martech",
    "developer": "Software Communications"
  },
  {
    "id": "pc_doom",
    "filename": "pc_doom.zip",
    "title": "Doom",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DOOM.zip",
    "year": 1993,
    "publisher": "id Software",
    "developer": "id Software"
  },
  {
    "id": "pc_wolfenstein3d",
    "filename": "pc_wolfenstein3d.zip",
    "title": "Wolfenstein 3D",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "WOLF3D.zip",
    "year": 1992,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_commander_keen",
    "filename": "pc_commander_keen.zip",
    "title": "Commander Keen: Invasion of the Vorticons",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN1.zip",
    "year": 1990,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_duke_nukem_2",
    "filename": "pc_duke_nukem_2.zip",
    "title": "Duke Nukem II",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DUKE2.zip",
    "year": 1993,
    "publisher": "Apogee Software",
    "developer": "Apogee Software"
  },
  {
    "id": "pc_prince_of_persia",
    "filename": "pc_prince_of_persia.zip",
    "title": "Prince of Persia",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "PRINCE.zip",
    "year": 1990,
    "publisher": "Brøderbund",
    "developer": "Jordan Mechner"
  },
  {
    "id": "pc_leisure_suit_larry",
    "filename": "pc_leisure_suit_larry.zip",
    "title": "Leisure Suit Larry in the Land of the Lounge Lizards",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL1.zip",
    "year": 1987,
    "publisher": "Sierra On-Line",
    "developer": "Al Lowe"
  },
  {
    "id": "pc_softporn",
    "filename": "pc_softporn.zip",
    "title": "Softporn Adventure",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SOFTPORN.zip",
    "year": 1991,
    "publisher": "Gary Thompson (shareware; original 1981: On-Line Systems)",
    "developer": "Chuck Benton (Apple II original), Gary Thompson (PC version)"
  },
  {
    "id": "pc_lsl1_vga",
    "filename": "pc_lsl1_vga.zip",
    "title": "Leisure Suit Larry 1: In the Land of the Lounge Lizards (VGA remake)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL1VGA.zip",
    "year": 1991,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line (Al Lowe)"
  },
  {
    "id": "pc_lsl2",
    "filename": "pc_lsl2.zip",
    "title": "Leisure Suit Larry Goes Looking for Love (in Several Wrong Places)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL2.zip",
    "year": 1988,
    "publisher": "Sierra On-Line",
    "developer": "Al Lowe"
  },
  {
    "id": "pc_lsl3",
    "filename": "pc_lsl3.zip",
    "title": "Leisure Suit Larry III: Passionate Patti in Pursuit of the Pulsating Pectorals",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL3.zip",
    "year": 1989,
    "publisher": "Sierra On-Line",
    "developer": "Al Lowe"
  },
  {
    "id": "pc_lsl5",
    "filename": "pc_lsl5.zip",
    "title": "Leisure Suit Larry 5: Passionate Patti Does a Little Undercover Work",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL5.zip",
    "year": 1991,
    "publisher": "Sierra On-Line",
    "developer": "Al Lowe"
  },
  {
    "id": "pc_lsl6",
    "filename": "pc_lsl6.zip",
    "title": "Leisure Suit Larry 6: Shape Up or Slip Out!",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "LSL6.zip",
    "year": 1993,
    "publisher": "Sierra On-Line",
    "developer": "Al Lowe"
  },
  {
    "id": "c64_hb_c64anabalt",
    "filename": "c64_hb_c64anabalt.d64",
    "title": "C64anabalt",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "C64anabalt.d64",
    "year": 2012,
    "publisher": "RGCD",
    "developer": "RGCD"
  },
  {
    "id": "c64_hb_rescuing_orc",
    "filename": "c64_hb_rescuing_orc.d64",
    "title": "Rescuing Orc",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Rescuing Orc.d64",
    "year": 2017,
    "publisher": "Juan J. Martínez",
    "developer": "Juan J. Martínez"
  },
  {
    "id": "c64_hb_doc_cosmos",
    "filename": "c64_hb_doc_cosmos.d64",
    "title": "Doc Cosmos",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Doc Cosmos.d64",
    "year": 2019,
    "publisher": "Simon Jameson",
    "developer": "Simon Jameson"
  },
  {
    "id": "c64_hb_tenebra2",
    "filename": "c64_hb_tenebra2.d64",
    "title": "Tenebra 2",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Tenebra 2.d64",
    "year": 2022,
    "publisher": "Haplo",
    "developer": "Haplo"
  },
  {
    "id": "c64_hb_bomberland",
    "filename": "c64_hb_bomberland.d64",
    "title": "Bomberland",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Bomberland.d64",
    "year": 2018,
    "publisher": "Master",
    "developer": "Master"
  },
  {
    "id": "c64_hb_bruce_lee_return_of_fury",
    "filename": "c64_hb_bruce_lee_return_of_fury.d64",
    "title": "Bruce Lee: Return of Fury",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Bruce Lee Return of Fury.d64",
    "year": 2019,
    "publisher": "Megastyle",
    "developer": "Megastyle"
  },
  {
    "id": "c64_hb_rocket_smash_ex",
    "filename": "c64_hb_rocket_smash_ex.d64",
    "title": "Rocket Smash EX",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Rocket Smash EX.crt",
    "year": 2015,
    "publisher": "RGCD",
    "developer": "Richard Bayliss / RGCD"
  },
  {
    "id": "c64_hb_micro_hexagon",
    "filename": "c64_hb_micro_hexagon.d64",
    "title": "Micro Hexagon",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Micro Hexagon.d64",
    "year": 2013,
    "publisher": "Onslaught",
    "developer": "Onslaught"
  },
  {
    "id": "c64_hb_wolfling",
    "filename": "c64_hb_wolfling.d64",
    "title": "Wolfling",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Wolfling.prg",
    "year": 2019,
    "publisher": "Lazycow",
    "developer": "Lazycow"
  },
  {
    "id": "c64_hb_runn_n_gunn",
    "filename": "c64_hb_runn_n_gunn.d64",
    "title": "Runn'n'Gunn",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Runn n Gunn.d64",
    "year": 2021,
    "publisher": "Excess",
    "developer": "Excess"
  },
  {
    "id": "c64_hb_grid_pix",
    "filename": "c64_hb_grid_pix.d64",
    "title": "Grid Pix",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Grid Pix.d64",
    "year": 2020,
    "publisher": "Excess",
    "developer": "Excess"
  },
  {
    "id": "c64_hb_super_bread_box",
    "filename": "c64_hb_super_bread_box.d64",
    "title": "Super Bread Box",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Super Bread Box.prg",
    "year": 2012,
    "publisher": "Paulko64",
    "developer": "Paulko64"
  },
  {
    "id": "c64_hb_hero_is_back",
    "filename": "c64_hb_hero_is_back.d64",
    "title": "H.E.R.O. Is Back",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "HERO Is Back.d64",
    "year": 2025,
    "publisher": "Excess and Hokuto Force",
    "developer": "Excess and Hokuto Force"
  },
  {
    "id": "c64_hb_luftrauserz",
    "filename": "c64_hb_luftrauserz.d64",
    "title": "LuftrauserZ",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "LuftrauserZ.d64",
    "year": 2017,
    "publisher": "Triad",
    "developer": "Triad"
  },
  {
    "id": "c64_hb_bagman_strikes_back",
    "filename": "c64_hb_bagman_strikes_back.d64",
    "title": "Bagman Strikes Back",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Bagman Strikes Back.d64",
    "year": 2022,
    "publisher": "LC-Games",
    "developer": "LC-Games"
  },
  {
    "id": "c64_hb_galaxian_dx",
    "filename": "c64_hb_galaxian_dx.d64",
    "title": "Galaxian DX",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Galaxian DX.d64",
    "year": 2021,
    "publisher": "Army of Darkness",
    "developer": "Army of Darkness"
  },
  {
    "id": "pc_civilization",
    "filename": "pc_civilization.zip",
    "title": "Sid Meier's Civilization",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "CIVILIZATION.zip",
    "year": 1991,
    "publisher": "MicroProse",
    "developer": "MicroProse (MPS Labs)"
  },
  {
    "id": "pc_simcity",
    "filename": "pc_simcity.zip",
    "title": "SimCity",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SIMCITY.zip",
    "year": 1989,
    "publisher": "Broderbund",
    "developer": "Maxis"
  },
  {
    "id": "pc_dune2",
    "filename": "pc_dune2.zip",
    "title": "Dune II: The Building of a Dynasty",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DUNE2.zip",
    "year": 1992,
    "publisher": "Virgin Games",
    "developer": "Westwood Studios"
  },
  {
    "id": "pc_tim",
    "filename": "pc_tim.zip",
    "title": "The Incredible Machine",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "TIM.zip",
    "year": 1993,
    "publisher": "Sierra On-Line",
    "developer": "Dynamix"
  },
  {
    "id": "pc_oregon_trail",
    "filename": "pc_oregon_trail.zip",
    "title": "The Oregon Trail",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "OREGON.zip",
    "year": 1990,
    "publisher": "MECC",
    "developer": "MECC"
  },
  {
    "id": "pc_keen2",
    "filename": "pc_keen2.zip",
    "title": "Commander Keen: The Earth Explodes (Episode 2)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN2.zip",
    "year": 1990,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_keen3",
    "filename": "pc_keen3.zip",
    "title": "Commander Keen: Keen Must Die! (Episode 3)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN3.zip",
    "year": 1990,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_keen4",
    "filename": "pc_keen4.zip",
    "title": "Commander Keen in Goodbye Galaxy: Secret of the Oracle (Episode 4)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN4.zip",
    "year": 1991,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_keen5",
    "filename": "pc_keen5.zip",
    "title": "Commander Keen in Goodbye Galaxy: The Armageddon Machine (Episode 5)",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN5.zip",
    "year": 1991,
    "publisher": "Apogee Software",
    "developer": "id Software"
  },
  {
    "id": "pc_keen6",
    "filename": "pc_keen6.zip",
    "title": "Commander Keen 6: Aliens Ate My Babysitter!",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KEEN6.zip",
    "year": 1991,
    "publisher": "FormGen",
    "developer": "id Software"
  },
  {
    "id": "pc_duke_nukem",
    "filename": "pc_duke_nukem.zip",
    "title": "Duke Nukem",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DUKE1.zip",
    "year": 1991,
    "publisher": "Apogee Software",
    "developer": "Apogee Software"
  },
  {
    "id": "pc_duke_nukem_3d",
    "filename": "pc_duke_nukem_3d.zip",
    "title": "Duke Nukem 3D",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DUKE3D.zip",
    "year": 1996,
    "publisher": "Apogee Software / FormGen",
    "developer": "3D Realms"
  },
  {
    "id": "pc_kq1",
    "filename": "pc_kq1.zip",
    "title": "King's Quest I: Quest for the Crown",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ1.zip",
    "year": 1990,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq2",
    "filename": "pc_kq2.zip",
    "title": "King's Quest II: Romancing the Throne",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ2.zip",
    "year": 1985,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq3",
    "filename": "pc_kq3.zip",
    "title": "King's Quest III: To Heir Is Human",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ3.zip",
    "year": 1986,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq4",
    "filename": "pc_kq4.zip",
    "title": "King's Quest IV: The Perils of Rosella",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ4.zip",
    "year": 1988,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq5",
    "filename": "pc_kq5.zip",
    "title": "King's Quest V: Absence Makes the Heart Go Yonder!",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ5.zip",
    "year": 1990,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq6",
    "filename": "pc_kq6.zip",
    "title": "King's Quest VI: Heir Today, Gone Tomorrow",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ6.zip",
    "year": 1992,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_kq7",
    "filename": "pc_kq7.zip",
    "title": "King's Quest VII: The Princeless Bride",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "KQ7.zip",
    "year": 1994,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_doom2",
    "filename": "pc_doom2.zip",
    "title": "Doom II: Hell on Earth",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "DOOM2.zip",
    "year": 1994,
    "publisher": "GT Interactive",
    "developer": "id Software"
  },
  {
    "id": "pc_final_doom_tnt",
    "filename": "pc_final_doom_tnt.zip",
    "title": "Final Doom: TNT Evilution",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "TNT.zip",
    "year": 1996,
    "publisher": "GT Interactive",
    "developer": "TeamTNT (id Software engine)"
  },
  {
    "id": "pc_final_doom_plutonia",
    "filename": "pc_final_doom_plutonia.zip",
    "title": "Final Doom: The Plutonia Experiment",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "PLUTONIA.zip",
    "year": 1996,
    "publisher": "GT Interactive",
    "developer": "Dario and Milo Casali (id Software engine)"
  },
  {
    "id": "pc_spear_of_destiny",
    "filename": "pc_spear_of_destiny.zip",
    "title": "Spear of Destiny",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SPEAR.zip",
    "year": 1992,
    "publisher": "FormGen Corporation",
    "developer": "id Software"
  },
  {
    "id": "pc_xcom_ufo_defense",
    "filename": "pc_xcom_ufo_defense.zip",
    "title": "X-COM: UFO Defense",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "XCOM.zip",
    "year": 1994,
    "publisher": "MicroProse",
    "developer": "Mythos Games / MicroProse"
  },
  {
    "id": "pc_sq1",
    "filename": "pc_sq1.zip",
    "title": "Space Quest I: The Sarien Encounter",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ1.zip",
    "year": 1986,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_sq2",
    "filename": "pc_sq2.zip",
    "title": "Space Quest II: Vohaul's Revenge",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ2.zip",
    "year": 1987,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_sq3",
    "filename": "pc_sq3.zip",
    "title": "Space Quest III: The Pirates of Pestulon",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ3.zip",
    "year": 1989,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_sq4",
    "filename": "pc_sq4.zip",
    "title": "Space Quest IV: Roger Wilco and the Time Rippers",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ4.zip",
    "year": 1991,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_sq5",
    "filename": "pc_sq5.zip",
    "title": "Space Quest V: The Next Mutation",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ5.zip",
    "year": 1993,
    "publisher": "Sierra On-Line",
    "developer": "Dynamix"
  },
  {
    "id": "pc_sq6",
    "filename": "pc_sq6.zip",
    "title": "Space Quest 6: The Spinal Frontier",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "SQ6.zip",
    "year": 1995,
    "publisher": "Sierra On-Line",
    "developer": "Sierra On-Line"
  },
  {
    "id": "pc_lemmings",
    "filename": "pc_lemmings.zip",
    "title": "Lemmings",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "PC_LEMMINGS.zip",
    "year": 1991,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_onml",
    "filename": "pc_onml.zip",
    "title": "Oh No! More Lemmings",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "onml.zip",
    "year": 1991,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_xmas_lemmings",
    "filename": "pc_xmas_lemmings.zip",
    "title": "Xmas Lemmings",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "xmas.zip",
    "year": 1992,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_holiday_lemmings",
    "filename": "pc_holiday_lemmings.zip",
    "title": "Holiday Lemmings 1994",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "holiday.zip",
    "year": 1994,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_lemmings2",
    "filename": "pc_lemmings2.zip",
    "title": "Lemmings 2: The Tribes",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "lem2.zip",
    "year": 1993,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_anwol",
    "filename": "pc_anwol.zip",
    "title": "All New World of Lemmings",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "anwol.zip",
    "year": 1994,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_blood_money",
    "filename": "pc_blood_money.zip",
    "title": "Blood Money",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "bloodmoney.zip",
    "year": 1990,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "pc_hb_gates",
    "filename": "pc_hb_gates.zip",
    "title": "Gates Of Integrity",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "GATES.zip",
    "publisher": "Tarjan",
    "developer": "Tarjan"
  },
  {
    "id": "pc_hb_disksweeper",
    "filename": "pc_hb_disksweeper.zip",
    "title": "DISKSWEEPER",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "DISKSWEEPER.zip",
    "year": 2022,
    "publisher": "voxel",
    "developer": "voxel"
  },
  {
    "id": "pc_hb_pantsmo",
    "filename": "pc_hb_pantsmo.zip",
    "title": "Pantsmo's Pantaloon Adventure",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "PANTSMO.zip",
    "publisher": "eviltentacle",
    "developer": "eviltentacle"
  },
  {
    "id": "pc_hb_noudar",
    "filename": "pc_hb_noudar.zip",
    "title": "Dungeons of Noudar",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "NOUDAR.zip",
    "year": 2018,
    "publisher": "Daniel Monteiro",
    "developer": "Daniel Monteiro"
  },
  {
    "id": "pc_hb_alienintruder",
    "filename": "pc_hb_alienintruder.zip",
    "title": "Alien Intruder",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "ALIENINTRUDER.zip",
    "year": 2024,
    "publisher": "Juan J. Martínez",
    "developer": "Juan J. Martínez"
  },
  {
    "id": "pc_hb_goldmine",
    "filename": "pc_hb_goldmine.zip",
    "title": "Gold Mine Run!",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "GOLDMINE.zip",
    "year": 2023,
    "publisher": "Juan J. Martínez",
    "developer": "Juan J. Martínez"
  },
  {
    "id": "pc_hb_traxtor",
    "filename": "pc_hb_traxtor.zip",
    "title": "The Return of Traxtor",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "TRAXTOR.zip",
    "year": 2023,
    "publisher": "Juan J. Martínez",
    "developer": "Juan J. Martínez"
  },
  {
    "id": "pc_hb_queens",
    "filename": "pc_hb_queens.zip",
    "title": "The Queen's Footsteps",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "QUEENSFOOTSTEPS.zip",
    "publisher": "Davide Bucci",
    "developer": "Davide Bucci"
  },
  {
    "id": "pc_hb_spacecavern",
    "filename": "pc_hb_spacecavern.zip",
    "title": "Space Cavern Blaster",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "SPACECAVERN.zip",
    "publisher": "dotmos",
    "developer": "dotmos"
  },
  {
    "id": "pc_hb_barren",
    "filename": "pc_hb_barren.zip",
    "title": "Barren Planet",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "BARRENPLANET.zip",
    "publisher": "Cyningstan",
    "developer": "Cyningstan"
  },
  {
    "id": "pc_hb_chambers",
    "filename": "pc_hb_chambers.zip",
    "title": "The Chambers Beneath",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "CHAMBERSBENEATH.zip",
    "publisher": "Cyningstan",
    "developer": "Cyningstan"
  },
  {
    "id": "pc_hb_hibernated1",
    "filename": "pc_hb_hibernated1.zip",
    "title": "Hibernated 1 (Director's Cut)",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "HIBERNATED1.zip",
    "publisher": "Stefan Vogt",
    "developer": "Stefan Vogt"
  },
  {
    "id": "pc_hb_eightfeet",
    "filename": "pc_hb_eightfeet.zip",
    "title": "Eight Feet Under",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "EIGHTFEETUNDER.zip",
    "publisher": "Stefan Vogt",
    "developer": "Stefan Vogt"
  },
  {
    "id": "pc_hb_lake",
    "filename": "pc_hb_lake.zip",
    "title": "LAKE Adventure",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "LAKEADVENTURE.zip",
    "publisher": "B.J. Best",
    "developer": "B.J. Best"
  },
  {
    "id": "pc_hb_acronia",
    "filename": "pc_hb_acronia.zip",
    "title": "Acronia",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "ACRONIA.zip",
    "year": 2021,
    "publisher": "Hadrosaurus Software",
    "developer": "Hadrosaurus Software"
  },
  {
    "id": "pc_hb_catsbroombas",
    "filename": "pc_hb_catsbroombas.zip",
    "title": "Cats on Broombas",
    "platform": "PC",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "CATSBROOMBAS.zip",
    "publisher": "Eigen Lenk",
    "developer": "Eigen Lenk"
  },
  {
    "id": "pc_gta1",
    "filename": "pc_gta1.zip",
    "title": "Grand Theft Auto",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "GTA1.zip",
    "year": 1997,
    "publisher": "BMG Interactive",
    "developer": "DMA Design"
  },
  {
    "id": "pc_outrun",
    "filename": "pc_outrun.zip",
    "title": "OutRun",
    "platform": "PC",
    "category": "MS-DOS",
    "vpNumber": null,
    "tags": [],
    "romFile": "OUTRUN.zip",
    "year": 1989,
    "publisher": "Mindscape",
    "developer": "Unlimited Software / Distinctive Software (arcade: Sega)"
  },
  {
    "id": "c64_hb_munchkin64",
    "filename": "c64_hb_munchkin64.prg",
    "title": "Munchkin 64",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Munchkin64.prg",
    "year": 2022,
    "publisher": "Pretzel Logic",
    "developer": "Pretzel Logic"
  },
  {
    "id": "c64_hb_roguebot",
    "filename": "c64_hb_roguebot.d64",
    "title": "Roguebot",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Roguebot.d64",
    "year": 2023,
    "publisher": "drmortalwombat",
    "developer": "drmortalwombat"
  },
  {
    "id": "c64_hb_veggies_vs_undead",
    "filename": "c64_hb_veggies_vs_undead.prg",
    "title": "Veggies vs Undead",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Veggies vs Undead.prg",
    "year": 2023,
    "publisher": "drmortalwombat",
    "developer": "drmortalwombat"
  },
  {
    "id": "c64_hb_shallow_domains",
    "filename": "c64_hb_shallow_domains.prg",
    "title": "Shallow Domains",
    "platform": "C64",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "Shallow Domains.prg",
    "year": 2022,
    "publisher": "drmortalwombat",
    "developer": "drmortalwombat"
  },
  {
      "id": "c64_hb_comchinko",
      "filename": "c64_hb_comchinko.prg",
      "title": "Comchinko",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "comchinko.prg",
      "year": 2026,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_broken_altars",
      "filename": "c64_hb_broken_altars.prg",
      "title": "Broken Altars",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "brokenaltars.prg",
      "year": 2026,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_trenchangle",
      "filename": "c64_hb_trenchangle.prg",
      "title": "Trenchangle",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "trenchangle.prg",
      "year": 2026,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_overload",
      "filename": "c64_hb_overload.prg",
      "title": "Overload",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "overload.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_terminal_walker",
      "filename": "c64_hb_terminal_walker.prg",
      "title": "Terminal Walker",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "walker.prg",
      "year": 2025,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_soiled_iron",
      "filename": "c64_hb_soiled_iron.prg",
      "title": "Soiled Iron",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "soiledquest.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_portal_buster",
      "filename": "c64_hb_portal_buster.prg",
      "title": "Portal Buster",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "portalbuster.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_mineshaft_gap",
      "filename": "c64_hb_mineshaft_gap.prg",
      "title": "Mineshaft Gap",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "mineshaftgap.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_metal_mayhem",
      "filename": "c64_hb_metal_mayhem.prg",
      "title": "Metal Mayhem",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "metalmayhem.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_corescape",
      "filename": "c64_hb_corescape.prg",
      "title": "Corescape",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "corescape.prg",
      "year": 2024,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_missile_defence",
      "filename": "c64_hb_missile_defence.prg",
      "title": "Missile Defence",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "missiledefence.prg",
      "year": 2023,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_balls_like_a_frog",
      "filename": "c64_hb_balls_like_a_frog.prg",
      "title": "Balls like a Frog",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "blaf.prg",
      "year": 2023,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_minotrace",
      "filename": "c64_hb_minotrace.prg",
      "title": "Minotrace",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "minotrace.prg",
      "year": 2022,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_ball_and_chain",
      "filename": "c64_hb_ball_and_chain.prg",
      "title": "Ball and Chain",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "ballnchain.prg",
      "year": 2022,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_gates_of_the_ancient",
      "filename": "c64_hb_gates_of_the_ancient.prg",
      "title": "Gates of the Ancient",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "goftancient.prg",
      "year": 2021,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
      "id": "c64_hb_plekthora",
      "filename": "c64_hb_plekthora.prg",
      "title": "Plekthora",
      "platform": "C64",
      "category": "Homebrew (community)",
      "vpNumber": null,
      "tags": [],
      "romFile": "plekthora.prg",
      "year": 2021,
      "publisher": "drmortalwombat",
      "developer": "drmortalwombat"
    },
  {
    "id": "am_sqrxz",
    "filename": "amiga_sqrxz.adf",
    "title": "Sqrxz",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_sqrxz.adf",
    "year": 2012,
    "publisher": "Retroguru",
    "developer": "Retroguru (Amiga OCS port); original 1996 game by Marcus Vesterlund, John Holmvall"
  },
  {
    "id": "am_sqrxz3",
    "filename": "amiga_sqrxz3.adf",
    "title": "Sqrxz 3",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_sqrxz3.adf",
    "year": 2015,
    "publisher": "Retroguru",
    "developer": "Retroguru"
  },
  {
    "id": "am_sqrxz4",
    "filename": "amiga_sqrxz4.adf",
    "title": "Sqrxz 4",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_sqrxz4.adf",
    "year": 2018,
    "publisher": "Retroguru",
    "developer": "Retroguru"
  },
  {
    "id": "am_wizzys_quest",
    "filename": "amiga_wizzys_quest.adf",
    "title": "Wizzy's Quest",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_wizzys_quest.adf",
    "year": 1990,
    "publisher": "G&S Appenzeller",
    "developer": "Guido Appenzeller, Sören Appenzeller"
  },
  {
    "id": "am_cybernetix",
    "filename": "amiga_cybernetix.adf",
    "title": "Cybernetix: The First Battle",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_cybernetix.adf",
    "year": 1991,
    "publisher": "Vision Software",
    "developer": "Paul Andrews, Rodney Smith, Blair Zuppicich"
  },
  {
    "id": "am_deluxe_galaga",
    "filename": "amiga_deluxe_galaga.adf",
    "title": "Deluxe Galaga",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_deluxe_galaga.adf",
    "year": 1994,
    "publisher": "Edgar Vigdal",
    "developer": "Edgar Vigdal"
  },
  {
    "id": "am_megaball",
    "filename": "amiga_megaball.adf",
    "title": "MegaBall",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_megaball.adf",
    "year": 1991,
    "publisher": "Ed Mackey, Al Mackey",
    "developer": "Ed Mackey, Al Mackey"
  },
  {
    "id": "am_zerg",
    "filename": "amiga_zerg.adf",
    "title": "Zerg",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_zerg.adf",
    "year": 1989,
    "publisher": "Mike Shapiro",
    "developer": "Mike Shapiro"
  },
  {
    "id": "am_doctor_strange_2",
    "filename": "amiga_doctor_strange_2.adf",
    "title": "Doctor Strange 2: The Return of Doctor Strange",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_doctor_strange_2.adf",
    "year": 1995,
    "publisher": "17-Bit Software",
    "developer": "Ouija Board"
  },
  {
    "id": "am_pollymorf",
    "filename": "amiga_pollymorf.adf",
    "title": "Pollymorf",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_pollymorf.adf",
    "year": 1993,
    "publisher": "Andrew Campbell",
    "developer": "Andrew Campbell"
  },
  {
    "id": "am_dogfight",
    "filename": "amiga_dogfight.adf",
    "title": "Dogfight",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_dogfight.adf",
    "year": 1996,
    "publisher": "Richard Ling",
    "developer": "Richard Ling"
  },
  {
    "id": "am_drip",
    "filename": "amiga_drip.adf",
    "title": "Drip",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_drip.adf",
    "year": 1989,
    "publisher": "Art Skiles",
    "developer": "Art Skiles"
  },
  {
    "id": "am_bobs_garden",
    "filename": "amiga_bobs_garden.adf",
    "title": "Bob's Garden",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_bobs_garden.adf",
    "year": 1993,
    "publisher": "Justin Leck",
    "developer": "Justin Leck"
  },
  {
    "id": "am_super_obliteration",
    "filename": "amiga_super_obliteration.adf",
    "title": "Super Obliteration",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_super_obliteration.adf",
    "year": 1993,
    "publisher": "David Papworth",
    "developer": "David Papworth"
  },
  {
    "id": "am_asteroids",
    "filename": "amiga_asteroids.adf",
    "title": "Cabaret Asteroids",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_asteroids.adf",
    "year": 1991,
    "publisher": "Vertical Developments",
    "developer": "Vertical Developments"
  },
  {
    "id": "am_alien_fish_finger",
    "filename": "amiga_alien_fish_finger.adf",
    "title": "Alien Fish Finger",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_alien_fish_finger.adf",
    "year": 1996,
    "publisher": "Skull Army",
    "developer": "David Cruickshank"
  },
  {
    "id": "am_wibble_world_giddy",
    "filename": "amiga_wibble_world_giddy.adf",
    "title": "Wibble World Giddy! Wibble Mania",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_wibble_world_giddy.adf",
    "year": 1993,
    "publisher": "Phillip Ruston",
    "developer": "Phillip Ruston"
  },
  {
    "id": "am_crazy_sue",
    "filename": "amiga_crazy_sue.adf",
    "title": "Crazy Sue",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_crazy_sue.adf",
    "year": 1991,
    "publisher": "MC Publications",
    "developer": "Jumpshoe, Hironymous, Oakenshield, Thorin"
  },
  {
    "id": "am_pengo2",
    "filename": "amiga_pengo2.adf",
    "title": "Pengo 2",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_pengo2.adf",
    "year": 1994,
    "publisher": "Reploid",
    "developer": "Reploid"
  },
  {
    "id": "am_toado",
    "filename": "amiga_toado.adf",
    "title": "Toado",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_toado.adf",
    "year": 1994,
    "publisher": "J. Wills",
    "developer": "J. Wills"
  },
  {
    "id": "am_deluxe_pacman",
    "filename": "amiga_deluxe_pacman.adf",
    "title": "Deluxe Pac-Man",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_deluxe_pacman.adf",
    "year": 1992,
    "publisher": "Edgar Vigdal",
    "developer": "Edgar Vigdal"
  },
  {
    "id": "am_llamatron",
    "filename": "amiga_llamatron.adf",
    "title": "Llamatron: 2112",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_llamatron.adf",
    "year": 1991,
    "publisher": "Llamasoft",
    "developer": "Jeff Minter"
  },
  {
    "id": "am_gorf",
    "filename": "amiga_gorf.adf",
    "title": "Gorf",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_gorf.adf",
    "year": 1993,
    "publisher": "Towerbyte",
    "developer": "Towerbyte"
  },
  {
    "id": "am_dropzone",
    "filename": "amiga_dropzone.adf",
    "title": "DropZone",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_dropzone.adf",
    "year": 1994,
    "publisher": "Richard Tunstall",
    "developer": "Richard Tunstall"
  },
  {
    "id": "am_elevation",
    "filename": "amiga_elevation.adf",
    "title": "Elevation",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_elevation.adf",
    "year": 1995,
    "publisher": "Delta-9",
    "developer": "Delta-9"
  },
  {
    "id": "am_trailblazer",
    "filename": "amiga_trailblazer.adf",
    "title": "Trailblazer",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_trailblazer.adf",
    "year": 1992,
    "publisher": "Alchemy Productions",
    "developer": "Alchemy Productions"
  },
  {
    "id": "am_space_taxi",
    "filename": "amiga_space_taxi.adf",
    "title": "Space Taxi",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_space_taxi.adf",
    "year": 1993,
    "publisher": "Effect",
    "developer": "Effect"
  },
  {
    "id": "am_robocop",
    "filename": "amiga_robocop.adf",
    "title": "RoboCop",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_robocop.adf",
    "year": 1989,
    "publisher": "Ocean Software",
    "developer": "Ocean Software"
  },
  {
    "id": "am_jimmywhite",
    "filename": "amiga_jimmywhite.adf",
    "title": "Jimmy White's 'Whirlwind' Snooker",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_jimmywhite.adf",
    "year": 1991,
    "publisher": "Virgin Games",
    "developer": "Archer Maclean"
  },
  {
    "id": "am_ohnomorelemmings",
    "filename": "amiga_ohnomorelemmings.adf",
    "title": "Oh No! More Lemmings",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_ohnomorelemmings.adf",
    "year": 1991,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "am_bubblebobble",
    "filename": "amiga_bubblebobble.adf",
    "title": "Bubble Bobble",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_bubblebobble.adf",
    "year": 1988,
    "publisher": "Firebird",
    "developer": "Software Creations"
  },
  {
    "id": "am_turrican",
    "filename": "amiga_turrican.adf",
    "title": "Turrican",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_turrican.adf",
    "year": 1990,
    "publisher": "Rainbow Arts",
    "developer": "Manfred Trenz"
  },
  {
    "id": "am_stuntcarracer",
    "filename": "amiga_stuntcarracer.adf",
    "title": "Stunt Car Racer",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_stuntcarracer.adf",
    "year": 1989,
    "publisher": "MicroStyle",
    "developer": "Geoff Crammond"
  },
  {
    "id": "am_lotusturbo2",
    "filename": "amiga_lotusturbo2.adf",
    "title": "Lotus Turbo Challenge 2",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_lotusturbo2.adf",
    "year": 1991,
    "publisher": "Gremlin Graphics",
    "developer": "Magnetic Fields"
  },
  {
    "id": "am_megamaid",
    "filename": "amiga_megamaid.adf",
    "title": "Megamaid",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": ["demoscene", "adult"],
    "romFile": "amiga_megamaid.adf",
    "year": 1989,
    "publisher": "Pixar & The Band",
    "developer": "Pixar & The Band"
  },
  {
    "id": "am_demo_sota",
    "filename": "amiga_demo_sota.adf",
    "title": "State of the Art (Spaceballs)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_sota.adf",
    "year": 1992,
    "publisher": "Spaceballs",
    "developer": "Code: Lone Starr, Major Asshole · Graphics: TMB Designs · Music: Travolta"
  },
  {
    "id": "am_demo_enigma",
    "filename": "amiga_demo_enigma.adf",
    "title": "Enigma (Phenomena)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_enigma.adf",
    "year": 1991,
    "publisher": "Phenomena",
    "developer": "Code: Azatoth, Judas · Graphics: Azatoth, Uno, Imbecille, Terminator · Music: Firefox, Tip"
  },
  {
    "id": "am_demo_mentalhangover",
    "filename": "amiga_demo_mentalhangover.adf",
    "title": "Mental Hangover (Scoopex)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_mentalhangover.adf",
    "year": 1990,
    "publisher": "Scoopex",
    "developer": "Code: Slayer · Graphics: Reward · Music: Uncle Tom"
  },
  {
    "id": "am_demo_interference",
    "filename": "amiga_demo_interference.adf",
    "title": "Interference (Sanity)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_interference.adf",
    "year": 1993,
    "publisher": "Sanity",
    "developer": "Code: Cosmos, Microforce · Graphics: Cougar, Havok · Music: Virgill"
  },
  {
    "id": "am_demo_arte",
    "filename": "amiga_demo_arte.adf",
    "title": "Arte (Sanity)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_arte.adf",
    "year": 1993,
    "publisher": "Sanity",
    "developer": "Code: Chaos, McDeal, Mr. Pet · Graphics: Ra · Music: Moby"
  },
  {
    "id": "am_demo_globaltrash",
    "filename": "amiga_demo_globaltrash.adf",
    "title": "Global Trash (The Silents)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_globaltrash.adf",
    "year": 1991,
    "publisher": "The Silents",
    "developer": "Code: Sunjohn · Graphics: Mikael Balle, Sionic · Music: Jesper Kyd"
  },
  {
    "id": "am_demo_voyage",
    "filename": "amiga_demo_voyage.adf",
    "title": "Voyage (Razor 1911)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_voyage.adf",
    "year": 1991,
    "publisher": "Razor 1911",
    "developer": "Code: Sim · Graphics: Drake, Murdock · Music: Codex, Mantronix, Tip"
  },
  {
    "id": "am_demo_rinkadink",
    "filename": "amiga_demo_rinkadink.adf",
    "title": "Rink A Dink: Redux (Lemon.)",
    "platform": "Amiga",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "amiga_demo_rinkadink.adf",
    "year": 2013,
    "publisher": "Lemon.",
    "developer": "Code: Paradroid · Graphics: Paradroid, Facet, Prowler · Music: Magnar, from an original by Nuke"
  },
  {
    "id": "c64_demo_dutchbreeze",
    "filename": "c64_demo_dutchbreeze.d64",
    "title": "Dutch Breeze (Black Mail)",
    "platform": "C64",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "c64_demo_dutchbreeze.d64",
    "year": 1991,
    "publisher": "Black Mail",
    "developer": "Code: Alf, Gaap, Hitchhiker, Skyline, Thunder · Graphics: Hein, Orc a.o. · Music: Jeroen Tel, Reyn Ouwehand, Falco Paul"
  },
  {
    "id": "c64_demo_deusexmachina",
    "filename": "c64_demo_deusexmachina.d64",
    "title": "Deus Ex Machina (Crest & Oxyron)",
    "platform": "C64",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "c64_demo_deusexmachina.d64",
    "year": 2000,
    "publisher": "Crest, Oxyron",
    "developer": "Code: Crossbow, Graham · Graphics: Crossbow, DeeKay, Cyclone, Mermaid · Music: Drax, Jeff, MSK"
  },
  {
    "id": "c64_demo_royalarte",
    "filename": "c64_demo_royalarte.d64",
    "title": "Royal Arte (Booze Design)",
    "platform": "C64",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "c64_demo_royalarte.d64",
    "year": 2001,
    "publisher": "Booze Design",
    "developer": "Code: HCL · Graphics: HCL, DeeKay, Valsary, Forbidden Cult · Music: Dane, Vip, Goto80, Agemixer, Mindflow, 6R6"
  },
  {
    "id": "c64_demo_wonderland12",
    "filename": "c64_demo_wonderland12.d64",
    "title": "Wonderland XII (Censor Design)",
    "platform": "C64",
    "category": "Demoscene",
    "vpNumber": null,
    "tags": [
      "demoscene"
    ],
    "romFile": "c64_demo_wonderland12.d64",
    "year": 2013,
    "publisher": "Censor Design",
    "developer": "Code: Axis, Bob, CRT, Lavazza, Mirage, Swallow · Graphics: CG, Creeper, Dragon, Mirage, Taito, Yazoo · Music: Magnar"
  },
  {
    "id": "am_act_of_war",
    "filename": "amiga_act_of_war.adf",
    "title": "Act of War",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_act_of_war.adf",
    "year": 1992,
    "publisher": "David Smith",
    "developer": "David Smith"
  },
  {
    "id": "am_alien_bash",
    "filename": "amiga_alien_bash.adf",
    "title": "Alien Bash",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_alien_bash.adf",
    "year": 1993,
    "publisher": "Glen Cumming, Stuart Law",
    "developer": "Glen Cumming, Stuart Law"
  },
  {
    "id": "am_ant_wars",
    "filename": "amiga_ant_wars.adf",
    "title": "Ant Wars",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_ant_wars.adf",
    "year": 1994,
    "publisher": "Paranoid",
    "developer": "Paranoid"
  },
  {
    "id": "am_atoms",
    "filename": "amiga_atoms.adf",
    "title": "Atoms!",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_atoms.adf",
    "year": 1992,
    "publisher": "Tom Kuhn",
    "developer": "Tom Kuhn"
  },
  {
    "id": "am_biplanes",
    "filename": "amiga_biplanes.adf",
    "title": "Biplanes",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_biplanes.adf",
    "year": 1990,
    "publisher": "Peter Mason",
    "developer": "Peter Mason"
  },
  {
    "id": "am_black_dawn",
    "filename": "amiga_black_dawn.adf",
    "title": "Black Dawn",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_black_dawn.adf",
    "year": 1994,
    "publisher": "Andrew Campbell",
    "developer": "Andrew Campbell"
  },
  {
    "id": "am_colonial_conquest2",
    "filename": "amiga_colonial_conquest2.adf",
    "title": "Colonial Conquest II",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_colonial_conquest2.adf",
    "year": 1994,
    "publisher": "Christian Mumenthaler",
    "developer": "Christian Mumenthaler"
  },
  {
    "id": "am_diplomacy",
    "filename": "amiga_diplomacy.adf",
    "title": "Diplomacy 2.0",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_diplomacy.adf",
    "year": 1991,
    "publisher": "Steve Douthat",
    "developer": "Steve Douthat"
  },
  {
    "id": "am_donkey_kong",
    "filename": "amiga_donkey_kong.adf",
    "title": "Donkey Kong",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_donkey_kong.adf",
    "year": 1993,
    "publisher": "Bignonia",
    "developer": "Bignonia"
  },
  {
    "id": "am_doody",
    "filename": "amiga_doody.adf",
    "title": "Doody",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_doody.adf",
    "year": 1991,
    "publisher": "W.G.S.S.",
    "developer": "Andy Wandy"
  },
  {
    "id": "am_elevation2",
    "filename": "amiga_elevation2.adf",
    "title": "Elevation II",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_elevation2.adf",
    "year": null,
    "publisher": "Delta-9",
    "developer": "Lee C. Wilson"
  },
  {
    "id": "am_hellzone",
    "filename": "amiga_hellzone.adf",
    "title": "Hellzone: Carnage Extreme",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_hellzone.adf",
    "year": 1992,
    "publisher": "Interscan",
    "developer": "Cullhane Gibbs"
  },
  {
    "id": "am_knights",
    "filename": "amiga_knights.adf",
    "title": "Knights",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_knights.adf",
    "year": 1994,
    "publisher": "Reaper",
    "developer": "Reaper"
  },
  {
    "id": "am_mayhem",
    "filename": "amiga_mayhem.adf",
    "title": "Mayhem",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_mayhem.adf",
    "year": 1991,
    "publisher": "Ensignia",
    "developer": "Ensignia"
  },
  {
    "id": "am_particle_man",
    "filename": "amiga_particle_man.adf",
    "title": "Particle Man",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_particle_man.adf",
    "year": null,
    "publisher": "Paul Nordovics",
    "developer": "Paul Nordovics"
  },
  {
    "id": "am_sqrxz2",
    "filename": "amiga_sqrxz2.adf",
    "title": "Sqrxz 2",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_sqrxz2.adf",
    "year": 2012,
    "publisher": "Retroguru",
    "developer": "Retroguru"
  },
  {
    "id": "am_tanx",
    "filename": "amiga_tanx.adf",
    "title": "Tanx",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_tanx.adf",
    "year": 1991,
    "publisher": "Gaz Robertz",
    "developer": "Gaz Robertz"
  },
  {
    "id": "am_top_secret",
    "filename": "amiga_top_secret.adf",
    "title": "Top Secret",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_top_secret.adf",
    "year": 1992,
    "publisher": "The Hidden",
    "developer": "The Hidden"
  },
  {
    "id": "am_transplant",
    "filename": "amiga_transplant.adf",
    "title": "Transplant",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_transplant.adf",
    "year": 1992,
    "publisher": "Jumping Jack Flash",
    "developer": "Jumping Jack Flash"
  },
  {
    "id": "am_trap_runner",
    "filename": "amiga_trap_runner.adf",
    "title": "Trap Runner",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_trap_runner.adf",
    "year": 2018,
    "publisher": "Retroguru",
    "developer": "Night Owl Design"
  },
  {
    "id": "am_turboraketti",
    "filename": "amiga_turboraketti.adf",
    "title": "TurboRaketti",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_turboraketti.adf",
    "year": 1992,
    "publisher": "Heikki Kosola",
    "developer": "Heikki Kosola"
  },
  {
    "id": "am_tiny_pixel_adventure",
    "filename": "amiga_tiny_pixel_adventure.adf",
    "title": "Tiny Pixel Adventure",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_tiny_pixel_adventure.adf",
    "year": 2024,
    "publisher": "HooGames2017",
    "developer": "HooGames2017"
  },
  {
    "id": "am_tenebra2",
    "filename": "amiga_tenebra2.adf",
    "title": "Tenebra 2",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_tenebra2.adf",
    "year": 2023,
    "publisher": "Haplo",
    "developer": "Haplo"
  },
  {
    "id": "am_ooze",
    "filename": "amiga_ooze.adf",
    "title": "Ooze: The Escape",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_ooze.adf",
    "year": 2023,
    "publisher": "Haplo",
    "developer": "Haplo & Andy Johns"
  },
  {
    "id": "am_yoomp",
    "filename": "amiga_yoomp.adf",
    "title": "Amiga Yoomp!",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_yoomp.adf",
    "year": 2024,
    "publisher": "zr-games",
    "developer": "zr-games"
  },
  {
    "id": "am_shift",
    "filename": "amiga_shift.adf",
    "title": "Shift",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_shift.adf",
    "year": 2024,
    "publisher": "Haplo",
    "developer": "Haplo"
  },
  {
    "id": "am_yeet",
    "filename": "amiga_yeet.adf",
    "title": "YEET",
    "platform": "Amiga",
    "category": "Homebrew (community)",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_yeet.adf",
    "year": 2025,
    "publisher": "zooperdan",
    "developer": "zooperdan"
  },
  {
    "id": "am_arkanoid2",
    "filename": "amiga_arkanoid2.adf",
    "title": "Arkanoid: Revenge of Doh",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_arkanoid2.adf",
    "year": 1988,
    "publisher": "Imagine",
    "developer": "Taito"
  },
  {
    "id": "am_battle_squadron",
    "filename": "amiga_battle_squadron.adf",
    "title": "Battle Squadron",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_battle_squadron.adf",
    "year": 1989,
    "publisher": "Innerprise Software",
    "developer": "Cope-Com"
  },
  {
    "id": "am_blood_money",
    "filename": "amiga_blood_money.adf",
    "title": "Blood Money",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_blood_money.adf",
    "year": 1989,
    "publisher": "Psygnosis",
    "developer": "DMA Design"
  },
  {
    "id": "am_bubble_ghost",
    "filename": "amiga_bubble_ghost.adf",
    "title": "Bubble Ghost",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_bubble_ghost.adf",
    "year": 1988,
    "publisher": "Accolade",
    "developer": "ERE Informatique"
  },
  {
    "id": "am_chuck_rock",
    "filename": "amiga_chuck_rock.adf",
    "title": "Chuck Rock",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_chuck_rock.adf",
    "year": 1991,
    "publisher": "Core Design",
    "developer": "Core Design"
  },
  {
    "id": "am_double_dragon",
    "filename": "amiga_double_dragon.adf",
    "title": "Double Dragon",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_double_dragon.adf",
    "year": 1989,
    "publisher": "Melbourne House",
    "developer": "Binary Design"
  },
  {
    "id": "am_dynablaster",
    "filename": "amiga_dynablaster.adf",
    "title": "Dyna Blaster",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_dynablaster.adf",
    "year": 1992,
    "publisher": "Ubi Soft",
    "developer": "Hudson Soft"
  },
  {
    "id": "am_hunter",
    "filename": "amiga_hunter.adf",
    "title": "Hunter",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_hunter.adf",
    "year": 1991,
    "publisher": "Activision",
    "developer": "Paul Holmes"
  },
  {
    "id": "am_hybris",
    "filename": "amiga_hybris.adf",
    "title": "Hybris",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_hybris.adf",
    "year": 1988,
    "publisher": "Discovery Software",
    "developer": "Cope-Com"
  },
  {
    "id": "am_ikplus",
    "filename": "amiga_ikplus.adf",
    "title": "IK+",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_ikplus.adf",
    "year": 1988,
    "publisher": "System 3",
    "developer": "Archer Maclean"
  },
  {
    "id": "am_jetstrike",
    "filename": "amiga_jetstrike.adf",
    "title": "Jetstrike",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_jetstrike.adf",
    "year": 1993,
    "publisher": "Rasputin Software",
    "developer": "Shadow Software"
  },
  {
    "id": "am_katakis",
    "filename": "amiga_katakis.adf",
    "title": "Katakis",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_katakis.adf",
    "year": 1988,
    "publisher": "Rainbow Arts",
    "developer": "Factor 5"
  },
  {
    "id": "am_kick_off2",
    "filename": "amiga_kick_off2.adf",
    "title": "Kick Off 2",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_kick_off2.adf",
    "year": 1990,
    "publisher": "Anco Software",
    "developer": "Dino Dini"
  },
  {
    "id": "am_lotus_esprit",
    "filename": "amiga_lotus_esprit.adf",
    "title": "Lotus Esprit Turbo Challenge",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_lotus_esprit.adf",
    "year": 1990,
    "publisher": "Gremlin Graphics",
    "developer": "Magnetic Fields"
  },
  {
    "id": "am_magic_pockets",
    "filename": "amiga_magic_pockets.adf",
    "title": "Magic Pockets",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_magic_pockets.adf",
    "year": 1991,
    "publisher": "Renegade",
    "developer": "The Bitmap Brothers"
  },
  {
    "id": "am_menace",
    "filename": "amiga_menace.adf",
    "title": "Menace",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_menace.adf",
    "year": 1988,
    "publisher": "Psyclapse",
    "developer": "DMA Design"
  },
  {
    "id": "am_nebulus",
    "filename": "amiga_nebulus.adf",
    "title": "Nebulus",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_nebulus.adf",
    "year": 1988,
    "publisher": "Hewson Consultants",
    "developer": "John M. Phillips"
  },
  {
    "id": "am_new_zealand_story",
    "filename": "amiga_new_zealand_story.adf",
    "title": "The New Zealand Story",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_new_zealand_story.adf",
    "year": 1989,
    "publisher": "Ocean Software",
    "developer": "Taito"
  },
  {
    "id": "am_nitro",
    "filename": "amiga_nitro.adf",
    "title": "Nitro",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_nitro.adf",
    "year": 1990,
    "publisher": "Psygnosis",
    "developer": "Psygnosis"
  },
  {
    "id": "am_north_and_south",
    "filename": "amiga_north_and_south.adf",
    "title": "North & South",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_north_and_south.adf",
    "year": 1989,
    "publisher": "Infogrames",
    "developer": "Infogrames"
  },
  {
    "id": "am_pang",
    "filename": "amiga_pang.adf",
    "title": "Pang",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_pang.adf",
    "year": 1990,
    "publisher": "Ocean Software",
    "developer": "Mitchell Corporation"
  },
  {
    "id": "am_parasol_stars",
    "filename": "amiga_parasol_stars.adf",
    "title": "Parasol Stars: Rainbow Islands II",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_parasol_stars.adf",
    "year": 1992,
    "publisher": "Ocean Software",
    "developer": "Taito"
  },
  {
    "id": "am_populous",
    "filename": "amiga_populous.adf",
    "title": "Populous",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_populous.adf",
    "year": 1989,
    "publisher": "Electronic Arts",
    "developer": "Bullfrog"
  },
  {
    "id": "am_rick_dangerous",
    "filename": "amiga_rick_dangerous.adf",
    "title": "Rick Dangerous",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_rick_dangerous.adf",
    "year": 1989,
    "publisher": "Firebird",
    "developer": "Core Design"
  },
  {
    "id": "am_rick_dangerous2",
    "filename": "amiga_rick_dangerous2.adf",
    "title": "Rick Dangerous 2",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_rick_dangerous2.adf",
    "year": 1990,
    "publisher": "MicroStyle",
    "developer": "Core Design"
  },
  {
    "id": "am_robocod",
    "filename": "amiga_robocod.adf",
    "title": "James Pond 2: Codename RoboCod",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_robocod.adf",
    "year": 1991,
    "publisher": "Millennium Interactive",
    "developer": "Vectordean"
  },
  {
    "id": "am_rodland",
    "filename": "amiga_rodland.adf",
    "title": "Rod-Land",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_rodland.adf",
    "year": 1991,
    "publisher": "Storm",
    "developer": "Jaleco"
  },
  {
    "id": "am_rtype",
    "filename": "amiga_rtype.adf",
    "title": "R-Type",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_rtype.adf",
    "year": 1989,
    "publisher": "Electric Dreams",
    "developer": "Irem"
  },
  {
    "id": "am_skweek",
    "filename": "amiga_skweek.adf",
    "title": "Skweek",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_skweek.adf",
    "year": 1989,
    "publisher": "Loriciels",
    "developer": "Loriciels"
  },
  {
    "id": "am_speedball2",
    "filename": "amiga_speedball2.adf",
    "title": "Speedball 2: Brutal Deluxe",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_speedball2.adf",
    "year": 1991,
    "publisher": "Image Works",
    "developer": "The Bitmap Brothers"
  },
  {
    "id": "am_swiv",
    "filename": "amiga_swiv.adf",
    "title": "SWIV",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_swiv.adf",
    "year": 1991,
    "publisher": "Storm",
    "developer": "Random Access"
  },
  {
    "id": "am_turrican2",
    "filename": "amiga_turrican2.adf",
    "title": "Turrican II: The Final Fight",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_turrican2.adf",
    "year": 1991,
    "publisher": "Rainbow Arts",
    "developer": "Factor 5"
  },
  {
    "id": "am_wings_of_fury",
    "filename": "amiga_wings_of_fury.adf",
    "title": "Wings of Fury",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_wings_of_fury.adf",
    "year": 1990,
    "publisher": "Broderbund",
    "developer": "Bill Heineman"
  },
  {
    "id": "am_xenon2",
    "filename": "amiga_xenon2.adf",
    "title": "Xenon 2: Megablast",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_xenon2.adf",
    "year": 1989,
    "publisher": "Image Works",
    "developer": "The Bitmap Brothers"
  },
  {
    "id": "am_xout",
    "filename": "amiga_xout.adf",
    "title": "X-Out",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_xout.adf",
    "year": 1990,
    "publisher": "Rainbow Arts",
    "developer": "Arc Developments"
  },
  {
    "id": "am_zout",
    "filename": "amiga_zout.adf",
    "title": "Z-Out",
    "platform": "Amiga",
    "category": "Amiga",
    "vpNumber": null,
    "tags": [],
    "romFile": "amiga_zout.adf",
    "year": 1991,
    "publisher": "Rainbow Arts",
    "developer": "Rainbow Arts"
  }
]
};
