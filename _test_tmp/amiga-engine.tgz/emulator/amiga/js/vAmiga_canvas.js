let TPP=2;
let HBLANK_MIN=0x12*TPP;
let HPIXELS=912*TPP;
let VPIXELS=313;
let xOff = HBLANK_MIN;//252
let yOff=26 + 6;
let clipped_width=HPIXELS-xOff-8*TPP;
let clipped_height=VPIXELS-yOff ;

let ctx=null;

function create2d_context()
{
    const canvas = document.getElementById('canvas');
    ctx = canvas.getContext('2d');
    image_data=ctx.createImageData(HPIXELS,VPIXELS);
//    pixel_buffer=new Uint8Array(0);
}

function render_canvas()
{
    let pixels = Module._wasm_pixel_buffer() + yOff*(HPIXELS<<2);
    let pixel_buffer=new Uint8Array(Module.HEAPU8.buffer, pixels, HPIXELS*clipped_height<<2);
    image_data.data.set(pixel_buffer);

    //putImageData(imageData, dx, dy, dirtyX, dirtyY, dirtyWidth, dirtyHeight)
    ctx.putImageData(image_data,
        -xOff/*TPP*/,/*-yOff*/0, 
        /*x,y*/ 
        xOff/*TPP*/,/*yOff*/0 
        /* width, height */, 
        clipped_width, clipped_height); 
}

function js_set_display(_xOff, _yOff, _clipped_width,_clipped_height) {
    xOff=_xOff*TPP -HBLANK_MIN*4;
    yOff=_yOff;
    clipped_width =_clipped_width;
    clipped_height=_clipped_height;
    if(clipped_height%2!=0) clipped_height++; //when odd make the height even 
    if(clipped_height+yOff > VPIXELS)
    {
        clipped_height=(VPIXELS-yOff) & 0xfffe;
    }

    let the_canvas = document.getElementById("canvas");
    the_canvas.width=clipped_width;
    if(typeof gl != 'undefined' && gl!=null)
    {
        the_canvas.height=clipped_height*2;

        let VPOS_CNT=VPIXELS;
        let HPOS_CNT=HPIXELS;
        updateTextureRect(xOff /HPOS_CNT, yOff / VPOS_CNT, (xOff+clipped_width) / HPOS_CNT, (yOff+clipped_height)/VPOS_CNT); 
    }
    else
    {
        the_canvas.height=clipped_height;
    }
}

function scaleVMCanvas() {
    let the_canvas = document.getElementById("canvas");
    // Vault-local fix (2026-09-16): clipped_width is in texels - TPP (=2) of
    // them per real Amiga pixel - while src_height below is in doubled
    // scanlines. Comparing them raw gave a ratio of ~2.5 instead of the ~1.25
    // this code's own comment expects, so the wratio test further down chose
    // the fit-to-width branch on ordinary landscape windows and sized the
    // canvas taller than the viewport: the bottom of the Amiga screen was cut
    // off, fullscreen and windowed alike. Dividing by TPP makes src_ratio the
    // real display ratio; the matching TPP factor is dropped from
    // reducedHeight below, so the fit-to-width branch still produces exactly
    // the size it always did. Revisit if the engine is ever updated.
    var src_width=clipped_width/TPP; //Module._wasm_get_render_width();
    var src_height=clipped_height*2;//Module._wasm_get_render_height()*2; 
    if(use_ntsc_pixel)
    {
        src_height*=52/44; //make NTSC a bit taller
    }
    var src_ratio = src_width/src_height; //1.25
/*        if(Module._wasm_get_renderer()==0)
    {//software renderer only has half of height pixels
        src_height*=2;
        src_ratio = src_width/src_height;
    }*/
    
    src_ratio*=1.03; //make it a bit wider
    
    var inv_src_ratio = src_height/src_width;

    //reserve space for the docked live memory view (if open)
    var reserved = (typeof memview_reserved_width === 'function') ? memview_reserved_width() : 0;
    var avail_width  = window.innerWidth - reserved;
    var avail_height = window.innerHeight;
    var wratio = avail_width / avail_height;

    //shrink the horizontal centering box (left:0 .. right:reserved) so the
    //canvas (margin:auto) centers within the available left area instead of
    //the full viewport and is not covered by the memory view panel
    $("#canvas").css("right", reserved + 'px');

    var topPos=0;
    if(wratio < src_ratio)
    {
        // no TPP factor: src_width is already in real pixels (see above)
        var reducedHeight=avail_width*inv_src_ratio;
        //all lower than 1.25
        $("#canvas").css("width", avail_width+'px')
        .css("height", Math.round(reducedHeight)+'px');
        
        if($("#virtual_keyboard").is(":hidden"))
        {   //center vertical, if virtual keyboard and navbar not present
            topPos=Math.round((avail_height-reducedHeight)/2);
        }
        else
        {//virtual keyboard is present
            var keyb_height= $("#virtual_keyboard").innerHeight();          
            //positioning directly stacked onto keyboard          
            topPos=Math.round(avail_height-reducedHeight-keyb_height);
        }
        if(topPos<0)
        {
            topPos=0;
        }
    }
    else
    {
        //all greater than 1.25
        var target_width;
        if(use_wide_screen)
        {
            target_width = avail_width;
        }
        else
        {
            target_width = Math.round(avail_height*src_ratio);
            if(target_width > avail_width) target_width = avail_width;
        }
        $("#canvas").css("width", target_width +'px');
        $("#canvas").css("height", "100%"); 
    }

    $("#canvas").css("top", topPos + 'px');   
};
